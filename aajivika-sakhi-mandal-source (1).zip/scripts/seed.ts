// Seed script for AAJIVIKA SAKHI MANDAL with full SHG-style member data
// Run with: bun run /home/z/my-project/scripts/seed.ts
import { db } from '../src/lib/db'

async function main() {
  // Clear existing data
  await db.meeting.deleteMany()
  await db.loanPayment.deleteMany()
  await db.weeklySaving.deleteMany()
  await db.expense.deleteMany()
  await db.expenseCategory.deleteMany()
  await db.privateLoan.deleteMany()
  await db.bankLoan.deleteMany()
  await db.member.deleteMany()
  await db.admin.deleteMany()
  await db.settings.deleteMany()

  // 1. Create admin
  const admin = await db.admin.create({
    data: {
      username: 'admin',
      password: 'sakhi123',
      name: 'Sunita Devi (President)',
    },
  })
  console.log('Created admin:', admin.username)

  // 2. Create settings — SHG group ID like JH340302
  const settings = await db.settings.create({
    data: {
      registrationNo: 'JH-ENB-2024-00874',
      groupCode: 'JH340302',
      groupName: 'Aajivika Sakhi Mandal',
      foundingDate: new Date('2020-10-14'),
      meetingDay: 'Wednesday',
      weeklySavingsPerMember: 10,
      presidentName: 'Sunita Devi',
      authorizedSignatoryName: 'Sunita Devi',
      bankName: 'Jharkhand Rajya Gramin Bank (JRGB)',
      bankBranch: 'Silchar',
      district: 'Ranchi',
      minSavings: 2,
      maxSavings: 5,
      maxLoanAmount: 10000,
      interestRate: 1.5,
    },
  })
  console.log('Created settings, groupCode:', settings.groupCode)

  // 3. Create 10 members with full SHG-style data
  // Posts: अध्यक्ष, उपाध्यक्ष, सचिव, कोषाध्यक्ष, बी.के., सदस्य
  const memberData = [
    {
      memberCode: 'JH3844416',
      name: 'Sunita Devi',
      guardianName: 'Shriram Ramesh',
      post: 'अध्यक्ष',
      age: 38,
      education: '10वीं',
      occupation: 'खेतिहर',
      village: 'Harmu',
      district: 'Ranchi',
      joiningDate: new Date('2020-10-14'),
      kycStatus: 'Verified',
      bankName: 'Jharkhand Rajya Gramin Bank',
      accountNo: '38291047652',
      ifscCode: 'PUNB0452300',
      phone: '9835102345',
      address: 'Harmu Road, Ranchi',
    },
    {
      memberCode: 'JH3844417',
      name: 'Geeta Kumari',
      guardianName: 'Harimohan Ramesh',
      post: 'सदस्य',
      age: 31,
      education: '8वीं',
      occupation: 'मजदूर',
      village: 'Bariatu',
      district: 'Ranchi',
      joiningDate: new Date('2020-10-14'),
      kycStatus: 'Verified',
      bankName: 'Bank of India',
      accountNo: '73820194568',
      ifscCode: 'BKID000482',
      phone: '9835204578',
      address: 'Bariatu, Ranchi',
    },
    {
      memberCode: 'JH3844418',
      name: 'Rekha Devi',
      guardianName: 'Harimohan Ramesh',
      post: 'सचिव',
      age: 40,
      education: '5वीं',
      occupation: 'खेतिहर',
      village: 'Doranda',
      district: 'Ranchi',
      joiningDate: new Date('2020-10-21'),
      kycStatus: 'Verified',
      bankName: 'Punjab National Bank',
      accountNo: '15283940671',
      ifscCode: 'PUNB0452300',
      phone: '9835305891',
      address: 'Doranda, Ranchi',
    },
    {
      memberCode: 'JH3844419',
      name: 'Anita Lakra',
      guardianName: 'Ramcharitra Ramesh',
      post: 'कोषाध्यक्ष',
      age: 35,
      education: '10वीं',
      occupation: 'खेतिहर',
      village: 'Kanke',
      district: 'Ranchi',
      joiningDate: new Date('2020-10-21'),
      kycStatus: 'Verified',
      bankName: 'State Bank of India',
      accountNo: '38291087634',
      ifscCode: 'SBIN0004521',
      phone: '9835406123',
      address: 'Kanke Road, Ranchi',
    },
    {
      memberCode: 'JH3844420',
      name: 'Priya Murmu',
      guardianName: 'Ramcharitra Ramesh',
      post: 'बी.के.',
      age: 28,
      education: '12वीं',
      occupation: 'व्यवसाय',
      village: 'Lalpur',
      district: 'Ranchi',
      joiningDate: new Date('2020-10-28'),
      kycStatus: 'Verified',
      bankName: 'Central Bank of India',
      accountNo: '90182736452',
      ifscCode: 'CBIN0004521',
      phone: '9835507345',
      address: 'Lalpur, Ranchi',
    },
    {
      memberCode: 'JH3844421',
      name: 'Sarla Tudu',
      guardianName: 'Ramcharitra Ramesh',
      post: 'सदस्य',
      age: 42,
      education: '8वीं',
      occupation: 'खेतिहर',
      village: 'Upper Bazar',
      district: 'Ranchi',
      joiningDate: new Date('2020-11-04'),
      kycStatus: 'Verified',
      bankName: 'Bank of India',
      accountNo: '73820458921',
      ifscCode: 'BKID000482',
      phone: '9835608567',
      address: 'Upper Bazar, Ranchi',
    },
    {
      memberCode: 'JH3844422',
      name: 'Kavita Soren',
      guardianName: 'Shriram Ramesh',
      post: 'सदस्य',
      age: 26,
      education: '10वीं',
      occupation: 'मजदूर',
      village: 'Ratu Road',
      district: 'Ranchi',
      joiningDate: new Date('2020-11-11'),
      kycStatus: 'Pending',
      bankName: 'State Bank of India',
      accountNo: '38291234567',
      ifscCode: 'SBIN0004521',
      phone: '9835709789',
      address: 'Ratu Road, Ranchi',
    },
    {
      memberCode: 'JH3844423',
      name: 'Manju Kisku',
      guardianName: 'Ramcharitra Ramesh',
      post: 'सदस्य',
      age: 33,
      education: '8वीं',
      occupation: 'खेतिहर',
      village: 'Argora',
      district: 'Ranchi',
      joiningDate: new Date('2020-11-18'),
      kycStatus: 'Verified',
      bankName: 'Punjab National Bank',
      accountNo: '15283456789',
      ifscCode: 'PUNB0452300',
      phone: '9835801011',
      address: 'Argora, Ranchi',
    },
    {
      memberCode: 'JH3844424',
      name: 'Bimla Hansda',
      guardianName: 'Ramcharitra Ramesh',
      post: 'सदस्य',
      age: 45,
      education: '5वीं',
      occupation: 'किसान',
      village: 'Harmu Housing',
      district: 'Ranchi',
      joiningDate: new Date('2020-11-25'),
      kycStatus: 'Verified',
      bankName: 'Central Bank of India',
      accountNo: '90182345678',
      ifscCode: 'CBIN0004521',
      phone: '9835901234',
      address: 'Harmu Housing Colony, Ranchi',
    },
    {
      memberCode: 'JH3844425',
      name: 'Rina Marandi',
      guardianName: 'Shriram Ramesh',
      post: 'सदस्य',
      age: 29,
      education: '11वीं',
      occupation: 'व्यवसाय',
      village: 'Booty More',
      district: 'Ranchi',
      joiningDate: new Date('2020-12-02'),
      kycStatus: 'Verified',
      bankName: 'State Bank of India',
      accountNo: '38291456789',
      ifscCode: 'SBIN0004521',
      phone: '9835111357',
      address: 'Booty More, Ranchi',
    },
  ]

  const members = []
  for (let i = 0; i < memberData.length; i++) {
    const m = await db.member.create({
      data: {
        serialNo: i + 1,
        ...memberData[i],
      },
    })
    members.push(m)
  }
  console.log(`Created ${members.length} members`)

  // 4. Create private loans for some members
  const privateLoans = [
    { memberIdx: 0, amount: 5000, disbDate: '2024-04-10', repayAmount: 5000, repayDate: '2024-07-10' },
    { memberIdx: 1, amount: 3000, disbDate: '2024-05-15', repayAmount: 1500, repayDate: '2024-09-20' },
    { memberIdx: 2, amount: 8000, disbDate: '2024-06-01', repayAmount: 0, repayDate: null },
    { memberIdx: 4, amount: 4000, disbDate: '2024-07-12', repayAmount: 4000, repayDate: '2024-10-25' },
    { memberIdx: 5, amount: 6000, disbDate: '2024-08-05', repayAmount: 2000, repayDate: '2024-11-15' },
    { memberIdx: 7, amount: 2500, disbDate: '2024-09-18', repayAmount: 0, repayDate: null },
    { memberIdx: 9, amount: 7000, disbDate: '2024-10-22', repayAmount: 3500, repayDate: '2025-01-30' },
  ]

  for (const pl of privateLoans) {
    await db.privateLoan.create({
      data: {
        memberId: members[pl.memberIdx].id,
        loanAmount: pl.amount,
        disbursementDate: new Date(pl.disbDate),
        repaymentAmount: pl.repayAmount,
        repaymentDate: pl.repayDate ? new Date(pl.repayDate) : null,
      },
    })
  }
  console.log(`Created ${privateLoans.length} private loans`)

  // 5. Create bank loan records
  const bankLoans = [
    { memberIdx: 0, share: 15000, emi: 2500, interest: 1200, payDate: '2025-06-15' },
    { memberIdx: 1, share: 12000, emi: 2000, interest: 960, payDate: '2025-06-15' },
    { memberIdx: 2, share: 15000, emi: 2500, interest: 1200, payDate: '2025-06-15' },
    { memberIdx: 3, share: 10000, emi: 1666, interest: 800, payDate: '2025-06-15' },
    { memberIdx: 4, share: 12000, emi: 2000, interest: 960, payDate: '2025-06-15' },
    { memberIdx: 5, share: 15000, emi: 2500, interest: 1200, payDate: '2025-06-15' },
    { memberIdx: 7, share: 10000, emi: 1666, interest: 800, payDate: '2025-06-15' },
    { memberIdx: 9, share: 12000, emi: 2000, interest: 960, payDate: '2025-06-15' },
  ]

  const createdBankLoans = []
  for (const bl of bankLoans) {
    const created = await db.bankLoan.create({
      data: {
        memberId: members[bl.memberIdx].id,
        bankLoanShare: bl.share,
        emiPaid: bl.emi,
        interestPaid: bl.interest,
        paymentDate: new Date(bl.payDate),
        bankName: 'Jharkhand Rajya Gramin Bank - SHG Loan Scheme',
      },
    })
    createdBankLoans.push({ ...bl, id: created.id, memberId: members[bl.memberIdx].id })
  }
  console.log(`Created ${bankLoans.length} bank loan records`)

  // 6. Create expense categories (खर्च श्रेणियाँ)
  const categoryNames = [
    'रोटी खर्च',
    'यात्रा खर्च',
    'चिकित्सा खर्च',
    'शिक्षा खर्च',
    'त्योहार खर्च',
    'अन्य खर्च',
  ]
  for (const name of categoryNames) {
    await db.expenseCategory.create({ data: { name } })
  }
  console.log(`Created ${categoryNames.length} expense categories`)

  // 7. Create sample expenses for members (some are member-specific, some are group-level)
  const expenses = [
    { memberIdx: 0, category: 'रोटी खर्च', amount: 500, desc: 'मासिक राशन खरीद', date: '2025-06-10' },
    { memberIdx: 0, category: 'चिकित्सा खर्च', amount: 1200, desc: 'बुखार के लिए दवा एवं डॉक्टर फीस', date: '2025-06-18' },
    { memberIdx: 1, category: 'यात्रा खर्च', amount: 300, desc: 'रांची से बोकारो यात्रा', date: '2025-06-12' },
    { memberIdx: 2, category: 'रोटी खर्च', amount: 450, desc: 'सब्जी एवं किराना', date: '2025-06-15' },
    { memberIdx: 3, category: 'शिक्षा खर्च', amount: 800, desc: 'बच्चों की किताबें एवं फीस', date: '2025-06-20' },
    { memberIdx: 4, category: 'त्योहार खर्च', amount: 1000, desc: 'सरहुल पर्व कोटि खर्च', date: '2025-06-05' },
    { memberIdx: 5, category: 'चिकित्सा खर्च', amount: 2000, desc: 'अस्पताल में जांच एवं इलाज', date: '2025-06-22' },
    { memberIdx: 6, category: 'रोटी खर्च', amount: 350, desc: 'साप्ताहिक राशन', date: '2025-06-08' },
    { memberIdx: 7, category: 'यात्रा खर्च', amount: 250, desc: 'ब्लॉक कार्यालय जाने का खर्च', date: '2025-06-14' },
    { memberIdx: 8, category: 'अन्य खर्च', amount: 600, desc: 'कपड़े खरीद', date: '2025-06-19' },
    { memberIdx: 9, category: 'रोटी खर्च', amount: 400, desc: 'मासिक किराना', date: '2025-06-11' },
    // Group-level expenses (no specific member) — these are pure samuh (group) expenses
    { memberIdx: null, category: 'अन्य खर्च', amount: 1500, desc: 'समूह रजिस्टर एवं स्टांप खर्च', date: '2025-06-03' },
    { memberIdx: null, category: 'यात्रा खर्च', amount: 800, desc: 'समूह की बैंक यात्रा — खाता खुलवाने', date: '2025-06-07' },
    { memberIdx: null, category: 'त्योहार खर्च', amount: 2000, desc: 'समूह वार्षिकोत्सव का खर्च — चाय नाश्ता सामग्री', date: '2025-06-25' },
  ]

  for (const ex of expenses) {
    await db.expense.create({
      data: {
        memberId: ex.memberIdx !== null ? members[ex.memberIdx].id : null,
        category: ex.category,
        amount: ex.amount,
        description: ex.desc,
        expenseDate: new Date(ex.date),
      },
    })
  }
  console.log(`Created ${expenses.length} expense records (incl. group-level)`)

  // 8. Create weekly savings records (last 8 Wednesdays)
  // Generate last 8 Wednesdays from today
  const today = new Date()
  const dayOfWeek = today.getDay() // 0=Sun, 3=Wed
  const daysToLastWed = (dayOfWeek - 3 + 7) % 7
  const lastWednesday = new Date(today)
  lastWednesday.setDate(today.getDate() - daysToLastWed)

  const wednesdays: Date[] = []
  for (let i = 7; i >= 0; i--) {
    const d = new Date(lastWednesday)
    d.setDate(lastWednesday.getDate() - i * 7)
    wednesdays.push(d)
  }

  let savingCount = 0
  for (let w = 0; w < wednesdays.length; w++) {
    const weekDate = wednesdays[w]
    for (let m = 0; m < members.length; m++) {
      // Most members paid (80%), some pending (15%), some advance (5%)
      const rand = (m * 7 + w * 3) % 20
      let status: 'paid' | 'pending' | 'advance' = 'paid'
      let amount = 10
      let advanceWeeks = 0

      if (rand < 1 && w < 6) {
        // Advance — paid for 2 weeks
        status = 'advance'
        amount = 20
        advanceWeeks = 1
      } else if (rand < 4 && w >= 2 && w < 7) {
        // Pending (skip most recent week so not everyone is pending)
        status = 'pending'
        amount = 0
      } else if (rand < 5 && w === 7) {
        // Most recent week — some pending
        status = 'pending'
        amount = 0
      }

      // Skip the very latest week for some members to simulate "not yet collected"
      if (w === 7 && rand >= 5) {
        status = 'pending'
        amount = 0
      }

      await db.weeklySaving.create({
        data: {
          memberId: members[m].id,
          weekDate,
          amount,
          status,
          advanceWeeks,
        },
      })
      savingCount++
    }
  }
  console.log(`Created ${savingCount} weekly saving records (${wednesdays.length} weeks × ${members.length} members)`)

  // 9. Create loan payment history (EMI / repayment entries with dates)
  let paymentCount = 0
  for (const bl of createdBankLoans) {
    // Create 3 EMI payment entries per bank loan
    const emiAmount = bl.emi / 3 // split total emiPaid into 3 entries
    const interestPerEmi = bl.interest / 3
    const principalPerEmi = emiAmount - interestPerEmi
    let remaining = bl.share
    const payDates = ['2025-04-15', '2025-05-15', '2025-06-15']
    for (let i = 0; i < 3; i++) {
      remaining -= principalPerEmi
      await db.loanPayment.create({
        data: {
          memberId: bl.memberId,
          loanType: 'bank',
          loanId: bl.id,
          paymentDate: new Date(payDates[i]),
          amount: emiAmount,
          principal: principalPerEmi,
          interest: interestPerEmi,
          remainingBalance: Math.max(0, remaining),
          paymentMode: 'bank',
          receiptNo: `RCP-BL-${bl.id.slice(-4)}-${i + 1}`,
        },
      })
      paymentCount++
    }
  }
  console.log(`Created ${paymentCount} bank loan payment entries`)

  // Private loan payment history
  let privPaymentCount = 0
  for (const pl of privateLoans) {
    if (pl.repayAmount > 0) {
      // Create 1-2 payment entries
      const numPayments = pl.repayAmount > 2000 ? 2 : 1
      const perPayment = pl.repayAmount / numPayments
      const interest = perPayment * 0.1 // 10% interest portion
      const principal = perPayment - interest
      let remaining = pl.amount
      const payDates = pl.repayDate
        ? [pl.repayDate]
        : ['2025-01-30']
      if (numPayments === 2) {
        payDates.unshift('2024-12-15')
      }
      for (let i = 0; i < numPayments; i++) {
        remaining -= principal
        await db.loanPayment.create({
          data: {
            memberId: members[pl.memberIdx].id,
            loanType: 'private',
            loanId: `pl-${pl.memberIdx}-${i}`, // reference
            paymentDate: new Date(payDates[i]),
            amount: perPayment,
            principal,
            interest,
            remainingBalance: Math.max(0, remaining),
            paymentMode: 'cash',
            remarks: pl.repayDate ? 'समूह लोन चुकौती' : 'आंशिक चुकौती',
          },
        })
        privPaymentCount++
      }
    }
  }
  console.log(`Created ${privPaymentCount} private loan payment entries`)

  // 10. Create meeting records (प्रस्ताव)
  const meetings = [
    {
      meetingDate: '2025-06-04', location: 'सुनीता देवी के घर, हरमू',
      meetingTime: '11:00 AM', chairperson: 'सुनीता देवी', secretary: 'रेखा देवी',
      presentCount: 10, absentCount: 0, presentMembers: 'सुनीता, गीता, रेखा, अनिता, प्रिया, सरला, कविता, मंजू, बिमला, रीना',
      topic: 'मासिक बचत संग्रह एवं ऋण वितरण',
      decisions: JSON.stringify([
        { desc: 'सभी सदस्यों से ₹10 बचत जमा की गई', action: 'जमा पूर्ण', date: '2025-06-04', member: 'सभी', remark: '₹100 कुल जमा' },
        { desc: 'सरला तुडू को ₹6000 का प्राइवेट लोन स्वीकृत', action: 'लोन वितरण', date: '2025-06-04', member: 'सरला तुडू', remark: 'ब्याज 1.5%/माह' },
      ]),
      totalSavings: 100, totalPending: 0, totalAdvance: 0, totalLoanGiven: 6000, totalLoanCollected: 0,
      nextMeetingDate: '2025-06-11', nextMeetingLocation: 'गीता कुमारी के घर, बरियातू', nextMeetingHost: 'गीता कुमारी',
      notes: 'सभी सदस्य उपस्थित थे। बैठक सफल रही।'
    },
    {
      meetingDate: '2025-06-11', location: 'गीता कुमारी के घर, बरियातू',
      meetingTime: '11:00 AM', chairperson: 'सुनीता देवी', secretary: 'रेखा देवी',
      presentCount: 9, absentCount: 1, presentMembers: 'सुनीता, गीता, रेखा, अनिता, प्रिया, सरला, कविता, मंजू, रीना',
      topic: 'साप्ताहिक बचत एवं कविता सोरेन का KYC',
      decisions: JSON.stringify([
        { desc: '9 सदस्यों से ₹10 जमा, कविता अनुपस्थित', action: 'जमा', date: '2025-06-11', member: 'कविता सोरेन', remark: '₹10 बकाया' },
        { desc: 'कविता सोरेन का KYC लंबित — अगली बैठक तक पूरा करें', action: 'कार्यवाही', date: '2025-06-11', member: 'कविता सोरेन', remark: 'आधार लाएं' },
      ]),
      totalSavings: 90, totalPending: 10, totalAdvance: 0, totalLoanGiven: 0, totalLoanCollected: 5000,
      nextMeetingDate: '2025-06-18', nextMeetingLocation: 'रेखा देवी के घर, डोरंदा', nextMeetingHost: 'रेखा देवी',
      notes: 'कविता अनुपस्थित थी।'
    },
    {
      meetingDate: '2025-06-18', location: 'रेखा देवी के घर, डोरंदा',
      meetingTime: '11:00 AM', chairperson: 'सुनीता देवी', secretary: 'रेखा देवी',
      presentCount: 10, absentCount: 0, presentMembers: 'सभी 10 सदस्य उपस्थित',
      topic: 'बैंक लोन EMI भुगतान एवं बचत',
      decisions: JSON.stringify([
        { desc: 'सभी सदस्यों से ₹10 जमा की गई', action: 'जमा पूर्ण', date: '2025-06-18', member: 'सभी', remark: '₹100 कुल' },
        { desc: 'बैंक लोन EMI ₹2500 भुगतान किया गया', action: 'EMI भुगतान', date: '2025-06-18', member: 'सुनीता देवी', remark: 'JRGB बैंक' },
        { desc: 'मंजू किस्कू को ₹2500 प्राइवेट लोन स्वीकृत', action: 'लोन वितरण', date: '2025-06-18', member: 'मंजू किस्कू', remark: '1.5% ब्याज' },
      ]),
      totalSavings: 100, totalPending: 0, totalAdvance: 20, totalLoanGiven: 2500, totalLoanCollected: 2500,
      nextMeetingDate: '2025-06-25', nextMeetingLocation: 'अनिता लाकड़ा के घर, कांके', nextMeetingHost: 'अनिता लाकड़ा',
      notes: 'प्रिया मुर्मू ने ₹20 एडवांस जमा किए।'
    },
  ]

  for (let i = 0; i < meetings.length; i++) {
    const mt = meetings[i]
    await db.meeting.create({
      data: {
        resolutionNo: i + 1,
        meetingDate: new Date(mt.meetingDate),
        location: mt.location,
        meetingTime: mt.meetingTime,
        chairperson: mt.chairperson,
        secretary: mt.secretary,
        presentCount: mt.presentCount,
        absentCount: mt.absentCount,
        presentMembers: mt.presentMembers,
        topic: mt.topic,
        decisions: mt.decisions,
        totalSavings: mt.totalSavings,
        totalPending: mt.totalPending,
        totalAdvance: mt.totalAdvance,
        totalLoanGiven: mt.totalLoanGiven,
        totalLoanCollected: mt.totalLoanCollected,
        nextMeetingDate: mt.nextMeetingDate ? new Date(mt.nextMeetingDate) : null,
        nextMeetingLocation: mt.nextMeetingLocation,
        nextMeetingHost: mt.nextMeetingHost,
        notes: mt.notes,
      },
    })
  }
  console.log(`Created ${meetings.length} meeting records (प्रस्ताव)`)

  console.log('\n--- Seed Summary ---')
  console.log('Admin username: admin')
  console.log('Admin password: sakhi123')
  console.log('Group Code: JH340302')
  console.log('Members: 10 (with full SHG-style data)')
  console.log('Posts: अध्यक्ष, सचिव, कोषाध्यक्ष, बी.के., सदस्य')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
