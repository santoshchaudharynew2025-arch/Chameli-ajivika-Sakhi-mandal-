'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar } from '@/components/shg/avatar'
import { formatINR, formatDate, formatTimeIST, formatTodayLongIST } from '@/lib/format'
import {
  Users,
  Wallet,
  Landmark,
  HandCoins,
  TrendingUp,
  AlertCircle,
  CalendarCheck,
  ArrowUpCircle,
  ArrowDownCircle,
  Banknote,
  PieChart,
  FileBarChart,
  CheckCircle2,
  Clock4,
  IndianRupee,
  BarChart3,
  Table2,
} from 'lucide-react'

interface ReportData {
  executive: {
    totalMembers: number
    totalSavings: number
    totalBankLoan: number
    totalBankLoanPaid: number
    totalBankLoanRemaining: number
    totalBankInterest: number
    totalPrivateLoan: number
    totalPrivateLoanRepaid: number
    totalPrivateLoanRemaining: number
    totalExpenses: number
    pendingThisWeek: number
    advanceThisWeek: number
    paidThisWeek: number
    pendingMembers: number
    advanceMembers: number
    paidMembers: number
    todayCollection: number
    weekCollection: number
    monthCollection: number
    yearCollection: number
    latestWeekDate: string | null
    weeklySavingsPerMember: number
  }
  memberReports: Array<{
    memberId: string
    name: string
    phone: string | null
    village: string | null
    post: string
    photoUrl: string | null
    totalSavings: number
    totalPending: number
    totalAdvance: number
    bankLoanTaken: number
    bankLoanPaid: number
    bankLoanRemaining: number
    privateLoanTaken: number
    privateLoanRepaid: number
    privateLoanRemaining: number
    totalInterest: number
    lastPaymentDate: string | null
  }>
  weeklyCollection: Array<{
    name: string
    memberCode: string
    photoUrl: string | null
    amount: number
    status: string
    advanceWeeks: number
  }>
  pendingReport: typeof memberReports
  advanceReport: typeof memberReports
  weeklySavingsHistory: Array<{
    date: string
    memberName: string
    memberCode: string
    amount: number
    status: string
    advanceWeeks: number
  }>
}

type ReportTab = 'executive' | 'weekly' | 'member' | 'pending' | 'advance' | 'charts'

export function ReportsSection() {
  const [data, setData] = useState<ReportData | null>(null)
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<ReportTab>('executive')

  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const res = await fetch('/api/reports', { cache: 'no-store' })
        const json = await res.json()
        if (mounted && json.ok) setData(json.report)
      } catch { /* swallow */ } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
  }, [])

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="h-10 bg-muted/60 animate-pulse rounded-lg w-96" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 bg-muted/60 animate-pulse rounded-xl" />
          ))}
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <Card>
        <CardContent className="py-10 text-center text-sm text-muted-foreground">
          Could not load reports. Please refresh.
        </CardContent>
      </Card>
    )
  }

  const tabs: { id: ReportTab; label: string; icon: React.ReactNode }[] = [
    { id: 'executive', label: 'Executive Summary', icon: <BarChart3 className="w-3.5 h-3.5" /> },
    { id: 'weekly', label: 'Weekly Collection', icon: <CalendarCheck className="w-3.5 h-3.5" /> },
    { id: 'member', label: 'Member Financial', icon: <Table2 className="w-3.5 h-3.5" /> },
    { id: 'pending', label: 'Pending Report', icon: <AlertCircle className="w-3.5 h-3.5" /> },
    { id: 'advance', label: 'Advance Report', icon: <ArrowUpCircle className="w-3.5 h-3.5" /> },
    { id: 'charts', label: '📊 Charts', icon: <PieChart className="w-3.5 h-3.5" /> },
  ]

  return (
    <div className="space-y-5">
      {/* Title */}
      <div className="flex items-baseline gap-2 flex-wrap">
        <h2 className="text-lg font-semibold">वित्तीय रिपोर्ट्स (Financial Reports)</h2>
        <span className="text-sm text-muted-foreground">
          Live reporting dashboard
        </span>
      </div>

      {/* Tab bar */}
      <div className="flex gap-1 border-b overflow-x-auto no-scrollbar">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-3 py-2 text-xs sm:text-sm font-medium border-b-2 transition whitespace-nowrap ${
              tab === t.id
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <span className="inline mr-1.5">{t.icon}</span>
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      {tab === 'executive' && <ExecutiveSummary exec={data.executive} />}
      {tab === 'weekly' && <WeeklyCollectionReport data={data} />}
      {tab === 'member' && <MemberFinancialReport members={data.memberReports} />}
      {tab === 'pending' && <PendingReport members={data.pendingReport} />}
      {tab === 'advance' && <AdvanceReport members={data.advanceReport} />}
      {tab === 'charts' && <ChartsReport data={data} />}
    </div>
  )
}

/* ===================== Executive Summary ===================== */
function ExecutiveSummary({ exec }: { exec: ReportData['executive'] }) {
  return (
    <div className="space-y-5">
      {/* Top row: 4 big stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <BigStat
          label="Total Members"
          value={String(exec.totalMembers)}
          icon={<Users className="w-5 h-5" />}
          gradient="from-purple-500 to-pink-500"
          glow="rgba(168,85,247,0.3)"
        />
        <BigStat
          label="Total Savings"
          value={formatINR(exec.totalSavings)}
          icon={<Wallet className="w-5 h-5" />}
          gradient="from-emerald-500 to-green-600"
          glow="rgba(16,185,129,0.3)"
        />
        <BigStat
          label="Bank Loan"
          value={formatINR(exec.totalBankLoan)}
          icon={<Landmark className="w-5 h-5" />}
          gradient="from-blue-500 to-indigo-600"
          glow="rgba(59,130,246,0.3)"
        />
        <BigStat
          label="Private Loan"
          value={formatINR(exec.totalPrivateLoan)}
          icon={<HandCoins className="w-5 h-5" />}
          gradient="from-amber-500 to-orange-600"
          glow="rgba(245,158,11,0.3)"
        />
      </div>

      {/* Loan breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        <Card className="shadow-card-3d">
          <CardContent className="p-5">
            <div className="text-sm font-semibold flex items-center gap-2 mb-3">
              <Landmark className="w-4 h-4 text-blue-600" />
              Bank Loan Breakdown
            </div>
            <div className="space-y-2 text-sm">
              <ReportRow label="Total Loan" value={formatINR(exec.totalBankLoan)} />
              <ReportRow label="EMI Paid" value={formatINR(exec.totalBankLoanPaid)} color="text-green-600" />
              <ReportRow label="Interest Paid" value={formatINR(exec.totalBankInterest)} color="text-amber-600" />
              <div className="pt-2 border-t">
                <ReportRow label="Remaining" value={formatINR(exec.totalBankLoanRemaining)} bold color="text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="shadow-card-3d">
          <CardContent className="p-5">
            <div className="text-sm font-semibold flex items-center gap-2 mb-3">
              <HandCoins className="w-4 h-4 text-amber-600" />
              Private Loan Breakdown
            </div>
            <div className="space-y-2 text-sm">
              <ReportRow label="Total Disbursed" value={formatINR(exec.totalPrivateLoan)} />
              <ReportRow label="Repaid" value={formatINR(exec.totalPrivateLoanRepaid)} color="text-green-600" />
              <div className="pt-2 border-t">
                <ReportRow label="Outstanding" value={formatINR(exec.totalPrivateLoanRemaining)} bold color="text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Collection stats */}
      <Card className="shadow-card-3d bg-gradient-to-br from-primary/5 to-transparent border-primary/20">
        <CardContent className="p-5">
          <div className="text-sm font-semibold flex items-center gap-2 mb-4 text-primary">
            <TrendingUp className="w-4 h-4" />
            Collection Summary
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <CollectionStat label="आज (Today)" value={formatINR(exec.todayCollection)} />
            <CollectionStat label="इस सप्ताह (This Week)" value={formatINR(exec.weekCollection)} />
            <CollectionStat label="इस महीने (This Month)" value={formatINR(exec.monthCollection)} />
            <CollectionStat label="इस वर्ष (This Year)" value={formatINR(exec.yearCollection)} />
          </div>
        </CardContent>
      </Card>

      {/* This week's status */}
      <Card className="shadow-card-3d">
        <CardContent className="p-5">
          <div className="text-sm font-semibold flex items-center gap-2 mb-4">
            <CalendarCheck className="w-4 h-4 text-primary" />
            इस सप्ताह की स्थिति (This Week's Status)
            {exec.latestWeekDate && (
              <span className="text-xs text-muted-foreground font-normal ml-auto">
                {formatDate(exec.latestWeekDate)}
              </span>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <StatusCard
              label="जमा (Paid)"
              count={exec.paidMembers}
              amount={exec.paidThisWeek}
              icon={<CheckCircle2 className="w-5 h-5" />}
              color="green"
            />
            <StatusCard
              label="बकाया (Pending)"
              count={exec.pendingMembers}
              amount={exec.pendingThisWeek}
              icon={<Clock4 className="w-5 h-5" />}
              color="amber"
            />
            <StatusCard
              label="एडवांस (Advance)"
              count={exec.advanceMembers}
              amount={exec.advanceThisWeek}
              icon={<ArrowUpCircle className="w-5 h-5" />}
              color="blue"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

/* ===================== Weekly Collection Report ===================== */
function WeeklyCollectionReport({ data }: { data: ReportData }) {
  const wc = data.weeklyCollection
  const totalPaid = wc.filter((w) => w.status === 'paid').reduce((s, w) => s + w.amount, 0)
  const totalPending = wc.filter((w) => w.status === 'pending').length * data.executive.weeklySavingsPerMember
  const totalAdvance = wc.filter((w) => w.status === 'advance').reduce((s, w) => s + (w.amount - data.executive.weeklySavingsPerMember), 0)

  return (
    <div className="space-y-4">
      <Card className="shadow-card-3d">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-sm font-semibold flex items-center gap-2">
                <CalendarCheck className="w-4 h-4 text-primary" />
                साप्ताहिक कलेक्शन रिपोर्ट
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                बैठक तिथि: {data.executive.latestWeekDate ? formatDate(data.executive.latestWeekDate) : '—'}
              </div>
            </div>
          </div>

          {/* Summary chips */}
          <div className="flex items-center gap-2 flex-wrap mb-4">
            <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              जमा: {formatINR(totalPaid)}
            </Badge>
            <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-xs">
              <Clock4 className="w-3 h-3 mr-1" />
              बकाया: {formatINR(totalPending)}
            </Badge>
            <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 text-xs">
              <ArrowUpCircle className="w-3 h-3 mr-1" />
              एडवांस: {formatINR(totalAdvance)}
            </Badge>
          </div>

          {/* Member list */}
          <div className="space-y-2">
            {wc.map((w, i) => (
              <div
                key={i}
                className="flex items-center gap-3 p-3 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors premium-table-row"
              >
                <Avatar src={w.photoUrl} name={w.name} size={36} />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{w.name}</div>
                  <div className="text-[10px] text-muted-foreground font-mono">{w.memberCode}</div>
                </div>
                <div className="text-right">
                  {w.status === 'paid' && (
                    <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      {formatINR(w.amount)}
                    </Badge>
                  )}
                  {w.status === 'pending' && (
                    <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-xs">
                      <Clock4 className="w-3 h-3 mr-1" />
                      बकाया {formatINR(data.executive.weeklySavingsPerMember)}
                    </Badge>
                  )}
                  {w.status === 'advance' && (
                    <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 text-xs">
                      <ArrowUpCircle className="w-3 h-3 mr-1" />
                      एडवांस {formatINR(w.amount)}
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

/* ===================== Member Financial Report ===================== */
function MemberFinancialReport({ members }: { members: ReportData['memberReports'] }) {
  return (
    <Card className="shadow-card-3d overflow-hidden">
      <CardContent className="p-0">
        <div className="p-4 border-b">
          <div className="text-sm font-semibold flex items-center gap-2">
            <Table2 className="w-4 h-4 text-primary" />
            सदस्य वित्तीय रिपोर्ट (Member Financial Report)
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            हर सदस्य की कुल बचत, लोन, ब्याज, बकाया और एडवांस का विवरण
          </div>
        </div>
        <div className="overflow-x-auto scroll-area">
          <table className="w-full text-xs">
            <thead className="premium-table-header sticky top-0">
              <tr>
                <th className="text-left px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">सदस्य</th>
                <th className="text-right px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">बचत</th>
                <th className="text-right px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">बकाया</th>
                <th className="text-right px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">एडवांस</th>
                <th className="text-right px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">बैंक लोन</th>
                <th className="text-right px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">प्राइवेट लोन</th>
                <th className="text-right px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">ब्याज</th>
                <th className="text-right px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">अंतिम भुगतान</th>
              </tr>
            </thead>
            <tbody>
              {members.map((m, i) => (
                <tr key={m.memberId} className={`premium-table-row border-b ${i % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}`}>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <Avatar src={m.photoUrl} name={m.name} size={28} ring={false} />
                      <div>
                        <div className="font-medium">{m.name}</div>
                        <div className="text-[9px] text-muted-foreground font-mono">{m.memberId}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 text-right font-semibold text-green-700">{formatINR(m.totalSavings)}</td>
                  <td className="px-3 py-2.5 text-right">
                    {m.totalPending > 0 ? (
                      <span className="font-semibold text-red-600">{formatINR(m.totalPending)}</span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    {m.totalAdvance > 0 ? (
                      <span className="font-semibold text-blue-600">{formatINR(m.totalAdvance)}</span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <div className="font-medium">{formatINR(m.bankLoanTaken)}</div>
                    {m.bankLoanRemaining > 0 && (
                      <div className="text-[9px] text-red-500">शेष: {formatINR(m.bankLoanRemaining)}</div>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <div className="font-medium">{formatINR(m.privateLoanTaken)}</div>
                    {m.privateLoanRemaining > 0 && (
                      <div className="text-[9px] text-red-500">शेष: {formatINR(m.privateLoanRemaining)}</div>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-right text-amber-600">{formatINR(m.totalInterest)}</td>
                  <td className="px-3 py-2.5 text-right text-[10px] text-muted-foreground">
                    {m.lastPaymentDate ? formatDate(m.lastPaymentDate) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}

/* ===================== Pending Report ===================== */
function PendingReport({ members }: { members: ReportData['memberReports'] }) {
  const totalPending = members.reduce((s, m) => s + m.totalPending, 0)
  return (
    <Card className="shadow-card-3d">
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="text-sm font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600" />
            बकाया रिपोर्ट (Pending Report)
          </div>
          <Badge className="bg-red-100 text-red-700 hover:bg-red-100 text-xs">
            कुल बकाया: {formatINR(totalPending)}
          </Badge>
        </div>
        {members.length === 0 ? (
          <div className="text-center text-sm text-muted-foreground py-8">
            <CheckCircle2 className="w-10 h-10 mx-auto mb-2 text-green-500" />
            कोई बकाया नहीं है! सभी सदस्यों ने जमा किया है।
          </div>
        ) : (
          <div className="space-y-2">
            {members.map((m) => (
              <div key={m.memberId} className="flex items-center gap-3 p-3 rounded-xl bg-red-50/50 border border-red-100">
                <Avatar src={m.photoUrl} name={m.name} size={36} />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{m.name}</div>
                  <div className="text-[10px] text-muted-foreground">
                    {m.village || '—'} · अंतिम भुगतान: {m.lastPaymentDate ? formatDate(m.lastPaymentDate) : '—'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-red-600">{formatINR(m.totalPending)}</div>
                  <div className="text-[9px] text-muted-foreground">बकाया</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

/* ===================== Advance Report ===================== */
function AdvanceReport({ members }: { members: ReportData['memberReports'] }) {
  const totalAdvance = members.reduce((s, m) => s + m.totalAdvance, 0)
  return (
    <Card className="shadow-card-3d">
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="text-sm font-semibold flex items-center gap-2">
            <ArrowUpCircle className="w-4 h-4 text-blue-600" />
            एडवांस रिपोर्ट (Advance Deposit Report)
          </div>
          <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 text-xs">
            कुल एडवांस: {formatINR(totalAdvance)}
          </Badge>
        </div>
        {members.length === 0 ? (
          <div className="text-center text-sm text-muted-foreground py-8">
            <ArrowUpCircle className="w-10 h-10 mx-auto mb-2 opacity-30" />
            किसी सदस्य ने एडवांस जमा नहीं किया है।
          </div>
        ) : (
          <div className="space-y-2">
            {members.map((m) => (
              <div key={m.memberId} className="flex items-center gap-3 p-3 rounded-xl bg-blue-50/50 border border-blue-100">
                <Avatar src={m.photoUrl} name={m.name} size={36} />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{m.name}</div>
                  <div className="text-[10px] text-muted-foreground">
                    {m.village || '—'} · अंतिम भुगतान: {m.lastPaymentDate ? formatDate(m.lastPaymentDate) : '—'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-blue-600">{formatINR(m.totalAdvance)}</div>
                  <div className="text-[9px] text-muted-foreground">एडवांस</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

/* ===================== Helper Components ===================== */
function BigStat({
  label,
  value,
  icon,
  gradient,
  glow,
}: {
  label: string
  value: string
  icon: React.ReactNode
  gradient: string
  glow: string
}) {
  return (
    <div
      className="relative overflow-hidden rounded-2xl bg-white border border-border p-4"
      style={{ boxShadow: `0 4px 6px -1px rgba(0,0,0,0.05), 0 10px 30px -5px ${glow}` }}
    >
      <div className={`absolute -right-4 -top-4 w-20 h-20 rounded-full bg-gradient-to-br ${gradient} opacity-10 blur-2xl`} />
      <div className={`inline-flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br ${gradient} text-white shadow-lg mb-2`}>
        {icon}
      </div>
      <div className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide">{label}</div>
      <div className="text-xl font-bold text-foreground mt-0.5">{value}</div>
    </div>
  )
}

function ReportRow({
  label,
  value,
  bold,
  color,
}: {
  label: string
  value: string
  bold?: boolean
  color?: string
}) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-muted-foreground">{label}</span>
      <span className={`${bold ? 'font-bold' : 'font-medium'} ${color || ''}`}>{value}</span>
    </div>
  )
}

function CollectionStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-white/60 rounded-xl p-3 border border-primary/10">
      <div className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</div>
      <div className="text-lg font-bold text-primary mt-0.5">{value}</div>
    </div>
  )
}

function StatusCard({
  label,
  count,
  amount,
  icon,
  color,
}: {
  label: string
  count: number
  amount: number
  icon: React.ReactNode
  color: 'green' | 'amber' | 'blue'
}) {
  const colors = {
    green: 'bg-green-50 border-green-200 text-green-700',
    amber: 'bg-amber-50 border-amber-200 text-amber-700',
    blue: 'bg-blue-50 border-blue-200 text-blue-700',
  }
  return (
    <div className={`rounded-xl p-4 border ${colors[color]}`}>
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-sm font-semibold">{label}</span>
      </div>
      <div className="text-2xl font-bold">{count}</div>
      <div className="text-xs opacity-80">सदस्य</div>
      <div className="text-sm font-semibold mt-1">{formatINR(amount)}</div>
    </div>
  )
}

/* ===================== Charts Report ===================== */
function ChartsReport({ data }: { data: ReportData }) {
  const exec = data.executive
  // Weekly savings history data for chart
  const weeklyData = data.weeklySavingsHistory.reduce((acc: Record<string, { date: string; paid: number; pending: number; advance: number }>, entry) => {
    const dateKey = formatDate(entry.date)
    if (!acc[dateKey]) {
      acc[dateKey] = { date: dateKey, paid: 0, pending: 0, advance: 0 }
    }
    if (entry.status === 'paid') acc[dateKey].paid += entry.amount
    else if (entry.status === 'pending') acc[dateKey].pending += exec.weeklySavingsPerMember
    else if (entry.status === 'advance') acc[dateKey].advance += entry.amount - exec.weeklySavingsPerMember
    return acc
  }, {})
  const chartData = Object.values(weeklyData).reverse().slice(-8)

  // Top 5 members by savings
  const topSavers = [...data.memberReports].sort((a, b) => b.totalSavings - a.totalSavings).slice(0, 5)

  // Top 5 pending members
  const topPending = [...data.pendingReport].slice(0, 5)

  return (
    <div className="space-y-4">
      {/* Weekly Savings Chart */}
      <Card className="shadow-card-3d">
        <CardContent className="p-5">
          <div className="text-sm font-semibold flex items-center gap-2 mb-4">
            <CalendarCheck className="w-4 h-4 text-primary" />
            साप्ताहिक जमा बनाम बकाया बनाम एडवांस
          </div>
          {chartData.length > 0 ? (
            <div className="space-y-2">
              {chartData.map((d, i) => {
                const maxVal = Math.max(...chartData.map((x) => x.paid + x.pending + x.advance), 1)
                return (
                  <div key={i} className="space-y-1">
                    <div className="flex justify-between text-[10px] text-muted-foreground">
                      <span>{d.date}</span>
                      <span>कुल: {formatINR(d.paid + d.pending + d.advance)}</span>
                    </div>
                    <div className="flex h-6 rounded-lg overflow-hidden bg-muted/30">
                      {d.paid > 0 && (
                        <div className="bg-green-500 flex items-center justify-center text-[8px] text-white font-medium" style={{ width: `${(d.paid / maxVal) * 100}%` }}>
                          {d.paid > 20 ? formatINR(d.paid) : ''}
                        </div>
                      )}
                      {d.pending > 0 && (
                        <div className="bg-amber-500 flex items-center justify-center text-[8px] text-white font-medium" style={{ width: `${(d.pending / maxVal) * 100}%` }}>
                          {d.pending > 20 ? formatINR(d.pending) : ''}
                        </div>
                      )}
                      {d.advance > 0 && (
                        <div className="bg-blue-500 flex items-center justify-center text-[8px] text-white font-medium" style={{ width: `${(d.advance / maxVal) * 100}%` }}>
                          {d.advance > 20 ? formatINR(d.advance) : ''}
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}
              <div className="flex items-center gap-3 text-[10px] mt-3">
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-green-500" />जमा</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-amber-500" />बकाया</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-blue-500" />एडवांस</span>
              </div>
            </div>
          ) : (
            <div className="text-center text-xs text-muted-foreground py-6">कोई डेटा नहीं</div>
          )}
        </CardContent>
      </Card>

      {/* Top 5 Savers */}
      <Card className="shadow-card-3d">
        <CardContent className="p-5">
          <div className="text-sm font-semibold flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-green-600" />
            सबसे अधिक बचत करने वाले सदस्य (Top 5)
          </div>
          <div className="space-y-2">
            {topSavers.map((m, i) => {
              const maxSavings = topSavers[0]?.totalSavings || 1
              return (
                <div key={m.memberId} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-bold text-primary shrink-0">{i + 1}</div>
                  <Avatar src={m.photoUrl} name={m.name} size={28} ring={false} />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium truncate">{m.name}</div>
                    <div className="h-2 rounded-full bg-muted/30 mt-1 overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full" style={{ width: `${(m.totalSavings / maxSavings) * 100}%` }} />
                    </div>
                  </div>
                  <div className="text-xs font-bold text-green-600 shrink-0">{formatINR(m.totalSavings)}</div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Top 5 Pending */}
      {topPending.length > 0 && (
        <Card className="shadow-card-3d">
          <CardContent className="p-5">
            <div className="text-sm font-semibold flex items-center gap-2 mb-4">
              <AlertCircle className="w-4 h-4 text-red-600" />
              सबसे अधिक बकाया वाले सदस्य (Top 5)
            </div>
            <div className="space-y-2">
              {topPending.map((m, i) => {
                const maxPending = topPending[0]?.totalPending || 1
                return (
                  <div key={m.memberId} className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center text-[10px] font-bold text-red-600 shrink-0">{i + 1}</div>
                    <Avatar src={m.photoUrl} name={m.name} size={28} ring={false} />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-medium truncate">{m.name}</div>
                      <div className="h-2 rounded-full bg-muted/30 mt-1 overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-red-500 to-amber-500 rounded-full" style={{ width: `${(m.totalPending / maxPending) * 100}%` }} />
                      </div>
                    </div>
                    <div className="text-xs font-bold text-red-600 shrink-0">{formatINR(m.totalPending)}</div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loan Distribution */}
      <Card className="shadow-card-3d">
        <CardContent className="p-5">
          <div className="text-sm font-semibold flex items-center gap-2 mb-4">
            <HandCoins className="w-4 h-4 text-amber-600" />
            लोन वितरण (Loan Distribution)
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl bg-blue-50 border border-blue-100 p-4 text-center">
              <div className="text-[10px] text-blue-600 uppercase tracking-wide">बैंक लोन</div>
              <div className="text-xl font-bold text-blue-700">{formatINR(exec.totalBankLoan)}</div>
              <div className="text-[10px] text-muted-foreground mt-1">चुकाया: {formatINR(exec.totalBankLoanPaid)}</div>
              <div className="text-[10px] text-red-600">शेष: {formatINR(exec.totalBankLoanRemaining)}</div>
            </div>
            <div className="rounded-xl bg-amber-50 border border-amber-100 p-4 text-center">
              <div className="text-[10px] text-amber-600 uppercase tracking-wide">प्राइवेट लोन</div>
              <div className="text-xl font-bold text-amber-700">{formatINR(exec.totalPrivateLoan)}</div>
              <div className="text-[10px] text-muted-foreground mt-1">चुकाया: {formatINR(exec.totalPrivateLoanRepaid)}</div>
              <div className="text-[10px] text-red-600">शेष: {formatINR(exec.totalPrivateLoanRemaining)}</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
