'use client'

import { useEffect, useState, useMemo } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Avatar } from '@/components/shg/avatar'
import { useToast } from '@/hooks/use-toast'
import { useAppStore } from '@/lib/store'
import { formatINR, formatDate, toISODate, formatTimeIST } from '@/lib/format'
import {
  Landmark,
  HandCoins,
  Plus,
  Pencil,
  Loader2,
  Calendar,
  Clock,
  IndianRupee,
  Receipt,
  FileText,
  TrendingDown,
  CheckCircle2,
  X,
} from 'lucide-react'

interface Member { id: string; name: string; memberCode: string; photoUrl: string | null }
interface LoanPayment {
  id: string
  memberId: string
  loanType: string
  loanId: string
  paymentDate: string
  paymentTime: string | null
  amount: number
  principal: number
  interest: number
  remainingBalance: number
  paymentMode: string
  receiptNo: string | null
  remarks: string | null
  member: Member
}

export function LoanPaymentTracker() {
  const [payments, setPayments] = useState<LoanPayment[]>([])
  const [members, setMembers] = useState<Member[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterType, setFilterType] = useState<'all' | 'bank' | 'private'>('all')
  const [filterMember, setFilterMember] = useState<string>('all')
  const [refreshKey, setRefreshKey] = useState(0)
  const [addOpen, setAddOpen] = useState(false)
  const admin = useAppStore((s) => s.admin)

  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const [pRes, mRes] = await Promise.all([
          fetch('/api/loan-payments', { cache: 'no-store' }),
          fetch('/api/members', { cache: 'no-store' }),
        ])
        const [p, m] = await Promise.all([pRes.json(), mRes.json()])
        if (mounted) {
          if (p.ok) setPayments(p.payments)
          if (m.ok) setMembers(m.members.map((x: Member) => ({ id: x.id, name: x.name, memberCode: x.memberCode, photoUrl: x.photoUrl })))
        }
      } catch { /* swallow */ } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
  }, [refreshKey])

  const filtered = useMemo(() => {
    return payments.filter((p) => {
      const q = search.toLowerCase().trim()
      const matchesSearch =
        !q ||
        p.member.name.toLowerCase().includes(q) ||
        p.member.memberCode.toLowerCase().includes(q) ||
        (p.receiptNo || '').toLowerCase().includes(q)
      const matchesType = filterType === 'all' || p.loanType === filterType
      const matchesMember = filterMember === 'all' || p.memberId === filterMember
      return matchesSearch && matchesType && matchesMember
    })
  }, [payments, search, filterType, filterMember])

  // Summary calculations
  const bankPayments = filtered.filter((p) => p.loanType === 'bank')
  const privatePayments = filtered.filter((p) => p.loanType === 'private')
  const totalBankPaid = bankPayments.reduce((s, p) => s + p.amount, 0)
  const totalBankInterest = bankPayments.reduce((s, p) => s + p.interest, 0)
  const totalPrivatePaid = privatePayments.reduce((s, p) => s + p.amount, 0)
  const totalPrivateInterest = privatePayments.reduce((s, p) => s + p.interest, 0)
  const totalPaid = filtered.reduce((s, p) => s + p.amount, 0)
  const totalInterest = filtered.reduce((s, p) => s + p.interest, 0)

  return (
    <div className="space-y-4">
      {/* Title + Add button */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-baseline gap-2 flex-wrap">
          <h3 className="text-base font-semibold">Loan Payment Tracker</h3>
          <span className="text-sm text-muted-foreground">
            ({filtered.length} payments · {formatINR(totalPaid)} total)
          </span>
        </div>
        {admin && (
          <PaymentFormDialog
            open={addOpen}
            setOpen={setAddOpen}
            members={members}
            onSaved={() => {
              setAddOpen(false)
              setRefreshKey((k) => k + 1)
            }}
          >
            <Button size="sm" className="h-9 premium-button text-white font-semibold">
              <Plus className="w-4 h-4" />
              Add Payment
            </Button>
          </PaymentFormDialog>
        )}
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <SummaryCard label="Bank EMI Paid" value={formatINR(totalBankPaid)} icon={<Landmark className="w-4 h-4" />} gradient="from-blue-500 to-indigo-600" />
        <SummaryCard label="Bank Interest" value={formatINR(totalBankInterest)} icon={<TrendingDown className="w-4 h-4" />} gradient="from-cyan-500 to-blue-500" />
        <SummaryCard label="Private Paid" value={formatINR(totalPrivatePaid)} icon={<HandCoins className="w-4 h-4" />} gradient="from-amber-500 to-orange-600" />
        <SummaryCard label="Private Interest" value={formatINR(totalPrivateInterest)} icon={<TrendingDown className="w-4 h-4" />} gradient="from-orange-500 to-red-500" />
      </div>

      {/* Search + filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[180px]">
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="सदस्य, आईडी, रसीद संख्या से खोजें..."
            className="premium-input h-9"
          />
        </div>
        <Select value={filterType} onValueChange={(v) => setFilterType(v as 'all' | 'bank' | 'private')}>
          <SelectTrigger className="w-[130px] h-9 premium-input">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="bank">Bank Loan</SelectItem>
            <SelectItem value="private">Private Loan</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterMember} onValueChange={setFilterMember}>
          <SelectTrigger className="w-[150px] h-9 premium-input">
            <SelectValue placeholder="सदस्य" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Members</SelectItem>
            {members.map((m) => (
              <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Payment history table */}
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 bg-muted/60 animate-pulse rounded-lg" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            <Receipt className="w-10 h-10 mx-auto mb-3 opacity-30" />
            कोई भुगतान रिकॉर्ड नहीं मिला।
          </CardContent>
        </Card>
      ) : (
        <Card className="shadow-card-3d overflow-hidden">
          <CardContent className="p-0">
            <div className="overflow-x-auto scroll-area">
              <table className="w-full text-xs">
                <thead className="premium-table-header sticky top-0">
                  <tr>
                    <th className="text-left px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">तिथि / समय</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">सदस्य</th>
                    <th className="text-center px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">प्रकार</th>
                    <th className="text-right px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">राशि</th>
                    <th className="text-right px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">मूलधन</th>
                    <th className="text-right px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">ब्याज</th>
                    <th className="text-right px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">शेष</th>
                    <th className="text-center px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">मोड</th>
                    <th className="text-left px-3 py-2.5 font-semibold text-slate-700 whitespace-nowrap">रसीद</th>
                    {admin && <th className="text-right px-3 py-2.5 font-semibold text-slate-700">क्रिया</th>}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((p, i) => (
                    <tr key={p.id} className={`premium-table-row border-b ${i % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}`}>
                      <td className="px-3 py-2.5 text-muted-foreground whitespace-nowrap">
                        <div>{formatDate(p.paymentDate)}</div>
                        {p.paymentTime && (
                          <div className="text-[9px] text-blue-600 flex items-center gap-0.5">
                            <Clock className="w-2.5 h-2.5" />
                            {p.paymentTime}
                          </div>
                        )}
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-2">
                          <Avatar src={p.member.photoUrl} name={p.member.name} size={24} ring={false} />
                          <div>
                            <div className="font-medium">{p.member.name}</div>
                            <div className="text-[9px] text-muted-foreground font-mono">{p.member.memberCode}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        {p.loanType === 'bank' ? (
                          <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 text-[10px]">
                            <Landmark className="w-2.5 h-2.5 mr-0.5" /> Bank
                          </Badge>
                        ) : (
                          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-[10px]">
                            <HandCoins className="w-2.5 h-2.5 mr-0.5" /> Private
                          </Badge>
                        )}
                      </td>
                      <td className="px-3 py-2.5 text-right font-bold text-green-700">{formatINR(p.amount)}</td>
                      <td className="px-3 py-2.5 text-right text-muted-foreground">{formatINR(p.principal)}</td>
                      <td className="px-3 py-2.5 text-right text-amber-600">{formatINR(p.interest)}</td>
                      <td className="px-3 py-2.5 text-right font-semibold text-red-600">{formatINR(p.remainingBalance)}</td>
                      <td className="px-3 py-2.5 text-center">
                        <Badge variant="outline" className="text-[9px]">{p.paymentMode}</Badge>
                      </td>
                      <td className="px-3 py-2.5 text-[10px] font-mono text-muted-foreground">{p.receiptNo || '—'}</td>
                      {admin && (
                        <td className="px-3 py-2.5 text-right">
                          <EditPaymentButton
                            payment={p}
                            onSaved={() => setRefreshKey((k) => k + 1)}
                          />
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                {/* Total row */}
                <tr className="bg-primary/5 border-t-2 border-primary/20 font-bold">
                  <td colSpan={3} className="px-3 py-2.5 text-right text-primary">कुल (Total):</td>
                  <td className="px-3 py-2.5 text-right text-green-700">{formatINR(totalPaid)}</td>
                  <td className="px-3 py-2.5 text-right text-muted-foreground">{formatINR(filtered.reduce((s, p) => s + p.principal, 0))}</td>
                  <td className="px-3 py-2.5 text-right text-amber-600">{formatINR(totalInterest)}</td>
                  <td colSpan={admin ? 4 : 3} className="px-3 py-2.5"></td>
                </tr>
                </tfoot>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

/* ===================== Edit Payment Button ===================== */
function EditPaymentButton({
  payment,
  onSaved,
}: {
  payment: LoanPayment
  onSaved: () => void
}) {
  const { toast } = useToast()
  const [open, setOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [amount, setAmount] = useState(String(payment.amount))
  const [interest, setInterest] = useState(String(payment.interest))
  const [paymentDate, setPaymentDate] = useState(toISODate(payment.paymentDate))
  const [paymentTime, setPaymentTime] = useState(payment.paymentTime || '')
  const [paymentMode, setPaymentMode] = useState(payment.paymentMode)
  const [remarks, setRemarks] = useState(payment.remarks || '')

  const principal = (() => {
    const amt = Number(amount) || 0
    const intr = Number(interest) || 0
    return Math.max(0, amt - intr)
  })()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      const res = await fetch(`/api/loan-payments/${payment.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paymentDate,
          paymentTime: paymentTime || null,
          amount: Number(amount),
          principal,
          interest: Number(interest) || 0,
          paymentMode,
          remarks: remarks || null,
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'अपडेट विफल', variant: 'destructive' })
        return
      }
      setOpen(false)
      onSaved()
      toast({ title: 'भुगतान अपडेट हुआ' })
    } catch {
      toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        className="h-7 w-7 text-blue-600 hover:text-blue-700"
        onClick={() => setOpen(true)}
        aria-label="Edit payment"
      >
        <Pencil className="w-3.5 h-3.5" />
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="premium-dialog p-0 overflow-hidden border-0 sm:max-w-[420px] max-h-[90vh] overflow-y-auto">
          <div className="premium-dialog-header bg-gradient-to-br from-primary via-[oklch(0.4_0.14_150)] to-[oklch(0.35_0.12_160)] px-5 py-4">
            <div className="relative flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shrink-0 shadow-lg">
                <Pencil className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <DialogTitle className="text-base font-bold text-white">
                  भुगतान संपादित करें
                </DialogTitle>
                <DialogDescription className="text-xs text-white/80 mt-0.5">
                  {payment.member.name} · {payment.loanType === 'bank' ? '🏦 बैंक लोन' : '💰 प्राइवेट लोन'}
                </DialogDescription>
              </div>
            </div>
          </div>
          <form onSubmit={handleSubmit} className="p-5 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label className="text-xs font-medium">तिथि</Label>
                <Input type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} className="premium-input h-9" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-medium">समय</Label>
                <Input type="time" value={paymentTime} onChange={(e) => setPaymentTime(e.target.value)} className="premium-input h-9" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label className="text-xs font-medium">राशि (₹)</Label>
                <Input type="number" min={0} value={amount} onChange={(e) => setAmount(e.target.value)} className="premium-input h-9" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-medium">ब्याज (₹)</Label>
                <Input type="number" min={0} value={interest} onChange={(e) => setInterest(e.target.value)} className="premium-input h-9" />
              </div>
            </div>
            <div className="rounded-lg bg-blue-50 border border-blue-100 p-2 text-xs">
              <span className="text-blue-600">मूलधन (auto): </span>
              <span className="font-bold text-blue-700">{formatINR(principal)}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label className="text-xs font-medium">मोड</Label>
                <Select value={paymentMode} onValueChange={setPaymentMode}>
                  <SelectTrigger className="premium-input h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">नकद</SelectItem>
                    <SelectItem value="bank">बैंक</SelectItem>
                    <SelectItem value="upi">UPI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-medium">टिप्पणी</Label>
                <Input value={remarks} onChange={(e) => setRemarks(e.target.value)} className="premium-input h-9" />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
              <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={submitting} className="press-effect h-9">
                <X className="w-3.5 h-3.5" /> रद्द
              </Button>
              <Button type="submit" disabled={submitting} className="premium-button text-white font-semibold h-9">
                {submitting ? '...' : 'अपडेट करें'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  )
}

/* ===================== Summary Card ===================== */
function SummaryCard({
  label,
  value,
  icon,
  gradient,
}: {
  label: string
  value: string
  icon: React.ReactNode
  gradient: string
}) {
  return (
    <div className="relative overflow-hidden rounded-xl bg-white border border-border p-3.5" style={{ boxShadow: '0 2px 4px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.06)' }}>
      <div className={`absolute -right-3 -top-3 w-14 h-14 rounded-full bg-gradient-to-br ${gradient} opacity-10 blur-xl`} />
      <div className="relative">
        <div className={`inline-flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br ${gradient} text-white shadow-sm mb-2`}>
          {icon}
        </div>
        <div className="text-[11px] text-muted-foreground font-medium">{label}</div>
        <div className="text-base font-bold text-foreground mt-0.5">{value}</div>
      </div>
    </div>
  )
}

/* ===================== Payment Form Dialog ===================== */
function PaymentFormDialog({
  open,
  setOpen,
  members,
  onSaved,
  children,
}: {
  open: boolean
  setOpen: (v: boolean) => void
  members: Member[]
  onSaved: () => void
  children: React.ReactNode
}) {
  const { toast } = useToast()
  const [submitting, setSubmitting] = useState(false)
  const [memberId, setMemberId] = useState('')
  const [loanType, setLoanType] = useState<'bank' | 'private'>('bank')
  const [paymentDate, setPaymentDate] = useState(toISODate(new Date()))
  const [paymentTime, setPaymentTime] = useState(formatTimeIST())
  const [amount, setAmount] = useState('')
  const [principal, setPrincipal] = useState('')
  const [interest, setInterest] = useState('')
  const [remainingBalance, setRemainingBalance] = useState('')
  const [paymentMode, setPaymentMode] = useState('cash')
  const [receiptNo, setReceiptNo] = useState('')
  const [remarks, setRemarks] = useState('')

  // Auto-calculate principal from amount - interest
  useEffect(() => {
    const amt = Number(amount) || 0
    const intr = Number(interest) || 0
    if (amt > 0) {
      setPrincipal(String(Math.max(0, amt - intr)))
    }
  }, [amount, interest])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!memberId || !amount || !paymentDate) {
      toast({ title: 'सदस्य, राशि और तिथि आवश्यक हैं', variant: 'destructive' })
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/loan-payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          memberId,
          loanType,
          loanId: '',
          paymentDate,
          paymentTime,
          amount: Number(amount),
          principal: Number(principal) || 0,
          interest: Number(interest) || 0,
          remainingBalance: Number(remainingBalance) || 0,
          paymentMode,
          receiptNo: receiptNo || null,
          remarks: remarks || null,
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'सहेजने में विफल', variant: 'destructive' })
        return
      }
      // Reset
      setMemberId('')
      setAmount('')
      setPrincipal('')
      setInterest('')
      setRemainingBalance('')
      setReceiptNo('')
      setRemarks('')
      onSaved()
    } catch {
      toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="premium-dialog p-0 overflow-hidden border-0 sm:max-w-[480px] max-h-[90vh] overflow-y-auto">
        <div className="premium-dialog-header bg-gradient-to-br from-primary via-[oklch(0.4_0.14_150)] to-[oklch(0.35_0.12_160)] px-5 py-4 sm:px-6 sm:py-5">
          <div className="relative flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shrink-0 shadow-lg">
              <Receipt className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <DialogTitle className="text-base sm:text-lg font-bold text-white leading-tight">
                नया भुगतान जोड़ें
              </DialogTitle>
              <DialogDescription className="text-xs text-white/80 mt-1">
                लोन EMI या चुकौती का भुगतान दर्ज करें (तिथि, राशि, ब्याज, शेष के साथ)
              </DialogDescription>
            </div>
          </div>
        </div>
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          {/* Member + Loan Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">सदस्य *</Label>
              <Select value={memberId} onValueChange={setMemberId}>
                <SelectTrigger className="premium-input h-10"><SelectValue placeholder="सदस्य चुनें" /></SelectTrigger>
                <SelectContent>
                  {members.map((m) => (
                    <SelectItem key={m.id} value={m.id}>{m.name} ({m.memberCode})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">लोन प्रकार *</Label>
              <Select value={loanType} onValueChange={(v) => setLoanType(v as 'bank' | 'private')}>
                <SelectTrigger className="premium-input h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="bank">🏦 बैंक लोन (EMI)</SelectItem>
                  <SelectItem value="private">💰 प्राइवेट लोन</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Date + Time + Amount */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">तिथि *</Label>
              <Input type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} required className="premium-input h-10" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">समय</Label>
              <Input type="time" value={paymentTime} onChange={(e) => setPaymentTime(e.target.value)} className="premium-input h-10" />
            </div>
            <div className="space-y-1.5 col-span-2 sm:col-span-1">
              <Label className="text-xs font-medium">कुल राशि (₹) *</Label>
              <Input type="number" min={0} value={amount} onChange={(e) => setAmount(e.target.value)} required placeholder="2500" className="premium-input h-10" />
            </div>
          </div>

          {/* Principal + Interest (auto-calc) */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">मूलधन (Principal)</Label>
              <Input type="number" min={0} value={principal} onChange={(e) => setPrincipal(e.target.value)} placeholder="2200" className="premium-input h-10" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">ब्याज (Interest)</Label>
              <Input type="number" min={0} value={interest} onChange={(e) => setInterest(e.target.value)} placeholder="300" className="premium-input h-10" />
            </div>
          </div>

          {/* Remaining balance + payment mode */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">शेष राशि (Remaining)</Label>
              <Input type="number" min={0} value={remainingBalance} onChange={(e) => setRemainingBalance(e.target.value)} placeholder="12500" className="premium-input h-10" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">भुगतान मोड</Label>
              <Select value={paymentMode} onValueChange={setPaymentMode}>
                <SelectTrigger className="premium-input h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">नकद (Cash)</SelectItem>
                  <SelectItem value="bank">बैंक (Bank)</SelectItem>
                  <SelectItem value="upi">UPI</SelectItem>
                  <SelectItem value="cheque">चेक (Cheque)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Receipt No + Remarks */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">रसीद संख्या</Label>
              <Input value={receiptNo} onChange={(e) => setReceiptNo(e.target.value)} placeholder="RCP-001" className="premium-input h-10 font-mono" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">टिप्पणी</Label>
              <Input value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="EMI भुगतान" className="premium-input h-10" />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={submitting} className="press-effect h-10">
              रद्द करें
            </Button>
            <Button type="submit" disabled={submitting} className="premium-button text-white font-semibold h-10">
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {submitting ? 'सहेज रहे हैं...' : 'भुगतान जोड़ें'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
