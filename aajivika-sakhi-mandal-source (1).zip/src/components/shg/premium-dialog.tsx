'use client'

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
  DialogClose,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { X, Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils'

interface PremiumDialogProps {
  open?: boolean
  onOpenChange?: (v: boolean) => void
  trigger?: React.ReactNode
  title: string
  description?: string
  icon?: React.ReactNode
  /** Accent gradient for the header background */
  gradient?: string
  footer?: React.ReactNode
  children: React.ReactNode
  className?: string
}

/**
 * Premium 3D dialog wrapper.
 * - Glassmorphism backdrop blur
 * - Gradient header with decorative blob + 3D icon badge
 * - Slide-up entrance animation
 * - Layered 3D card shadow
 */
export function PremiumDialog({
  open,
  onOpenChange,
  trigger,
  title,
  description,
  icon,
  gradient = 'from-primary via-[oklch(0.4_0.14_150)] to-[oklch(0.35_0.12_160)]',
  footer,
  children,
  className,
}: PremiumDialogProps) {
  const content = (
    <DialogContent
      className={cn(
        'premium-dialog p-0 overflow-hidden border-0 max-h-[90vh] overflow-y-auto',
        className
      )}
    >
      {/* Gradient header */}
      <div className={cn('premium-dialog-header bg-gradient-to-br px-5 py-4 sm:px-6 sm:py-5', gradient)}>
        <div className="relative flex items-start gap-3">
          {icon && (
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shrink-0 shadow-lg">
              {icon}
            </div>
          )}
          <div className="flex-1 min-w-0">
            <DialogTitle className="text-base sm:text-lg font-bold text-white leading-tight">
              {title}
            </DialogTitle>
            {description && (
              <DialogDescription className="text-xs text-white/80 mt-1 leading-relaxed">
                {description}
              </DialogDescription>
            )}
          </div>
        </div>
      </div>
      {/* Body */}
      <div className="p-5 sm:p-6">{children}</div>
      {/* Footer */}
      {footer && (
        <div className="px-5 sm:px-6 pb-5 sm:pb-6 pt-2 border-t border-border/50 bg-muted/20">
          {footer}
        </div>
      )}
    </DialogContent>
  )

  if (trigger !== undefined) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogTrigger asChild>{trigger}</DialogTrigger>
        {content}
      </Dialog>
    )
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      {content}
    </Dialog>
  )
}

/**
 * Premium submit button with 3D gradient + press effect.
 */
export function PremiumSubmitButton({
  children,
  submitting,
  submittingLabel,
  disabled,
}: {
  children: React.ReactNode
  submitting?: boolean
  submittingLabel?: string
  disabled?: boolean
}) {
  return (
    <Button
      type="submit"
      disabled={disabled || submitting}
      className="premium-button text-white font-semibold"
    >
      {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
      {submitting ? submittingLabel || 'Saving…' : children}
    </Button>
  )
}

/**
 * Premium cancel button — outline style.
 */
export function PremiumCancelButton({
  children,
  onClick,
  disabled,
}: {
  children: React.ReactNode
  onClick: () => void
  disabled?: boolean
}) {
  return (
    <Button
      type="button"
      variant="outline"
      onClick={onClick}
      disabled={disabled}
      className="press-effect"
    >
      {children}
    </Button>
  )
}

/**
 * Premium section label — uppercase tracked text with optional icon.
 */
export function PremiumSectionLabel({
  icon,
  children,
}: {
  icon?: React.ReactNode
  children: React.ReactNode
}) {
  return (
    <div className="premium-section-label">
      {icon}
      {children}
    </div>
  )
}

export { DialogClose }
