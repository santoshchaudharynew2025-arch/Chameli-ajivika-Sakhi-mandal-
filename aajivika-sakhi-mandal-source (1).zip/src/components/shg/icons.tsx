'use client'

import { useEffect, useState } from 'react'

// A simple "lotus" SVG logo placeholder representing the SHG.
export function LotusIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 64 64"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden
    >
      {/* Outer petals */}
      <path
        d="M32 6 C 36 18, 44 24, 52 28 C 50 36, 44 44, 32 50 C 20 44, 14 36, 12 28 C 20 24, 28 18, 32 6 Z"
        fill="currentColor"
        opacity="0.35"
      />
      {/* Middle petals */}
      <path
        d="M32 12 C 34 20, 38 26, 44 30 C 42 36, 38 42, 32 46 C 26 42, 22 36, 20 30 C 26 26, 30 20, 32 12 Z"
        fill="currentColor"
        opacity="0.6"
      />
      {/* Inner petal */}
      <path
        d="M32 18 C 33 24, 35 28, 38 32 C 36 36, 34 40, 32 42 C 30 40, 28 36, 26 32 C 29 28, 31 24, 32 18 Z"
        fill="currentColor"
      />
      {/* Base line */}
      <path
        d="M14 50 Q 32 56 50 50"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        opacity="0.7"
      />
    </svg>
  )
}

// Checks if the database is reachable via our dashboard API.
export async function db_connected(): Promise<'connecting' | 'connected'> {
  try {
    const res = await fetch('/api/dashboard', { cache: 'no-store' })
    if (res.ok) return 'connected'
  } catch {
    /* fallthrough */
  }
  return 'connecting'
}

// Small live "DB connected" poller used by login screen.
export function useDbStatus() {
  const [status, setStatus] = useState<'connecting' | 'connected'>('connecting')
  useEffect(() => {
    let mounted = true
    const check = async () => {
      const s = await db_connected()
      if (mounted) setStatus(s)
    }
    check()
    const id = setInterval(check, 8000)
    return () => {
      mounted = false
      clearInterval(id)
    }
  }, [])
  return status
}
