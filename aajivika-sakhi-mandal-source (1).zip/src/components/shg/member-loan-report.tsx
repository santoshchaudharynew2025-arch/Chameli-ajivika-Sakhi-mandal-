'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar } from '@/components/shg/avatar'
import { formatINR, formatDate, toISODate, formatTimeIST } from '@/lib/format'
import {
  Dialog, DialogContent, DialogTitle, DialogDescription,
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Landmark, HandCoins, CheckCircle2, Clock4, Receipt, FileText,
  Printer, IndianRupee, Calendar, Clock, X, Loader2,
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Member {
  id: string; memberCode: string; name: string; guardianName: string | null
  post: string; phone: string | null; village: string | null; district: string | null
  photoUrl: string | null; joiningDate: string
  bankName: string | null; accountNo: string | null; ifscCode: string | null
}

interface BankLoanData {
  id: string; bankLoanShare: number; emiPaid: number; interestPaid: number
  interestRate: number; paymentDate: string | null; bankName: string | null
}

interface PrivateLoanData {
  id: string; loanAmount: number; interestRate: number; disbursementDate: string
  repaymentAmount: number; repaymentDate: string | null
}

interface LoanPaymentData {
  id: string; loanType: string; paymentDate: string; paymentTime: string | null
  amount: number; principal: number; interest: number; remainingBalance: number
  paymentMode: string; receiptNo: string | null; remarks: string | null
}

// Unified loan item — combines bank + private into one list
interface UnifiedLoan {
  loanId: string
  loanType: 'bank' | 'private'
  loanAmount: number
  interestRate: number
  disbursedDate: string
  paidSoFar: number
  interestPaid: number
  remaining: number
  isCompleted: boolean
  bankName: string | null
  payments: LoanPaymentData[]
}

interface MemberLoanReportProps {
  member: Member | null
  open: boolean
  onOpenChange: (v: boolean) => void
}

export function MemberLoanReport({ member, open, onOpenChange }: MemberLoanReportProps) {
  const [bankLoans, setBankLoans] = useState<BankLoanData[]>([])
  const [privateLoans, setPrivateLoans] = useState<PrivateLoanData[]>([])
  const [payments, setPayments] = useState<LoanPaymentData[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshKey, setRefreshKey] = useState(0)
  const { toast } = useToast()

  useEffect(() => {
    if (!member || !open) return
    let mounted = true
    const load = async () => {
      setLoading(true)
      try {
        const [blRes, plRes, pRes] = await Promise.all([
          fetch('/api/loans/bank', { cache: 'no-store' }),
          fetch('/api/loans/private', { cache: 'no-store' }),
          fetch(`/api/loan-payments?memberId=${member.id}`, { cache: 'no-store' }),
        ])
        const [bl, pl, p] = await Promise.all([blRes.json(), plRes.json(), pRes.json()])
        if (mounted) {
          setBankLoans((bl.loans || []).filter((l: { memberId: string }) => l.memberId === member.id))
          setPrivateLoans((pl.loans || []).filter((l: { memberId: string }) => l.memberId === member.id))
          setPayments(p.payments || [])
        }
      } catch { /* swallow */ } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
  }, [member, open, refreshKey])

  if (!member) return null

  // Build unified loan list
  const unifiedLoans: UnifiedLoan[] = [
    ...bankLoans.map((bl): UnifiedLoan => {
      const loanPayments = payments.filter((p) => p.loanType === 'bank' && p.loanId === bl.id)
      return {
        loanId: bl.id, loanType: 'bank', loanAmount: bl.bankLoanShare,
        interestRate: bl.interestRate || 0,
        disbursedDate: bl.paymentDate || new Date().toISOString(),
        paidSoFar: bl.emiPaid, interestPaid: bl.interestPaid,
        remaining: Math.max(0, bl.bankLoanShare - bl.emiPaid),
        isCompleted: bl.bankLoanShare - bl.emiPaid <= 0,
        bankName: bl.bankName, payments: loanPayments,
      }
    }),
    ...privateLoans.map((pl): UnifiedLoan => {
      const loanPayments = payments.filter((p) => p.loanType === 'private' && (p.loanId === pl.id || p.loanId.includes(pl.id.slice(-6))))
      return {
        loanId: pl.id, loanType: 'private', loanAmount: pl.loanAmount,
        interestRate: pl.interestRate || 0,
        disbursedDate: pl.disbursementDate,
        paidSoFar: pl.repaymentAmount, interestPaid: loanPayments.reduce((s, p) => s + p.interest, 0),
        remaining: Math.max(0, pl.loanAmount - pl.repaymentAmount),
        isCompleted: pl.loanAmount - pl.repaymentAmount <= 0,
        bankName: null, payments: loanPayments,
      }
    }),
  ].sort((a, b) => new Date(b.disbursedDate).getTime() - new Date(a.disbursedDate).getTime())

  // Totals
  const totalLoanTaken = unifiedLoans.reduce((s, l) => s + l.loanAmount, 0)
  const totalPaid = unifiedLoans.reduce((s, l) => s + l.paidSoFar, 0)
  const totalInterest = unifiedLoans.reduce((s, l) => s + l.interestPaid, 0)
  const totalRemaining = unifiedLoans.reduce((s, l) => s + l.remaining, 0)
  const activeLoans = unifiedLoans.filter((l) => !l.isCompleted).length
  const closedLoans = unifiedLoans.filter((l) => l.isCompleted).length

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="premium-dialog p-0 overflow-hidden border-0 sm:max-w-[680px] max-h-[90vh] overflow-y-auto">
        {/* Gradient header */}
        <div className="premium-dialog-header bg-gradient-to-br from-primary via-[oklch(0.4_0.14_150)] to-[oklch(0.35_0.12_160)] px-5 py-5 sm:px-6 sm:py-6">
          <div className="relative flex items-center gap-4">
            <div className="shrink-0">
              {member.photoUrl ? (
                <div className="w-16 h-16 rounded-2xl overflow-hidden ring-4 ring-white/40 shadow-2xl">
                  <img src={member.photoUrl} alt={member.name} className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-md border-2 border-white/40 flex items-center justify-center shadow-2xl">
                  <Avatar name={member.name} size={32} ring={false} />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <DialogTitle className="text-lg font-bold text-white leading-tight">
                लोन रिपोर्ट — {member.name}
              </DialogTitle>
              <DialogDescription className="text-xs text-white/80 mt-1 font-mono">
                सदस्य आईडी: {member.memberCode} · {member.post}
              </DialogDescription>
              <div className="text-[10px] text-white/60 mt-0.5">
                पूरा लोन विवरण — बैंक + प्राइवेट लोन एक साथ
              </div>
            </div>
            <Button size="sm" variant="secondary" className="bg-white/20 backdrop-blur-md text-white border-white/30 hover:bg-white/30 press-effect shrink-0" onClick={() => window.print()}>
              <Printer className="w-3.5 h-3.5" />PDF
            </Button>
          </div>
        </div>

        <div className="p-5 sm:p-6 space-y-5">
          {loading ? (
            <div className="h-40 bg-muted/60 animate-pulse rounded-lg" />
          ) : (
            <>
              {/* ===== Summary Boxes ===== */}
              <div>
                <div className="premium-section-label"><FileText className="w-3 h-3" />संपूर्ण लोन सारांश</div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <SummaryBox label="कुल लोन लिया" value={formatINR(totalLoanTaken)} color="text-blue-600" />
                  <SummaryBox label="कुल भुगतान" value={formatINR(totalPaid)} color="text-green-600" />
                  <SummaryBox label="कुल ब्याज" value={formatINR(totalInterest)} color="text-amber-600" />
                  <SummaryBox label="कुल बकाया" value={formatINR(totalRemaining)} color="text-red-600" />
                </div>
                <div className="flex items-center gap-2 mt-2 flex-wrap">
                  <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-xs">
                    <Clock4 className="w-3 h-3 mr-1" />{activeLoans} चल रहे
                  </Badge>
                  {closedLoans > 0 && (
                    <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">
                      <CheckCircle2 className="w-3 h-3 mr-1" />{closedLoans} पूर्ण
                    </Badge>
                  )}
                </div>
              </div>

              {/* ===== Unified Loan List ===== */}
              {unifiedLoans.length > 0 ? (
                <div>
                  <div className="premium-section-label">
                    <Receipt className="w-3 h-3" />
                    सभी लोन (बैंक + प्राइवेट) — {unifiedLoans.length} लोन
                  </div>
                  <div className="space-y-3">
                    {unifiedLoans.map((loan, i) => (
                      <UnifiedLoanCard
                        key={loan.loanId}
                        loan={loan}
                        index={i}
                        memberId={member.id}
                        memberName={member.name}
                        onSaved={() => setRefreshKey((k) => k + 1)}
                      />
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center text-sm text-muted-foreground py-8">
                  <Receipt className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  इस सदस्य का कोई लोन रिकॉर्ड नहीं है।
                </div>
              )}

              <div className="flex justify-end pt-2 border-t border-border/50">
                <Button variant="outline" onClick={() => onOpenChange(false)} className="press-effect h-10">
                  <X className="w-4 h-4" />बंद करें
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

/* ===================== Unified Loan Card ===================== */
function UnifiedLoanCard({
  loan, index, memberId, memberName, onSaved,
}: {
  loan: UnifiedLoan; index: number; memberId: string; memberName: string; onSaved: () => void
}) {
  const isBank = loan.loanType === 'bank'
  return (
    <Card className="premium-card overflow-hidden">
      {/* Loan header bar */}
      <div className={`bg-gradient-to-r ${isBank ? 'from-blue-50 to-indigo-50 border-blue-100' : 'from-amber-50 to-orange-50 border-amber-100'} px-4 py-3 border-b`}>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="text-xs font-bold flex items-center gap-2">
            {isBank ? <Landmark className="w-4 h-4 text-blue-600" /> : <HandCoins className="w-4 h-4 text-amber-600" />}
            लोन #{index + 1} — {isBank ? 'बैंक लोन' : 'प्राइवेट लोन'}
            {loan.bankName && <span className="text-muted-foreground font-normal">· {loan.bankName}</span>}
          </div>
          {loan.isCompleted ? (
            <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">
              <CheckCircle2 className="w-3 h-3 mr-1" />पूर्ण (Closed)
            </Badge>
          ) : (
            <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-xs">
              <Clock4 className="w-3 h-3 mr-1" />चल रहा
            </Badge>
          )}
        </div>
      </div>

      <CardContent className="p-4 space-y-3">
        {/* Loan details */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <DetailBox label="लोन राशि" value={formatINR(loan.loanAmount)} icon={<IndianRupee className="w-3 h-3" />} />
          <DetailBox label="ब्याज दर" value={`${loan.interestRate}%`} color="text-amber-600" />
          <DetailBox label="भुगतान" value={formatINR(loan.paidSoFar)} color="text-green-600" />
          <DetailBox label="शेष" value={formatINR(loan.remaining)} color="text-red-600" bold />
          <DetailBox label="ब्याज चुकाया" value={formatINR(loan.interestPaid)} color="text-amber-600" />
          <DetailBox label="वितरण तिथि" value={formatDate(loan.disbursedDate)} icon={<Calendar className="w-3 h-3" />} />
          <DetailBox label="कुल देय" value={formatINR(loan.loanAmount + loan.interestPaid)} />
          <DetailBox label="भुगतान की संख्या" value={`${loan.payments.length}`} />
        </div>

        {/* Make Payment button */}
        {!loan.isCompleted && (
          <MakePaymentInline
            memberId={memberId}
            memberName={memberName}
            loanType={loan.loanType}
            loanId={loan.loanId}
            loanAmount={loan.loanAmount}
            paidSoFar={loan.paidSoFar}
            interestRate={loan.interestRate}
            onSaved={onSaved}
          />
        )}

        {/* Payment history */}
        {loan.payments.length > 0 && (
          <div>
            <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-2 flex items-center gap-1">
              <Receipt className="w-3 h-3" />
              भुगतान इतिहास ({loan.payments.length})
            </div>
            <div className="overflow-x-auto scroll-area rounded-lg border">
              <table className="w-full text-[11px]">
                <thead className="premium-table-header">
                  <tr>
                    <th className="text-left px-2 py-1.5 font-semibold">तिथि / समय</th>
                    <th className="text-right px-2 py-1.5 font-semibold">राशि</th>
                    <th className="text-right px-2 py-1.5 font-semibold">मूलधन</th>
                    <th className="text-right px-2 py-1.5 font-semibold">ब्याज</th>
                    <th className="text-right px-2 py-1.5 font-semibold">शेष</th>
                    <th className="text-center px-2 py-1.5 font-semibold">मोड</th>
                  </tr>
                </thead>
                <tbody>
                  {loan.payments.map((p, idx) => (
                    <tr key={p.id} className={`border-b ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}`}>
                      <td className="px-2 py-1.5 text-muted-foreground whitespace-nowrap">
                        <div>{formatDate(p.paymentDate)}</div>
                        {p.paymentTime && (
                          <div className="text-[9px] text-blue-600 flex items-center gap-0.5">
                            <Clock className="w-2 h-2" />{p.paymentTime}
                          </div>
                        )}
                      </td>
                      <td className="px-2 py-1.5 text-right font-bold text-green-700">{formatINR(p.amount)}</td>
                      <td className="px-2 py-1.5 text-right text-muted-foreground">{formatINR(p.principal)}</td>
                      <td className="px-2 py-1.5 text-right text-amber-600">{formatINR(p.interest)}</td>
                      <td className="px-2 py-1.5 text-right font-semibold text-red-600">{formatINR(p.remainingBalance)}</td>
                      <td className="px-2 py-1.5 text-center"><Badge variant="outline" className="text-[8px]">{p.paymentMode}</Badge></td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className={`${isBank ? 'bg-blue-50' : 'bg-amber-50'} font-bold border-t-2`}>
                    <td className="px-2 py-1.5 text-right">कुल:</td>
                    <td className="px-2 py-1.5 text-right text-green-700">{formatINR(loan.payments.reduce((s, p) => s + p.amount, 0))}</td>
                    <td className="px-2 py-1.5 text-right">{formatINR(loan.payments.reduce((s, p) => s + p.principal, 0))}</td>
                    <td className="px-2 py-1.5 text-right text-amber-600">{formatINR(loan.payments.reduce((s, p) => s + p.interest, 0))}</td>
                    <td colSpan={2}></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

/* ===================== Make Payment Inline ===================== */
function MakePaymentInline({
  memberId, memberName, loanType, loanId, loanAmount, paidSoFar, interestRate, onSaved,
}: {
  memberId: string; memberName: string; loanType: 'bank' | 'private'; loanId: string
  loanAmount: number; paidSoFar: number; interestRate: number; onSaved: () => void
}) {
  const { toast } = useToast()
  const [open, setOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [amount, setAmount] = useState('')
  const [interest, setInterest] = useState('')
  const [paymentDate, setPaymentDate] = useState(toISODate(new Date()))
  const [paymentTime, setPaymentTime] = useState(formatTimeIST())
  const [paymentMode, setPaymentMode] = useState('cash')
  const [remarks, setRemarks] = useState('')

  const remaining = Math.max(0, loanAmount - paidSoFar)
  const principal = (() => {
    const amt = Number(amount) || 0
    const intr = Number(interest) || 0
    return Math.max(0, amt - intr)
  })()
  const newRemaining = Math.max(0, remaining - principal)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!amount) { toast({ title: 'राशि दर्ज करें', variant: 'destructive' }); return }
    setSubmitting(true)
    try {
      const res = await fetch('/api/loan-payments', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          memberId, loanType, loanId, paymentDate, paymentTime,
          amount: Number(amount), principal, interest: Number(interest) || 0,
          remainingBalance: newRemaining, paymentMode, remarks: remarks || null,
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) { toast({ title: 'भुगतान विफल', variant: 'destructive' }); return }
      setAmount(''); setInterest(''); setRemarks('')
      setOpen(false); onSaved()
      toast({ title: `₹${amount} का भुगतान दर्ज हुआ` })
    } catch { toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' }) } finally { setSubmitting(false) }
  }

  return (
    <>
      <Button size="sm" className="w-full premium-button text-white font-semibold press-effect h-9" onClick={() => setOpen(true)}>
        <IndianRupee className="w-4 h-4" />
        भुगतान जमा करें — शेष {formatINR(remaining)}
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="premium-dialog p-0 overflow-hidden border-0 sm:max-w-[440px] max-h-[90vh] overflow-y-auto">
          <div className={`premium-dialog-header bg-gradient-to-br ${loanType === 'bank' ? 'from-blue-500 via-indigo-500 to-violet-600' : 'from-amber-500 via-orange-500 to-red-500'} px-5 py-4`}>
            <div className="relative flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shrink-0 shadow-lg">
                <IndianRupee className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <DialogTitle className="text-base font-bold text-white">भुगतान जमा करें — {memberName}</DialogTitle>
                <DialogDescription className="text-xs text-white/80 mt-0.5">
                  {loanType === 'bank' ? '🏦 बैंक लोन EMI भुगतान' : '💰 प्राइवेट लोन चुकौती'} · ब्याज दर: {interestRate}%
                </DialogDescription>
              </div>
            </div>
          </div>
          <form onSubmit={handleSubmit} className="p-5 space-y-3">
            <div className="rounded-xl bg-muted/40 border border-border/50 p-3 space-y-1.5 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">कुल लोन</span><span className="font-bold">{formatINR(loanAmount)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">अब तक चुकाया</span><span className="font-semibold text-green-600">{formatINR(paidSoFar)}</span></div>
              <div className="flex justify-between pt-1.5 border-t"><span className="text-muted-foreground font-medium">शेष राशि</span><span className="font-bold text-red-600">{formatINR(remaining)}</span></div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1"><Label className="text-xs font-medium">भुगतान राशि (₹) *</Label><Input type="number" min={1} value={amount} onChange={(e) => setAmount(e.target.value)} required placeholder="2500" className="premium-input h-9" /></div>
              <div className="space-y-1"><Label className="text-xs font-medium">ब्याज (₹)</Label><Input type="number" min={0} value={interest} onChange={(e) => setInterest(e.target.value)} placeholder="300" className="premium-input h-9" /></div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="rounded-lg bg-blue-50 border border-blue-100 p-2">
                <div className="text-[10px] text-blue-600">मूलधन (Principal)</div>
                <div className="font-bold text-blue-700">{formatINR(principal)}</div>
              </div>
              <div className="rounded-lg bg-red-50 border border-red-100 p-2">
                <div className="text-[10px] text-red-600">नया शेष (New Balance)</div>
                <div className="font-bold text-red-700">{formatINR(newRemaining)}</div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1"><Label className="text-xs font-medium">तिथि</Label><Input type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} className="premium-input h-9" /></div>
              <div className="space-y-1"><Label className="text-xs font-medium">समय</Label><Input type="time" value={paymentTime} onChange={(e) => setPaymentTime(e.target.value)} className="premium-input h-9" /></div>
              <div className="space-y-1"><Label className="text-xs font-medium">मोड</Label>
                <Select value={paymentMode} onValueChange={setPaymentMode}>
                  <SelectTrigger className="premium-input h-9"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="cash">नकद</SelectItem><SelectItem value="bank">बैंक</SelectItem><SelectItem value="upi">UPI</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1"><Label className="text-xs font-medium">टिप्पणी</Label><Input value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="EMI का भुगतान" className="premium-input h-9" /></div>
            <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
              <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={submitting} className="press-effect h-9"><X className="w-3.5 h-3.5" />रद्द</Button>
              <Button type="submit" disabled={submitting} className="premium-button text-white font-semibold h-9">
                {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                {submitting ? '...' : 'भुगतान जमा करें'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  )
}

/* ===================== Helpers ===================== */
function SummaryBox({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="rounded-xl bg-muted/40 border border-border/50 p-3">
      <div className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</div>
      <div className={`text-sm font-bold mt-0.5 ${color || ''}`}>{value}</div>
    </div>
  )
}
function DetailBox({ label, value, color, bold, icon }: { label: string; value: string; color?: string; bold?: boolean; icon?: React.ReactNode }) {
  return (
    <div className="rounded-lg bg-muted/30 border border-border/30 p-2">
      <div className="text-[9px] text-muted-foreground uppercase tracking-wide flex items-center gap-1">{icon}{label}</div>
      <div className={`text-sm ${bold ? 'font-bold' : 'font-medium'} ${color || ''} mt-0.5`}>{value}</div>
    </div>
  )
}
