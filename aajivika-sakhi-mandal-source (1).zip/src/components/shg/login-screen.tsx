'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAppStore } from '@/lib/store'
import { useToast } from '@/hooks/use-toast'
import {
  Loader2,
  LockKeyhole,
  User,
  ShieldCheck,
  Eye,
  EyeOff,
  Users,
  HandCoins,
  PiggyBank,
} from 'lucide-react'
import { Logo } from '@/components/shg/logo'

export function LoginScreen() {
  const setAdmin = useAppStore((s) => s.setAdmin)
  const { toast } = useToast()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({
          title: 'Login Failed',
          description: data?.message || 'Invalid credentials',
          variant: 'destructive',
        })
        return
      }
      setAdmin(data.admin)
      toast({
        title: 'Welcome back',
        description: `Logged in as ${data.admin.username}`,
      })
    } catch {
      toast({
        title: 'Network Error',
        description: 'Could not reach the server. Please retry.',
        variant: 'destructive',
      })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex relative overflow-hidden">
      {/* Background illustration with green gradient overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: 'url(/shg-women-illustration.jpg)',
        }}
        aria-hidden
      />
      {/* Green gradient overlay for readability */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(135deg, rgba(0, 102, 51, 0.92) 0%, rgba(0, 153, 102, 0.85) 50%, rgba(0, 102, 51, 0.92) 100%)',
        }}
        aria-hidden
      />

      {/* LEFT SIDE — Branding (hidden on mobile, shown on lg+) */}
      <div className="hidden lg:flex lg:w-1/2 relative z-10 flex-col justify-center px-12 xl:px-16 text-white">
        <div className="max-w-lg">
          {/* Logo */}
          <div className="flex items-center gap-4 mb-8">
            <div className="w-16 h-16 rounded-2xl bg-white shadow-2xl flex items-center justify-center p-1.5 shrink-0">
              <Logo size={52} />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight leading-tight">
                AAJIVIKA SAKHI
              </h1>
              <h2 className="text-3xl font-bold tracking-tight leading-tight text-green-100">
                MANDAL
              </h2>
            </div>
          </div>

          {/* Tagline */}
          <p className="text-lg text-green-50/90 leading-relaxed mb-10 max-w-md">
            महिला स्वयं सहायता समूह — Women&apos;s Self Help Group Management System. Empowering rural women through savings, loans & community.
          </p>

          {/* Feature highlights */}
          <div className="space-y-4">
            <FeatureItem
              icon={<Users className="w-5 h-5" />}
              title="Member Management"
              desc="10 members · KYC · profiles"
            />
            <FeatureItem
              icon={<PiggyBank className="w-5 h-5" />}
              title="Savings Tracking"
              desc="Weekly collection · ₹10/member"
            />
            <FeatureItem
              icon={<HandCoins className="w-5 h-5" />}
              title="Loans & Expenses"
              desc="Private/Bank loans · expense records"
            />
          </div>

          {/* SHG info badge */}
          <div className="mt-10 inline-flex items-center gap-2 bg-white/10 backdrop-blur-md rounded-full px-4 py-2 border border-white/20">
            <span className="inline-block w-2 h-2 rounded-full bg-green-300 animate-pulse" />
            <span className="text-xs font-medium text-green-50">
              Reg. No: JH-ENB-2024-00874 · Group ID: JH340302
            </span>
          </div>
        </div>
      </div>

      {/* RIGHT SIDE — Login Card */}
      <div className="w-full lg:w-1/2 relative z-10 flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-md">
          {/* Login Card */}
          <div className="bg-white rounded-3xl shadow-2xl p-6 sm:p-8 lg:p-10 border border-white/50">
            {/* Mobile logo (shown only on small screens) */}
            <div className="lg:hidden flex items-center justify-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-white shadow-lg flex items-center justify-center p-1 shrink-0">
                <Logo size={40} />
              </div>
              <div>
                <div className="font-bold text-lg text-foreground leading-tight">AAJIVIKA SAKHI</div>
                <div className="font-bold text-lg text-primary leading-tight">MANDAL</div>
              </div>
            </div>

            {/* Heading */}
            <div className="text-center lg:text-left mb-6">
              <h2 className="text-2xl sm:text-3xl font-bold text-foreground tracking-tight">
                Welcome Back!
              </h2>
              <p className="text-sm text-muted-foreground mt-1.5">
                Login to your account to continue
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Username */}
              <div className="space-y-2">
                <Label htmlFor="username" className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Username
                </Label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="username"
                    type="text"
                    autoComplete="username"
                    placeholder="Enter your username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="pl-10 h-12 rounded-xl bg-muted/50 border-border focus:border-primary focus:bg-background transition-colors"
                    required
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Password
                </Label>
                <div className="relative">
                  <LockKeyhole className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="current-password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10 h-12 rounded-xl bg-muted/50 border-border focus:border-primary focus:bg-background transition-colors"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Login Button */}
              <Button
                type="submit"
                className="w-full h-12 rounded-xl text-sm font-bold uppercase tracking-wide shadow-lg hover:shadow-xl transition-all press-effect"
                disabled={submitting || !username || !password}
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Signing in…
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    Login to Dashboard
                  </>
                )}
              </Button>

              {/* Demo credentials hint */}
              <div className="rounded-xl bg-primary/5 border border-primary/15 px-4 py-3 text-xs text-muted-foreground leading-relaxed">
                <div className="font-semibold text-primary mb-1 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Demo Credentials
                </div>
                <div className="font-mono">
                  Username: <span className="font-semibold text-foreground">admin</span>
                  {' · '}
                  Password: <span className="font-semibold text-foreground">sakhi123</span>
                </div>
              </div>
            </form>
          </div>

          {/* Footer */}
          <p className="text-center text-[11px] text-white/80 mt-6 leading-relaxed">
            © Aajivika Sakhi Mandal · Authorized by Jharkhand e-Nibandhan
            <br />
            Authorized Signatory / President Stamp
          </p>
        </div>
      </div>
    </div>
  )
}

/* --------------------- Feature item (left panel) --------------------- */
function FeatureItem({
  icon,
  title,
  desc,
}: {
  icon: React.ReactNode
  title: string
  desc: string
}) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center shrink-0">
        {icon}
      </div>
      <div>
        <div className="font-semibold text-sm text-white">{title}</div>
        <div className="text-xs text-green-50/80">{desc}</div>
      </div>
    </div>
  )
}
