'use client'

import { useEffect, useState, useRef } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { formatINR, formatDate } from '@/lib/format'
import {
  Wallet,
  Landmark,
  HandCoins,
  Users,
  CalendarDays,
  TrendingUp,
  PiggyBank,
  CircleDollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  Activity,
  Target,
} from 'lucide-react'

interface Summary {
  memberCount: number
  weeklySavingsPerMember: number
  weeksSinceFounding: number
  totalSavings: number
  totalPrivateLoanDisbursed: number
  totalPrivateLoanRepaid: number
  totalPrivateLoanOutstanding: number
  totalBankLoanShare: number
  totalEmiPaid: number
  totalInterestPaid: number
  foundingDate: string
  meetingDay: string
}

export function DashboardSection() {
  const [summary, setSummary] = useState<Summary | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const res = await fetch('/api/dashboard', { cache: 'no-store' })
        const data = await res.json()
        if (mounted && data.ok) setSummary(data.summary)
      } catch {
        /* swallow */
      } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
    const id = setInterval(load, 30000)
    return () => {
      mounted = false
      clearInterval(id)
    }
  }, [])

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-40 bg-muted/60 animate-pulse rounded-2xl" />
          ))}
        </div>
      </div>
    )
  }

  if (!summary) {
    return (
      <Card>
        <CardContent className="py-10 text-center text-sm text-muted-foreground">
          Could not load dashboard. Please refresh.
        </CardContent>
      </Card>
    )
  }

  const privateRepayProgress =
    summary.totalPrivateLoanDisbursed > 0
      ? Math.min(
          100,
          Math.round(
            (summary.totalPrivateLoanRepaid / summary.totalPrivateLoanDisbursed) * 100
          )
        )
      : 0

  const bankRepayProgress =
    summary.totalBankLoanShare > 0
      ? Math.min(100, Math.round((summary.totalEmiPaid / summary.totalBankLoanShare) * 100))
      : 0

  return (
    <div className="space-y-6">
      {/* Hero greeting banner */}
      <HeroBanner summary={summary} />

      {/* Top stat cards — 3D glassmorphism */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <GlassStatCard
          title="Total Savings"
          value={formatINR(summary.totalSavings)}
          subtitle={`${formatINR(summary.weeklySavingsPerMember)} / member / week`}
          icon={<Wallet className="w-6 h-6" />}
          trend={`+${formatINR(summary.weeklySavingsPerMember * summary.memberCount)} this week`}
          trendUp
          gradient="from-emerald-500 via-green-500 to-teal-600"
          glow="rgba(16, 185, 129, 0.35)"
          delay={0}
        />
        <GlassStatCard
          title="Bank Loan"
          value={formatINR(summary.totalBankLoanShare)}
          subtitle={`EMI paid: ${formatINR(summary.totalEmiPaid)}`}
          icon={<Landmark className="w-6 h-6" />}
          trend={`Interest: ${formatINR(summary.totalInterestPaid)}`}
          trendUp={false}
          gradient="from-blue-500 via-indigo-500 to-violet-600"
          glow="rgba(59, 130, 246, 0.35)"
          delay={0.1}
        />
        <GlassStatCard
          title="Private Loan"
          value={formatINR(summary.totalPrivateLoanDisbursed)}
          subtitle={`Outstanding: ${formatINR(summary.totalPrivateLoanOutstanding)}`}
          icon={<HandCoins className="w-6 h-6" />}
          trend={`Repaid: ${formatINR(summary.totalPrivateLoanRepaid)}`}
          trendUp
          gradient="from-amber-500 via-orange-500 to-red-500"
          glow="rgba(245, 158, 11, 0.35)"
          delay={0.2}
        />
      </div>

      {/* Progress ring cards — circular 3D gauges */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <ProgressRingCard
          title="Private Loan Recovery"
          subtitle="Group loan collection progress"
          icon={<HandCoins className="w-5 h-5" />}
          percentage={privateRepayProgress}
          repaid={formatINR(summary.totalPrivateLoanRepaid)}
          total={formatINR(summary.totalPrivateLoanDisbursed)}
          outstanding={formatINR(summary.totalPrivateLoanOutstanding)}
          ringColor="#f59e0b"
          ringGradient="from-amber-400 to-orange-500"
          badgeColor="bg-amber-50 text-amber-700"
        />
        <ProgressRingCard
          title="Bank Loan EMI Progress"
          subtitle="EMI &amp; interest paid against bank loan"
          icon={<Landmark className="w-5 h-5" />}
          percentage={bankRepayProgress}
          repaid={formatINR(summary.totalEmiPaid)}
          total={formatINR(summary.totalBankLoanShare)}
          outstanding={formatINR(summary.totalBankLoanShare - summary.totalEmiPaid)}
          ringColor="#3b82f6"
          ringGradient="from-blue-400 to-indigo-500"
          badgeColor="bg-blue-50 text-blue-700"
          extra={
            <Badge className="bg-blue-50 text-blue-700 hover:bg-blue-50 text-xs">
              <CircleDollarSign className="w-3 h-3 mr-1" />
              {formatINR(summary.totalInterestPaid)} interest
            </Badge>
          }
        />
      </div>

      {/* Quick stats grid — mini 3D tiles */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <MiniStatTile
          label="Active Members"
          value={String(summary.memberCount)}
          icon={<Users className="w-4 h-4" />}
          gradient="from-purple-500 to-pink-500"
        />
        <MiniStatTile
          label="Weeks Active"
          value={String(summary.weeksSinceFounding)}
          icon={<CalendarDays className="w-4 h-4" />}
          gradient="from-cyan-500 to-blue-500"
        />
        <MiniStatTile
          label="Weekly Collection"
          value={formatINR(summary.weeklySavingsPerMember * summary.memberCount)}
          icon={<PiggyBank className="w-4 h-4" />}
          gradient="from-green-500 to-emerald-500"
        />
        <MiniStatTile
          label="Founded On"
          value={formatDate(summary.foundingDate)}
          icon={<TrendingUp className="w-4 h-4" />}
          gradient="from-amber-500 to-orange-500"
        />
      </div>

      {/* Info banner — 3D gradient card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20 p-5 shadow-card-3d">
        {/* Decorative blob */}
        <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-primary/10 blur-2xl" aria-hidden />
        <div className="absolute -left-4 -bottom-4 w-24 h-24 rounded-full bg-primary/5 blur-xl" aria-hidden />
        <div className="relative flex items-start gap-4">
          <div className="rounded-2xl bg-gradient-to-br from-primary to-[oklch(0.38_0.13_145)] p-3 shrink-0 shadow-fab">
            <CalendarDays className="w-5 h-5 text-primary-foreground" />
          </div>
          <div className="text-sm leading-relaxed text-foreground">
            <div className="font-bold text-base text-primary mb-1">Next Meeting</div>
            <div>
              Every <span className="font-bold text-primary">{summary.meetingDay}</span>, members contribute{' '}
              <span className="font-bold">{formatINR(summary.weeklySavingsPerMember)}</span>{' '}
              towards group savings. Repayment schedules are reviewed during the meeting.
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ===================== Hero Banner ===================== */
function HeroBanner({ summary }: { summary: Summary }) {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary via-[oklch(0.4_0.14_150)] to-[oklch(0.35_0.12_160)] p-6 sm:p-8 text-white shadow-2xl">
      {/* Animated decorative blobs */}
      <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-white/10 blur-3xl animate-pulse" aria-hidden />
      <div className="absolute -left-8 -bottom-8 w-40 h-40 rounded-full bg-white/5 blur-2xl" aria-hidden />
      {/* Subtle grid pattern */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage:
            'linear-gradient(rgba(255,255,255,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.3) 1px, transparent 1px)',
          backgroundSize: '24px 24px',
        }}
        aria-hidden
      />
      <div className="relative flex items-center justify-between gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-white/80" />
            <span className="text-xs font-medium text-white/80 uppercase tracking-wider">
              Dashboard Overview
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
            आजीविका सखी मंडल
          </h2>
          <p className="text-sm text-white/80 mt-1">
            Real-time financial snapshot of your Self Help Group
          </p>
        </div>
        {/* Total corpus display */}
        <div className="bg-white/15 backdrop-blur-md rounded-2xl px-5 py-3 border border-white/20 shadow-lg">
          <div className="text-[10px] text-white/70 uppercase tracking-wide font-medium">
            Total Corpus
          </div>
          <div className="text-2xl font-bold font-mono">
            {formatINR(summary.totalSavings + summary.totalBankLoanShare)}
          </div>
        </div>
      </div>
    </div>
  )
}

/* ===================== Glassmorphism Stat Card ===================== */
function GlassStatCard({
  title,
  value,
  subtitle,
  icon,
  trend,
  trendUp,
  gradient,
  glow,
  delay = 0,
}: {
  title: string
  value: string
  subtitle: string
  icon: React.ReactNode
  trend: string
  trendUp: boolean
  gradient: string
  glow: string
  delay?: number
}) {
  const cardRef = useRef<HTMLDivElement>(null)

  // 3D tilt on mouse move
  const handleMouseMove = (e: React.MouseEvent) => {
    const card = cardRef.current
    if (!card) return
    const rect = card.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    const centerX = rect.width / 2
    const centerY = rect.height / 2
    const rotateX = ((y - centerY) / centerY) * -6 // max 6deg
    const rotateY = ((x - centerX) / centerX) * 6
    card.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`
  }
  const handleMouseLeave = () => {
    const card = cardRef.current
    if (card) card.style.transform = 'perspective(800px) rotateX(0) rotateY(0) translateY(0)'
  }

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative overflow-hidden rounded-2xl bg-white border border-border transition-transform duration-200 ease-out cursor-default"
      style={{
        boxShadow: `0 4px 6px -1px rgba(0,0,0,0.05), 0 10px 30px -5px ${glow}, 0 0 0 1px rgba(0,0,0,0.02)`,
        animationDelay: `${delay}s`,
      }}
    >
      {/* Gradient top strip */}
      <div className={`h-1.5 bg-gradient-to-r ${gradient}`} aria-hidden />
      {/* Glow blob behind icon */}
      <div
        className={`absolute -right-6 -top-6 w-28 h-28 rounded-full bg-gradient-to-br ${gradient} opacity-10 blur-2xl`}
        aria-hidden
      />
      <div className="relative p-5">
        {/* Icon + trend */}
        <div className="flex items-start justify-between mb-4">
          <div
            className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${gradient} flex items-center justify-center text-white shadow-lg`}
            style={{ boxShadow: `0 8px 16px -4px ${glow}` }}
          >
            {icon}
          </div>
          <div
            className={`flex items-center gap-0.5 text-[11px] font-semibold px-2 py-1 rounded-full ${
              trendUp
                ? 'text-green-700 bg-green-50'
                : 'text-amber-700 bg-amber-50'
            }`}
          >
            {trendUp ? (
              <ArrowUpRight className="w-3 h-3" />
            ) : (
              <ArrowDownRight className="w-3 h-3" />
            )}
          </div>
        </div>
        {/* Title */}
        <div className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
          {title}
        </div>
        {/* Value — large bold */}
        <div className="text-3xl font-bold tracking-tight mt-1 text-foreground">
          {value}
        </div>
        {/* Subtitle */}
        <div className="text-xs text-muted-foreground mt-1">{subtitle}</div>
        {/* Trend footer */}
        <div className="text-[11px] text-muted-foreground mt-3 pt-3 border-t border-border/60">
          {trend}
        </div>
      </div>
    </div>
  )
}

/* ===================== Progress Ring Card ===================== */
function ProgressRingCard({
  title,
  subtitle,
  icon,
  percentage,
  repaid,
  total,
  outstanding,
  ringColor,
  ringGradient,
  badgeColor,
  extra,
}: {
  title: string
  subtitle: string
  icon: React.ReactNode
  percentage: number
  repaid: string
  total: string
  outstanding: string
  ringColor: string
  ringGradient: string
  badgeColor: string
  extra?: React.ReactNode
}) {
  const radius = 52
  const circumference = 2 * Math.PI * radius
  const strokeDashoffset = circumference - (percentage / 100) * circumference

  return (
    <Card className="shadow-card-3d lift-on-hover hover:shadow-card-3d-hover overflow-hidden">
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="text-sm font-semibold flex items-center gap-2">
              <span className={`bg-gradient-to-br ${ringGradient} text-white p-1.5 rounded-lg shadow-sm`}>
                {icon}
              </span>
              {title}
            </div>
            <div className="text-xs text-muted-foreground mt-1">{subtitle}</div>
          </div>
          {extra}
        </div>

        {/* Ring + details layout */}
        <div className="flex items-center gap-5">
          {/* Circular progress ring */}
          <div className="relative shrink-0">
            <svg width="120" height="120" viewBox="0 0 120 120" className="-rotate-90">
              {/* Background ring */}
              <circle
                cx="60"
                cy="60"
                r={radius}
                fill="none"
                stroke="currentColor"
                strokeWidth="10"
                className="text-muted/30"
              />
              {/* Progress ring with gradient */}
              <defs>
                <linearGradient id={`grad-${title.replace(/\s/g, '')}`} x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor={ringColor} stopOpacity="0.6" />
                  <stop offset="100%" stopColor={ringColor} />
                </linearGradient>
              </defs>
              <circle
                cx="60"
                cy="60"
                r={radius}
                fill="none"
                stroke={`url(#grad-${title.replace(/\s/g, '')})`}
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                style={{
                  transition: 'stroke-dashoffset 1s ease-in-out',
                  filter: `drop-shadow(0 2px 4px ${ringColor}40)`,
                }}
              />
            </svg>
            {/* Center label */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="text-2xl font-bold text-foreground">{percentage}%</div>
              <div className="text-[9px] text-muted-foreground uppercase tracking-wide">collected</div>
            </div>
          </div>

          {/* Stats */}
          <div className="flex-1 space-y-2 min-w-0">
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Repaid</span>
              <span className="font-semibold text-foreground">{repaid}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Total</span>
              <span className="font-medium">{total}</span>
            </div>
            <div className="flex justify-between text-xs pt-2 border-t">
              <span className="text-muted-foreground">Outstanding</span>
              <span className={`font-bold px-2 py-0.5 rounded ${badgeColor}`}>
                {outstanding}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

/* ===================== Mini Stat Tile ===================== */
function MiniStatTile({
  label,
  value,
  icon,
  gradient,
}: {
  label: string
  value: string
  icon: React.ReactNode
  gradient: string
}) {
  return (
    <div
      className="relative overflow-hidden rounded-xl bg-white border border-border p-3.5 transition-all hover:-translate-y-1 hover:shadow-card-hover cursor-default"
      style={{ boxShadow: '0 2px 4px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.06)' }}
    >
      {/* Glow blob */}
      <div
        className={`absolute -right-4 -top-4 w-16 h-16 rounded-full bg-gradient-to-br ${gradient} opacity-10 blur-xl`}
        aria-hidden
      />
      <div className="relative">
        <div className={`inline-flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br ${gradient} text-white shadow-sm mb-2`}>
          {icon}
        </div>
        <div className="text-[11px] text-muted-foreground font-medium">{label}</div>
        <div className="text-base font-bold text-foreground mt-0.5">{value}</div>
      </div>
    </div>
  )
}
