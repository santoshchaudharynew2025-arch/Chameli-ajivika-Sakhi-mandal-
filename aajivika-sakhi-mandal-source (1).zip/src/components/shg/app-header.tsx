'use client'

import { useEffect, useState } from 'react'
import { LotusIcon, db_connected } from './icons'

interface HeaderData {
  registrationNo: string | null
  foundingDate: string | null
  meetingDay: string
}

export function AppHeader({ data }: { data: HeaderData | null }) {
  const [dbStatus, setDbStatus] = useState<'connecting' | 'connected'>('connecting')

  useEffect(() => {
    db_connected().then(setDbStatus)
  }, [])

  const fmtFounding = (d: string | null) => {
    if (!d) return '—'
    const date = new Date(d)
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    })
  }

  return (
    <header className="bg-gradient-to-r from-primary via-[oklch(0.45_0.16_28)] to-primary text-primary-foreground shadow-lg">
      <div className="max-w-6xl mx-auto px-4 py-5 sm:py-7">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          {/* Left: Logo + Title */}
          <div className="flex items-center gap-3 sm:gap-4">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-primary-foreground/15 backdrop-blur flex items-center justify-center border-2 border-primary-foreground/30">
              <LotusIcon className="w-9 h-9 sm:w-11 sm:h-11 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-serif text-xl sm:text-3xl font-bold tracking-tight">
                AAJIVIKA SAKHI MANDAL
              </h1>
              <p className="text-[10px] sm:text-xs text-primary-foreground/80 mt-0.5">
                Reg. No:{' '}
                <span className="font-semibold text-primary-foreground">
                  {data?.registrationNo || 'JH-ENB-2024-00874'}
                </span>
              </p>
              <div className="flex items-center gap-2 text-[10px] sm:text-xs text-primary-foreground/80 mt-0.5">
                <span>Founded: {fmtFounding(data?.foundingDate)}</span>
                <span aria-hidden>•</span>
                <span>Meeting: Every {data?.meetingDay || 'Wednesday'}</span>
              </div>
            </div>
          </div>

          {/* Right: DB status badge */}
          <div className="flex items-center gap-2 bg-primary-foreground/15 backdrop-blur rounded-full px-3 py-1.5 border border-primary-foreground/20">
            <span
              className={`inline-block w-2 h-2 rounded-full ${
                dbStatus === 'connected'
                  ? 'bg-green-400 animate-pulse'
                  : 'bg-yellow-300'
              }`}
              aria-hidden
            />
            <span className="text-[10px] sm:text-xs font-medium text-primary-foreground">
              {dbStatus === 'connected' ? 'DB Connected · Live Sync' : 'Connecting…'}
            </span>
          </div>
        </div>
      </div>
      <div className="deco-divider opacity-50" />
    </header>
  )
}
