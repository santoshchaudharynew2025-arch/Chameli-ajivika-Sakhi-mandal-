'use client'

import { useEffect, useMemo, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { useToast } from '@/hooks/use-toast'
import { useAppStore } from '@/lib/store'
import { formatINR, formatDate, toISODate, formatTimeIST } from '@/lib/format'
import { LoanPaymentTracker } from '@/components/shg/loan-payment-tracker'
import {
  Search,
  HandCoins,
  Landmark,
  Plus,
  Pencil,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  Clock4,
  Loader2,
  Receipt,
  IndianRupee,
} from 'lucide-react'

interface Member { id: string; name: string }
interface PrivateLoan {
  id: string; memberId: string; loanAmount: number; disbursementDate: string;
  repaymentAmount: number; repaymentDate: string | null; note?: string | null; member: Member
}
interface BankLoan {
  id: string; memberId: string; bankLoanShare: number; emiPaid: number; interestPaid: number;
  paymentDate: string | null; bankName?: string | null; note?: string | null; member: Member
}

export function LoansSection() {
  const [tab, setTab] = useState<'private' | 'bank' | 'tracker'>('private')
  const [members, setMembers] = useState<Member[]>([])
  const [privateLoans, setPrivateLoans] = useState<PrivateLoan[]>([])
  const [bankLoans, setBankLoans] = useState<BankLoan[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState<'all' | 'pending' | 'paid'>('all')
  const admin = useAppStore((s) => s.admin)
  const [refreshKey, setRefreshKey] = useState(0)

  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const [mRes, pRes, bRes] = await Promise.all([
          fetch('/api/members', { cache: 'no-store' }),
          fetch('/api/loans/private', { cache: 'no-store' }),
          fetch('/api/loans/bank', { cache: 'no-store' }),
        ])
        const [m, p, b] = await Promise.all([mRes.json(), pRes.json(), bRes.json()])
        if (mounted) {
          if (m.ok) setMembers(m.members.map((x: { id: string; name: string }) => ({ id: x.id, name: x.name })))
          if (p.ok) setPrivateLoans(p.loans)
          if (b.ok) setBankLoans(b.loans)
        }
      } catch { /* swallow */ } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
  }, [refreshKey])

  const totals = useMemo(() => {
    if (tab === 'private') {
      const disbursed = privateLoans.reduce((s, l) => s + l.loanAmount, 0)
      const repaid = privateLoans.reduce((s, l) => s + l.repaymentAmount, 0)
      return { disbursed, repaid, outstanding: disbursed - repaid }
    }
    const share = bankLoans.reduce((s, l) => s + l.bankLoanShare, 0)
    const emi = bankLoans.reduce((s, l) => s + l.emiPaid, 0)
    const interest = bankLoans.reduce((s, l) => s + l.interestPaid, 0)
    return { disbursed: share, repaid: emi, outstanding: share - emi, interest }
  }, [tab, privateLoans, bankLoans])

  return (
    <div className="space-y-4">
      {/* Tabs */}
      <Tabs value={tab} onValueChange={(v) => setTab(v as 'private' | 'bank' | 'tracker')}>
        <TabsList className="h-9">
          <TabsTrigger value="private" className="text-xs">
            <HandCoins className="w-3.5 h-3.5 mr-1.5" />
            Private Loans
          </TabsTrigger>
          <TabsTrigger value="bank" className="text-xs">
            <Landmark className="w-3.5 h-3.5 mr-1.5" />
            Bank Loans
          </TabsTrigger>
          <TabsTrigger value="tracker" className="text-xs">
            <Receipt className="w-3.5 h-3.5 mr-1.5" />
            Payment Tracker
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Payment Tracker tab */}
      {tab === 'tracker' && <LoanPaymentTracker />}

      {/* Title + Add button (only for private/bank tabs) */}
      {tab !== 'tracker' && (
      <>
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-baseline gap-2 flex-wrap">
          <h2 className="text-lg font-semibold">
            {tab === 'private' ? 'Private Loan Records' : 'Bank Loan Records'}
          </h2>
          <span className="text-sm text-muted-foreground">
            {tab === 'private' ? `${privateLoans.length} records` : `${bankLoans.length} records`}
          </span>
        </div>
        {admin && (
          <>
            <PrivateLoanAddButton
              members={members}
              tab={tab}
              onSaved={() => {
                setRefreshKey((k) => k + 1)
              }}
            />
          </>
        )}
      </div>

      {/* Search + filter */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by member name..."
            className="pl-9 h-9"
          />
        </div>
        <Select
          value={filter}
          onValueChange={(v) => setFilter(v as 'all' | 'pending' | 'paid')}
        >
          <SelectTrigger className="w-[150px] h-9">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Records</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="paid">Fully Paid</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Summary chips */}
      <div className="flex items-center gap-2 flex-wrap">
        {tab === 'private' ? (
          <>
            <Badge variant="outline" className="text-xs bg-blue-50 border-blue-200">
              Disbursed: {formatINR(totals.disbursed)}
            </Badge>
            <Badge variant="outline" className="text-xs bg-green-50 border-green-200">
              Repaid: {formatINR(totals.repaid)}
            </Badge>
            <Badge variant="outline" className="text-xs bg-amber-50 border-amber-200">
              Outstanding: {formatINR(totals.outstanding)}
            </Badge>
          </>
        ) : (
          <>
            <Badge variant="outline" className="text-xs bg-blue-50 border-blue-200">
              Total Bank Loan: {formatINR(totals.disbursed)}
            </Badge>
            <Badge variant="outline" className="text-xs bg-green-50 border-green-200">
              EMI Paid: {formatINR(totals.repaid)}
            </Badge>
            <Badge variant="outline" className="text-xs bg-purple-50 border-purple-200">
              Interest Paid: {formatINR(totals.interest || 0)}
            </Badge>
          </>
        )}
      </div>

      {/* List */}
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-20 bg-muted/60 animate-pulse rounded-lg" />
          ))}
        </div>
      ) : tab === 'private' ? (
        <PrivateLoanList
          loans={privateLoans.filter((l) => {
            const q = search.toLowerCase()
            const matchesSearch = !q || l.member.name.toLowerCase().includes(q)
            const isPaid = l.repaymentAmount >= l.loanAmount && l.loanAmount > 0
            const matchesFilter = filter === 'all' || (filter === 'paid' && isPaid) || (filter === 'pending' && !isPaid)
            return matchesSearch && matchesFilter
          })}
          members={members}
          admin={!!admin}
          onRefresh={() => setRefreshKey((k) => k + 1)}
        />
      ) : (
        <BankLoanList
          loans={bankLoans.filter((l) => {
            const q = search.toLowerCase()
            const matchesSearch = !q || l.member.name.toLowerCase().includes(q)
            const isPaid = l.emiPaid >= l.bankLoanShare && l.bankLoanShare > 0
            const matchesFilter = filter === 'all' || (filter === 'paid' && isPaid) || (filter === 'pending' && !isPaid)
            return matchesSearch && matchesFilter
          })}
          members={members}
          admin={!!admin}
          onRefresh={() => setRefreshKey((k) => k + 1)}
        />
      )}
      </>
      )}
    </div>
  )
}

/* ---------------------- Add button router ---------------------- */
function PrivateLoanAddButton({
  members,
  tab,
  onSaved,
}: {
  members: Member[]
  tab: 'private' | 'bank'
  onSaved: () => void
}) {
  const [open, setOpen] = useState(false)
  return (
    <>
      {tab === 'private' ? (
        <PrivateLoanFormDialog
          members={members}
          open={open}
          setOpen={(v) => {
            setOpen(v)
            if (!v) onSaved()
          }}
          editLoan={null}
          onSaved={() => setOpen(false)}
        >
          <Button size="sm" className="h-9">
            <Plus className="w-4 h-4" />
            Add Loan
          </Button>
        </PrivateLoanFormDialog>
      ) : (
        <BankLoanFormDialog
          members={members}
          open={open}
          setOpen={(v) => {
            setOpen(v)
            if (!v) onSaved()
          }}
          editLoan={null}
          onSaved={() => setOpen(false)}
        >
          <Button size="sm" className="h-9">
            <Plus className="w-4 h-4" />
            Add Record
          </Button>
        </BankLoanFormDialog>
      )}
    </>
  )
}

/* ---------------------- Make Payment Button + Dialog ---------------------- */
function MakePaymentButton({
  memberId,
  memberName,
  loanType,
  loanId,
  loanAmount,
  paidSoFar,
  onSaved,
}: {
  memberId: string
  memberName: string
  loanType: 'bank' | 'private'
  loanId: string
  loanAmount: number
  paidSoFar: number
  onSaved: () => void
}) {
  const { toast } = useToast()
  const [open, setOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [amount, setAmount] = useState('')
  const [interest, setInterest] = useState('')
  const [paymentDate, setPaymentDate] = useState(toISODate(new Date()))
  const [paymentTime, setPaymentTime] = useState(formatTimeIST())
  const [paymentMode, setPaymentMode] = useState('cash')
  const [remarks, setRemarks] = useState('')

  const remaining = Math.max(0, loanAmount - paidSoFar)
  const principal = (() => {
    const amt = Number(amount) || 0
    const intr = Number(interest) || 0
    return Math.max(0, amt - intr)
  })()
  const newRemaining = Math.max(0, remaining - principal)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!amount) {
      toast({ title: 'राशि दर्ज करें', variant: 'destructive' })
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/loan-payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          memberId,
          loanType,
          loanId,
          paymentDate,
          paymentTime,
          amount: Number(amount),
          principal,
          interest: Number(interest) || 0,
          remainingBalance: newRemaining,
          paymentMode,
          remarks: remarks || null,
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'भुगतान विफल', variant: 'destructive' })
        return
      }
      setAmount('')
      setInterest('')
      setRemarks('')
      setOpen(false)
      onSaved()
      toast({ title: `₹${amount} का भुगतान दर्ज हुआ` })
    } catch {
      toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <>
      <Button
        size="sm"
        className="h-7 text-[11px] premium-button text-white font-semibold press-effect"
        onClick={() => setOpen(true)}
        disabled={remaining <= 0}
      >
        <IndianRupee className="w-3 h-3" />
        {remaining <= 0 ? 'पूर्ण' : 'जमा करें'}
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="premium-dialog p-0 overflow-hidden border-0 sm:max-w-[440px] max-h-[90vh] overflow-y-auto">
          <div className={`premium-dialog-header bg-gradient-to-br ${loanType === 'bank' ? 'from-blue-500 via-indigo-500 to-violet-600' : 'from-amber-500 via-orange-500 to-red-500'} px-5 py-4`}>
            <div className="relative flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shrink-0 shadow-lg">
                <IndianRupee className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <DialogTitle className="text-base font-bold text-white">
                  भुगतान जमा करें — {memberName}
                </DialogTitle>
                <DialogDescription className="text-xs text-white/80 mt-0.5">
                  {loanType === 'bank' ? '🏦 बैंक लोन EMI' : '💰 प्राइवेट लोन चुकौती'}
                </DialogDescription>
              </div>
            </div>
          </div>
          <form onSubmit={handleSubmit} className="p-5 space-y-3">
            {/* Loan summary box */}
            <div className="rounded-xl bg-muted/40 border border-border/50 p-3 space-y-1.5 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">कुल लोन</span><span className="font-bold">{formatINR(loanAmount)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">अब तक चुकाया</span><span className="font-semibold text-green-600">{formatINR(paidSoFar)}</span></div>
              <div className="flex justify-between pt-1.5 border-t"><span className="text-muted-foreground font-medium">शेष राशि</span><span className="font-bold text-red-600">{formatINR(remaining)}</span></div>
            </div>

            {/* Payment amount */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label className="text-xs font-medium">भुगतान राशि (₹) *</Label>
                <Input type="number" min={1} value={amount} onChange={(e) => setAmount(e.target.value)} required placeholder="2500" className="premium-input h-9" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-medium">ब्याज (₹)</Label>
                <Input type="number" min={0} value={interest} onChange={(e) => setInterest(e.target.value)} placeholder="300" className="premium-input h-9" />
              </div>
            </div>

            {/* Auto-calc display */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="rounded-lg bg-blue-50 border border-blue-100 p-2">
                <div className="text-[10px] text-blue-600">मूलधन (Principal)</div>
                <div className="font-bold text-blue-700">{formatINR(principal)}</div>
              </div>
              <div className="rounded-lg bg-red-50 border border-red-100 p-2">
                <div className="text-[10px] text-red-600">नया शेष (New Balance)</div>
                <div className="font-bold text-red-700">{formatINR(newRemaining)}</div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1">
                <Label className="text-xs font-medium">तिथि</Label>
                <Input type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} className="premium-input h-9" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-medium">समय</Label>
                <Input type="time" value={paymentTime} onChange={(e) => setPaymentTime(e.target.value)} className="premium-input h-9" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-medium">मोड</Label>
                <Select value={paymentMode} onValueChange={setPaymentMode}>
                  <SelectTrigger className="premium-input h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">नकद</SelectItem>
                    <SelectItem value="bank">बैंक</SelectItem>
                    <SelectItem value="upi">UPI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-1">
              <Label className="text-xs font-medium">टिप्पणी</Label>
              <Input value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="EMI का 3वां भुगतान" className="premium-input h-9" />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
              <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={submitting} className="press-effect h-9">रद्द</Button>
              <Button type="submit" disabled={submitting} className="premium-button text-white font-semibold h-9">
                {submitting ? '...' : 'भुगतान जमा करें'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  )
}

/* ----------- Edit Loan Button (manages own state) ----------- */
function EditLoanButton({
  members,
  editLoan,
  isPrivate,
  onSaved,
}: {
  members: Member[]
  editLoan: PrivateLoan | BankLoan
  isPrivate: boolean
  onSaved: () => void
}) {
  const [open, setOpen] = useState(false)
  if (isPrivate) {
    return (
      <PrivateLoanFormDialog
        members={members}
        open={open}
        setOpen={setOpen}
        editLoan={editLoan as PrivateLoan}
        onSaved={onSaved}
      >
        <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Edit">
          <Pencil className="w-3.5 h-3.5" />
        </Button>
      </PrivateLoanFormDialog>
    )
  }
  return (
    <BankLoanFormDialog
      members={members}
      open={open}
      setOpen={setOpen}
      editLoan={editLoan as BankLoan}
      onSaved={onSaved}
    >
      <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Edit">
        <Pencil className="w-3.5 h-3.5" />
      </Button>
    </BankLoanFormDialog>
  )
}

/* ------------------------------- Private Loan List ------------------------------- */
function PrivateLoanList({
  loans,
  members,
  admin,
  onRefresh,
}: {
  loans: PrivateLoan[]
  members: Member[]
  admin: boolean
  onRefresh: () => void
}) {
  const { toast } = useToast()
  if (loans.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-sm text-muted-foreground">
          <HandCoins className="w-10 h-10 mx-auto mb-3 opacity-30" />
          No private loan records found.
        </CardContent>
      </Card>
    )
  }
  return (
    <div className="space-y-2">
      {loans.map((l) => {
        const isPaid = l.repaymentAmount >= l.loanAmount && l.loanAmount > 0
        const outstanding = Math.max(0, l.loanAmount - l.repaymentAmount)
        return (
          <Card key={l.id} className="shadow-card lift-on-hover hover:shadow-card-hover">
            <CardContent className="p-4 flex items-center gap-4">
              <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 shadow-fab ${isPaid ? 'bg-gradient-to-br from-green-100 to-green-50' : 'bg-gradient-to-br from-amber-100 to-amber-50'}`}>
                <HandCoins className={`w-5 h-5 ${isPaid ? 'text-green-600' : 'text-amber-600'}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="font-medium text-sm">{l.member.name}</div>
                  {isPaid ? (
                    <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-[10px]">
                      <CheckCircle2 className="w-2.5 h-2.5 mr-0.5" />
                      Fully Repaid
                    </Badge>
                  ) : (
                    <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-[10px]">
                      <Clock4 className="w-2.5 h-2.5 mr-0.5" />
                      {formatINR(outstanding)} pending
                    </Badge>
                  )}
                </div>
                <div className="text-xs text-muted-foreground mt-1 flex items-center gap-3 flex-wrap">
                  <span>Loan: <span className="font-medium text-foreground">{formatINR(l.loanAmount)}</span></span>
                  <span>Disbursed: {formatDate(l.disbursementDate)}</span>
                  <span>Repaid: <span className="font-medium text-foreground">{formatINR(l.repaymentAmount)}</span></span>
                  {l.repaymentDate && <span>On: {formatDate(l.repaymentDate)}</span>}
                </div>
              </div>
              {admin && (
                <div className="flex items-center gap-1 shrink-0">
                  <MakePaymentButton
                    memberId={l.memberId}
                    memberName={l.member.name}
                    loanType="private"
                    loanId={l.id}
                    loanAmount={l.loanAmount}
                    paidSoFar={l.repaymentAmount}
                    onSaved={onRefresh}
                  />
                  <EditLoanButton
                    members={members}
                    editLoan={l}
                    isPrivate={true}
                    onSaved={() => {
                      onRefresh()
                      toast({ title: 'Loan updated' })
                    }}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:text-destructive"
                    aria-label="Delete"
                    onClick={async () => {
                      if (!confirm('Delete this loan record?')) return
                      const r = await fetch(`/api/loans/private/${l.id}`, { method: 'DELETE' })
                      if (r.ok) {
                        onRefresh()
                        toast({ title: 'Loan deleted' })
                      } else {
                        toast({ title: 'Failed to delete', variant: 'destructive' })
                      }
                    }}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

/* ------------------------------- Bank Loan List ------------------------------- */
function BankLoanList({
  loans,
  members,
  admin,
  onRefresh,
}: {
  loans: BankLoan[]
  members: Member[]
  admin: boolean
  onRefresh: () => void
}) {
  const { toast } = useToast()
  if (loans.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-sm text-muted-foreground">
          <Landmark className="w-10 h-10 mx-auto mb-3 opacity-30" />
          No bank loan records found.
        </CardContent>
      </Card>
    )
  }
  return (
    <div className="space-y-2">
      {loans.map((l) => {
        const isPaid = l.emiPaid >= l.bankLoanShare && l.bankLoanShare > 0
        const remaining = Math.max(0, l.bankLoanShare - l.emiPaid)
        return (
          <Card key={l.id} className="shadow-card lift-on-hover hover:shadow-card-hover">
            <CardContent className="p-4 flex items-center gap-4">
              <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 shadow-fab ${isPaid ? 'bg-gradient-to-br from-green-100 to-green-50' : 'bg-gradient-to-br from-blue-100 to-blue-50'}`}>
                <Landmark className={`w-5 h-5 ${isPaid ? 'text-green-600' : 'text-blue-600'}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="font-medium text-sm">{l.member.name}</div>
                  {isPaid ? (
                    <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-[10px]">
                      <CheckCircle2 className="w-2.5 h-2.5 mr-0.5" />
                      Fully Paid
                    </Badge>
                  ) : (
                    <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-[10px]">
                      <Clock4 className="w-2.5 h-2.5 mr-0.5" />
                      {formatINR(remaining)} remaining
                    </Badge>
                  )}
                </div>
                <div className="text-xs text-muted-foreground mt-1 flex items-center gap-3 flex-wrap">
                  <span>Share: <span className="font-medium text-foreground">{formatINR(l.bankLoanShare)}</span></span>
                  <span>EMI: <span className="font-medium text-foreground">{formatINR(l.emiPaid)}</span></span>
                  <span>Interest: <span className="font-medium text-foreground">{formatINR(l.interestPaid)}</span></span>
                  {l.paymentDate && <span>Paid on: {formatDate(l.paymentDate)}</span>}
                </div>
              </div>
              {admin && (
                <div className="flex items-center gap-1 shrink-0">
                  <MakePaymentButton
                    memberId={l.memberId}
                    memberName={l.member.name}
                    loanType="bank"
                    loanId={l.id}
                    loanAmount={l.bankLoanShare}
                    paidSoFar={l.emiPaid}
                    onSaved={onRefresh}
                  />
                  <EditLoanButton
                    members={members}
                    editLoan={l}
                    isPrivate={false}
                    onSaved={() => {
                      onRefresh()
                      toast({ title: 'Bank loan updated' })
                    }}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:text-destructive"
                    aria-label="Delete"
                    onClick={async () => {
                      if (!confirm('Delete this bank loan record?')) return
                      const r = await fetch(`/api/loans/bank/${l.id}`, { method: 'DELETE' })
                      if (r.ok) {
                        onRefresh()
                        toast({ title: 'Record deleted' })
                      } else {
                        toast({ title: 'Failed to delete', variant: 'destructive' })
                      }
                    }}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

/* --------------------------- Private Loan Form --------------------------- */
function PrivateLoanFormDialog({
  members,
  open,
  setOpen,
  editLoan,
  onSaved,
  children,
}: {
  members: Member[]
  open: boolean
  setOpen: (v: boolean) => void
  editLoan: PrivateLoan | null
  onSaved: () => void
  children: React.ReactNode
}) {
  const { toast } = useToast()
  const [submitting, setSubmitting] = useState(false)
  const [memberId, setMemberId] = useState(editLoan?.memberId || '')
  const [loanAmount, setLoanAmount] = useState(editLoan ? String(editLoan.loanAmount) : '')
  const [disbursementDate, setDisbursementDate] = useState(editLoan ? toISODate(editLoan.disbursementDate) : '')
  const [repaymentAmount, setRepaymentAmount] = useState(editLoan ? String(editLoan.repaymentAmount) : '0')
  const [repaymentDate, setRepaymentDate] = useState(editLoan ? toISODate(editLoan.repaymentDate) : '')

  useEffect(() => {
    setMemberId(editLoan?.memberId || '')
    setLoanAmount(editLoan ? String(editLoan.loanAmount) : '')
    setDisbursementDate(editLoan ? toISODate(editLoan.disbursementDate) : '')
    setRepaymentAmount(editLoan ? String(editLoan.repaymentAmount) : '0')
    setRepaymentDate(editLoan ? toISODate(editLoan.repaymentDate) : '')
  }, [editLoan, open])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!memberId || !loanAmount || !disbursementDate) {
      toast({ title: 'Member, amount and disbursement date are required', variant: 'destructive' })
      return
    }
    setSubmitting(true)
    try {
      const payload = {
        memberId,
        loanAmount: Number(loanAmount),
        disbursementDate,
        repaymentAmount: Number(repaymentAmount || 0),
        repaymentDate: repaymentDate || null,
      }
      const url = editLoan ? `/api/loans/private/${editLoan.id}` : '/api/loans/private'
      const method = editLoan ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'Save failed', description: data?.message, variant: 'destructive' })
        return
      }
      onSaved()
    } catch {
      toast({ title: 'Network error', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="premium-dialog p-0 overflow-hidden border-0 sm:max-w-[480px] max-h-[90vh] overflow-y-auto">
        <div className="premium-dialog-header bg-gradient-to-br from-amber-500 via-orange-500 to-amber-600 px-5 py-4 sm:px-6 sm:py-5">
          <div className="relative flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shrink-0 shadow-lg">
              <HandCoins className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <DialogTitle className="text-base sm:text-lg font-bold text-white leading-tight">
                {editLoan ? 'Edit Private Loan' : 'Add Private Loan'}
              </DialogTitle>
              <DialogDescription className="text-xs text-white/80 mt-1">
                Record a loan disbursed from the group savings fund.
              </DialogDescription>
            </div>
          </div>
        </div>
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          <div className="space-y-1.5">
            <Label className="text-xs font-medium">Member</Label>
            <Select value={memberId} onValueChange={setMemberId}>
              <SelectTrigger className="premium-input h-10"><SelectValue placeholder="Select member" /></SelectTrigger>
              <SelectContent>
                {members.map((m) => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Loan Amount (₹)</Label>
              <Input type="number" min={0} step="100" value={loanAmount} onChange={(e) => setLoanAmount(e.target.value)} required className="premium-input h-10" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Disbursement Date</Label>
              <Input type="date" value={disbursementDate} onChange={(e) => setDisbursementDate(e.target.value)} required className="premium-input h-10" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Repayment Amount (₹)</Label>
              <Input type="number" min={0} step="100" value={repaymentAmount} onChange={(e) => setRepaymentAmount(e.target.value)} className="premium-input h-10" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Repayment Date</Label>
              <Input type="date" value={repaymentDate} onChange={(e) => setRepaymentDate(e.target.value)} className="premium-input h-10" />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={submitting} className="press-effect h-10">Cancel</Button>
            <Button type="submit" disabled={submitting} className="premium-button text-white font-semibold h-10">
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {editLoan ? 'Update Loan' : 'Save Loan'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

/* --------------------------- Bank Loan Form --------------------------- */
function BankLoanFormDialog({
  members,
  open,
  setOpen,
  editLoan,
  onSaved,
  children,
}: {
  members: Member[]
  open: boolean
  setOpen: (v: boolean) => void
  editLoan: BankLoan | null
  onSaved: () => void
  children: React.ReactNode
}) {
  const { toast } = useToast()
  const [submitting, setSubmitting] = useState(false)
  const [memberId, setMemberId] = useState(editLoan?.memberId || '')
  const [bankLoanShare, setBankLoanShare] = useState(editLoan ? String(editLoan.bankLoanShare) : '')
  const [emiPaid, setEmiPaid] = useState(editLoan ? String(editLoan.emiPaid) : '0')
  const [interestPaid, setInterestPaid] = useState(editLoan ? String(editLoan.interestPaid) : '0')
  const [paymentDate, setPaymentDate] = useState(editLoan ? toISODate(editLoan.paymentDate) : '')
  const [bankName, setBankName] = useState(editLoan?.bankName || '')

  useEffect(() => {
    setMemberId(editLoan?.memberId || '')
    setBankLoanShare(editLoan ? String(editLoan.bankLoanShare) : '')
    setEmiPaid(editLoan ? String(editLoan.emiPaid) : '0')
    setInterestPaid(editLoan ? String(editLoan.interestPaid) : '0')
    setPaymentDate(editLoan ? toISODate(editLoan.paymentDate) : '')
    setBankName(editLoan?.bankName || '')
  }, [editLoan, open])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!memberId || !bankLoanShare) {
      toast({ title: 'Member and bank loan share are required', variant: 'destructive' })
      return
    }
    setSubmitting(true)
    try {
      const payload = {
        memberId,
        bankLoanShare: Number(bankLoanShare),
        emiPaid: Number(emiPaid || 0),
        interestPaid: Number(interestPaid || 0),
        paymentDate: paymentDate || null,
        bankName: bankName || null,
      }
      const url = editLoan ? `/api/loans/bank/${editLoan.id}` : '/api/loans/bank'
      const method = editLoan ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'Save failed', description: data?.message, variant: 'destructive' })
        return
      }
      onSaved()
    } catch {
      toast({ title: 'Network error', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="premium-dialog p-0 overflow-hidden border-0 sm:max-w-[480px] max-h-[90vh] overflow-y-auto">
        <div className="premium-dialog-header bg-gradient-to-br from-blue-500 via-indigo-500 to-violet-600 px-5 py-4 sm:px-6 sm:py-5">
          <div className="relative flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shrink-0 shadow-lg">
              <Landmark className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <DialogTitle className="text-base sm:text-lg font-bold text-white leading-tight">
                {editLoan ? 'Edit Bank Loan Record' : 'Add Bank Loan Record'}
              </DialogTitle>
              <DialogDescription className="text-xs text-white/80 mt-1">
                Record bank loan share, EMI paid and interest paid.
              </DialogDescription>
            </div>
          </div>
        </div>
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          <div className="space-y-1.5">
            <Label className="text-xs font-medium">Member</Label>
            <Select value={memberId} onValueChange={setMemberId}>
              <SelectTrigger className="premium-input h-10"><SelectValue placeholder="Select member" /></SelectTrigger>
              <SelectContent>
                {members.map((m) => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-medium">Bank Name (optional)</Label>
            <Input value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="State Bank of India" className="premium-input h-10" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Bank Loan Share (₹)</Label>
              <Input type="number" min={0} step="500" value={bankLoanShare} onChange={(e) => setBankLoanShare(e.target.value)} required className="premium-input h-10" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">EMI Paid (₹)</Label>
              <Input type="number" min={0} step="100" value={emiPaid} onChange={(e) => setEmiPaid(e.target.value)} className="premium-input h-10" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Interest Paid (₹)</Label>
              <Input type="number" min={0} step="50" value={interestPaid} onChange={(e) => setInterestPaid(e.target.value)} className="premium-input h-10" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-medium">Payment Date</Label>
            <Input type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} className="premium-input h-10" />
          </div>
          {Number(emiPaid) >= Number(bankLoanShare) && Number(bankLoanShare) > 0 && (
            <div className="flex items-start gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-md px-3 py-2">
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>EMI paid equals or exceeds bank loan share — loan marked as fully paid.</span>
            </div>
          )}
          <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={submitting} className="press-effect h-10">Cancel</Button>
            <Button type="submit" disabled={submitting} className="premium-button text-white font-semibold h-10">
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {editLoan ? 'Update Record' : 'Save Record'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
