'use client'

import { useAppStore, type Section } from '@/lib/store'
import { Home, Users, HandCoins, Settings } from 'lucide-react'
import { cn } from '@/lib/utils'

interface NavItem {
  id: Section
  label: string
  icon: React.ComponentType<{ className?: string }>
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'members', label: 'Members', icon: Users },
  { id: 'loans', label: 'Loans & EMI', icon: HandCoins },
  { id: 'admin', label: 'Admin', icon: Settings },
]

function useNavState() {
  const activeSection = useAppStore((s) => s.activeSection)
  const setActiveSection = useAppStore((s) => s.setActiveSection)
  const admin = useAppStore((s) => s.admin)
  return { activeSection, setActiveSection, admin }
}

/**
 * Desktop top navigation bar — shown below the header on sm+ screens.
 * Renders a horizontal menu of section buttons.
 */
export function TopNav() {
  const { activeSection, setActiveSection, admin } = useNavState()

  return (
    <nav
      className="hidden sm:block bg-card/95 backdrop-blur border-b border-border shadow-sm sticky top-0 z-40"
      aria-label="Primary"
    >
      <div className="max-w-6xl mx-auto px-4">
        <ul className="flex items-center gap-1 h-12">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon
            const isActive = activeSection === item.id
            const isDisabled = !admin && item.id === 'admin'
            return (
              <li key={item.id}>
                <button
                  onClick={() => !isDisabled && setActiveSection(item.id)}
                  disabled={isDisabled}
                  className={cn(
                    'relative flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all',
                    isActive
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground',
                    isDisabled && 'opacity-40 cursor-not-allowed'
                  )}
                  aria-current={isActive ? 'page' : undefined}
                  aria-label={item.label}
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                  {isActive && (
                    <span className="absolute -bottom-[1px] left-1/2 -translate-x-1/2 h-0.5 w-8 bg-primary rounded-full" />
                  )}
                </button>
              </li>
            )
          })}
        </ul>
      </div>
    </nav>
  )
}

/**
 * Mobile bottom navigation — fixed at bottom on small screens only.
 */
export function MobileBottomNav() {
  const { activeSection, setActiveSection, admin } = useNavState()

  return (
    <nav
      className="sm:hidden fixed bottom-0 inset-x-0 z-50 bg-card/95 backdrop-blur border-t shadow-lg"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      aria-label="Primary"
    >
      <div className="grid grid-cols-4">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon
          const isActive = activeSection === item.id
          const isDisabled = !admin && item.id === 'admin'
          return (
            <button
              key={item.id}
              onClick={() => !isDisabled && setActiveSection(item.id)}
              disabled={isDisabled}
              className={cn(
                'relative flex flex-col items-center justify-center gap-0.5 py-2.5 text-[10px] font-medium transition-colors min-h-[56px]',
                isActive
                  ? 'text-primary'
                  : 'text-muted-foreground hover:text-foreground',
                isDisabled && 'opacity-40 cursor-not-allowed'
              )}
              aria-current={isActive ? 'page' : undefined}
              aria-label={item.label}
            >
              <Icon className={cn('w-5 h-5', isActive && 'scale-110 transition-transform')} />
              <span className="leading-tight">{item.label}</span>
              {isActive && (
                <span className="absolute top-0 h-0.5 w-10 bg-primary rounded-b-full" />
              )}
            </button>
          )
        })}
      </div>
    </nav>
  )
}

/**
 * Desktop footer — copyright / signatory line only (no nav buttons,
 * those live in the TopNav on desktop).
 */
export function DesktopFooter() {
  return (
    <footer className="hidden sm:block mt-auto bg-card border-t border-border">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between text-[11px] text-muted-foreground">
        <span>© Aajivika Sakhi Mandal · Authorized Signatory / President Stamp</span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
          DB Connected · Live Sync
        </span>
      </div>
    </footer>
  )
}
