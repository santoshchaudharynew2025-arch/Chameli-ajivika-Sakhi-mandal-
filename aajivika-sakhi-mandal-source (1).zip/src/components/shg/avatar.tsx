'use client'

import { useRef, useState } from 'react'
import { Camera, X, User } from 'lucide-react'
import { cn } from '@/lib/utils'

interface AvatarProps {
  src?: string | null
  name?: string
  size?: number
  className?: string
  /** Show a 3D ring/border around the avatar */
  ring?: boolean
}

/**
 * Displays a member/admin avatar: shows the photo if available,
 * otherwise falls back to a colored circle with initials.
 */
export function Avatar({ src, name, size = 40, className, ring = true }: AvatarProps) {
  const initials = (name || '?')
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

  // Deterministic color from name
  const colors = [
    'from-purple-500 to-pink-500',
    'from-blue-500 to-cyan-500',
    'from-green-500 to-emerald-500',
    'from-amber-500 to-orange-500',
    'from-red-500 to-rose-500',
    'from-indigo-500 to-violet-500',
    'from-teal-500 to-green-500',
    'from-fuchsia-500 to-pink-500',
  ]
  const colorIdx = (name || '').split('').reduce((a, c) => a + c.charCodeAt(0), 0) % colors.length
  const gradient = colors[colorIdx]

  if (src) {
    return (
      <div
        className={cn(
          'relative rounded-full overflow-hidden shrink-0',
          ring && 'ring-2 ring-white shadow-lg',
          className
        )}
        style={{ width: size, height: size }}
      >
        <img src={src} alt={name || 'Avatar'} className="w-full h-full object-cover" />
      </div>
    )
  }

  return (
    <div
      className={cn(
        'relative rounded-full flex items-center justify-center text-white font-bold shrink-0 bg-gradient-to-br',
        gradient,
        ring && 'ring-2 ring-white shadow-lg',
        className
      )}
      style={{ width: size, height: size, fontSize: size * 0.4 }}
    >
      {initials || <User className="w-1/2 h-1/2" />}
    </div>
  )
}

interface PhotoUploadProps {
  value?: string | null
  onChange: (dataUrl: string | null) => void
  name?: string
  size?: number
}

/**
 * 3D photo upload widget with circular preview.
 * Click to upload, hover to see change/remove buttons.
 */
export function PhotoUpload({ value, onChange, name, size = 96 }: PhotoUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragOver, setDragOver] = useState(false)

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) return
    const reader = new FileReader()
    reader.onload = () => {
      onChange(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleFile(file)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files?.[0]
    if (file) handleFile(file)
  }

  return (
    <div className="flex flex-col items-center gap-2">
      <div
        className="relative group cursor-pointer"
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault()
          setDragOver(true)
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
      >
        {/* 3D ring frame */}
        <div
          className={cn(
            'rounded-full p-1 transition-all',
            dragOver
              ? 'bg-primary/30 ring-4 ring-primary/30'
              : 'bg-gradient-to-br from-primary/20 to-primary/5 ring-2 ring-primary/20'
          )}
          style={{ width: size + 16, height: size + 16 }}
        >
          <div className="rounded-full overflow-hidden bg-muted relative" style={{ width: size, height: size }}>
            {value ? (
              <img src={value} alt="Preview" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-muted to-muted/50">
                <User className="w-1/3 h-1/3 text-muted-foreground" />
              </div>
            )}
            {/* Hover overlay */}
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <Camera className="w-1/4 h-1/4 text-white" />
            </div>
          </div>
        </div>
        {/* Remove button */}
        {value && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation()
              onChange(null)
            }}
            className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-destructive text-white flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
            aria-label="Remove photo"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          onChange={handleInputChange}
          className="hidden"
        />
      </div>
      <div className="text-[10px] text-muted-foreground text-center">
        {value ? 'फोटो बदलने के लिए क्लिक करें' : 'फोटो अपलोड करने के लिए क्लिक करें'}
      </div>
    </div>
  )
}
