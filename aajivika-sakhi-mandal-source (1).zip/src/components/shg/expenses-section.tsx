'use client'

import { useEffect, useMemo, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useToast } from '@/hooks/use-toast'
import { useAppStore } from '@/lib/store'
import { formatINR, formatDate, toISODate } from '@/lib/format'
import {
  Search,
  Receipt,
  Plus,
  Pencil,
  Trash2,
  Loader2,
  Calendar,
  IndianRupee,
  FileText,
  List,
} from 'lucide-react'

interface Member { id: string; name: string; memberCode: string }
interface Expense {
  id: string
  memberId: string | null
  category: string
  amount: number
  description: string | null
  expenseDate: string
  member: Member | null
}

// Color coding for expense categories
const CATEGORY_COLORS: Record<string, string> = {
  'रोटी खर्च': 'bg-orange-100 text-orange-700 hover:bg-orange-100',
  'यात्रा खर्च': 'bg-blue-100 text-blue-700 hover:bg-blue-100',
  'चिकित्सा खर्च': 'bg-red-100 text-red-700 hover:bg-red-100',
  'शिक्षा खर्च': 'bg-purple-100 text-purple-700 hover:bg-purple-100',
  'त्योहार खर्च': 'bg-pink-100 text-pink-700 hover:bg-pink-100',
  'अन्य खर्च': 'bg-gray-100 text-gray-700 hover:bg-gray-100',
}

function getCategoryColor(cat: string): string {
  return CATEGORY_COLORS[cat] || 'bg-green-100 text-green-700 hover:bg-green-100'
}

export function ExpensesSection() {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [members, setMembers] = useState<Member[]>([])
  const [categories, setCategories] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterCategory, setFilterCategory] = useState<string>('all')
  const [filterMember, setFilterMember] = useState<string>('all')
  const [refreshKey, setRefreshKey] = useState(0)
  const [addOpen, setAddOpen] = useState(false)
  const admin = useAppStore((s) => s.admin)
  const { toast } = useToast()

  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const [eRes, mRes, cRes] = await Promise.all([
          fetch('/api/expenses', { cache: 'no-store' }),
          fetch('/api/members', { cache: 'no-store' }),
          fetch('/api/expense-categories', { cache: 'no-store' }),
        ])
        const [e, m, c] = await Promise.all([eRes.json(), mRes.json(), cRes.json()])
        if (mounted) {
          if (e.ok) setExpenses(e.expenses)
          if (m.ok) setMembers(m.members.map((x: Member) => ({ id: x.id, name: x.name, memberCode: x.memberCode })))
          if (c.ok) setCategories(c.categories.map((x: { name: string }) => x.name))
        }
      } catch { /* swallow */ } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
  }, [refreshKey])

  const filtered = useMemo(() => {
    return expenses.filter((e) => {
      const q = search.toLowerCase().trim()
      const memberName = e.member?.name || ''
      const memberCode = e.member?.memberCode || ''
      const matchesSearch =
        !q ||
        memberName.toLowerCase().includes(q) ||
        memberCode.toLowerCase().includes(q) ||
        'समूह'.includes(q) ||
        e.category.toLowerCase().includes(q) ||
        (e.description || '').toLowerCase().includes(q)
      const matchesCat = filterCategory === 'all' || e.category === filterCategory
      const matchesMem =
        filterMember === 'all' ||
        (filterMember === '__group__' && !e.memberId) ||
        e.memberId === filterMember
      return matchesSearch && matchesCat && matchesMem
    })
  }, [expenses, search, filterCategory, filterMember])

  const totalAmount = filtered.reduce((s, e) => s + e.amount, 0)
  // Category-wise totals
  const categoryTotals = useMemo(() => {
    const map: Record<string, number> = {}
    for (const e of filtered) {
      map[e.category] = (map[e.category] || 0) + e.amount
    }
    return Object.entries(map).sort((a, b) => b[1] - a[1])
  }, [filtered])

  return (
    <div className="space-y-4">
      {/* Title + Add button */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-baseline gap-2 flex-wrap">
          <h2 className="text-lg font-semibold">खर्च प्रबंधन</h2>
          <span className="text-sm text-muted-foreground">
            ({expenses.length} रिकॉर्ड · कुल {formatINR(expenses.reduce((s, e) => s + e.amount, 0))})
          </span>
        </div>
        {admin && (
          <ExpenseFormDialog
            open={addOpen}
            setOpen={setAddOpen}
            editExpense={null}
            members={members}
            categories={categories}
            onSaved={() => {
              setAddOpen(false)
              setRefreshKey((k) => k + 1)
              toast({ title: 'खर्च सफलतापूर्वक जोड़ा गया' })
            }}
          >
            <Button size="sm" className="h-9">
              <Plus className="w-4 h-4" />
              खर्च जोड़ें
            </Button>
          </ExpenseFormDialog>
        )}
      </div>

      {/* Summary cards by category */}
      {categoryTotals.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {categoryTotals.slice(0, 6).map(([cat, amt]) => (
            <Card key={cat} className="shadow-card">
              <CardContent className="p-3">
                <Badge className={`text-[10px] mb-1 ${getCategoryColor(cat)}`}>{cat}</Badge>
                <div className="text-sm font-bold">{formatINR(amt)}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Search + filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="सदस्य, श्रेणी, विवरण से खोजें..."
            className="pl-9 h-9"
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-[150px] h-9">
            <SelectValue placeholder="श्रेणी" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">सभी श्रेणियाँ</SelectItem>
            {categories.map((c) => (
              <SelectItem key={c} value={c}>{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterMember} onValueChange={setFilterMember}>
          <SelectTrigger className="w-[160px] h-9">
            <SelectValue placeholder="सदस्य" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">सभी (All)</SelectItem>
            <SelectItem value="__group__">समूह (Group)</SelectItem>
            {members.map((m) => (
              <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Total badge for filtered results */}
      {(filterCategory !== 'all' || filterMember !== 'all' || search) && (
        <div className="flex items-center gap-2 flex-wrap">
          <Badge variant="outline" className="text-xs bg-primary/5 border-primary/20">
            छना हुआ कुल: <span className="font-bold ml-1">{formatINR(totalAmount)}</span>
            <span className="ml-1 text-muted-foreground">({filtered.length} रिकॉर्ड)</span>
          </Badge>
        </div>
      )}

      {/* List */}
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-20 bg-muted/60 animate-pulse rounded-lg" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            <Receipt className="w-10 h-10 mx-auto mb-3 opacity-30" />
            कोई खर्च रिकॉर्ड नहीं मिला।
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {filtered.map((e) => (
            <ExpenseCard
              key={e.id}
              expense={e}
              admin={!!admin}
              members={members}
              categories={categories}
              onRefresh={() => setRefreshKey((k) => k + 1)}
            />
          ))}
          {/* Total row */}
          <Card className="bg-primary/5 border-primary/20 shadow-card">
            <CardContent className="p-4 flex items-center justify-between">
              <div className="text-sm font-semibold text-primary">
                कुल खर्च (Total Expenses)
              </div>
              <div className="text-lg font-bold text-primary">{formatINR(totalAmount)}</div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

/* ------------------------------- Expense Card ------------------------------- */
function ExpenseCard({
  expense,
  admin,
  members,
  categories,
  onRefresh,
}: {
  expense: Expense
  admin: boolean
  members: Member[]
  categories: string[]
  onRefresh: () => void
}) {
  const { toast } = useToast()
  const [editOpen, setEditOpen] = useState(false)

  return (
    <Card className="shadow-card lift-on-hover hover:shadow-card-hover">
      <CardContent className="p-4 flex items-start gap-4">
        {/* Icon with category color */}
        <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 shadow-fab ${getCategoryColor(expense.category).replace('text-', 'bg-').split(' ')[0]}/20`}>
          <Receipt className={`w-5 h-5 ${getCategoryColor(expense.category).split(' ')[1]}`} />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            {expense.member ? (
              <>
                <div className="font-medium text-sm">{expense.member.name}</div>
                <span className="text-[10px] text-muted-foreground font-mono">{expense.member.memberCode}</span>
              </>
            ) : (
              <Badge className="bg-indigo-100 text-indigo-700 hover:bg-indigo-100 text-[10px]">
                🏛️ समूह (Group)
              </Badge>
            )}
            <Badge className={`text-[10px] ${getCategoryColor(expense.category)}`}>
              {expense.category}
            </Badge>
          </div>
          <div className="flex items-center gap-3 mt-1 flex-wrap text-xs">
            <span className="font-bold text-base text-primary">
              <IndianRupee className="w-3.5 h-3.5 inline -mt-0.5" />
              {expense.amount.toLocaleString('en-IN')}
            </span>
            <span className="text-muted-foreground flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {formatDate(expense.expenseDate)}
            </span>
          </div>
          {expense.description && (
            <div className="text-xs text-muted-foreground mt-1.5 flex items-start gap-1.5">
              <FileText className="w-3 h-3 mt-0.5 shrink-0" />
              <span className="leading-relaxed">{expense.description}</span>
            </div>
          )}
        </div>

        {/* Actions */}
        {admin && (
          <div className="flex items-center gap-1 shrink-0">
            <ExpenseFormDialog
              open={editOpen}
              setOpen={setEditOpen}
              editExpense={expense}
              members={members}
              categories={categories}
              onSaved={() => {
                setEditOpen(false)
                onRefresh()
                toast({ title: 'खर्च अपडेट हुआ' })
              }}
            >
              <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Edit">
                <Pencil className="w-3.5 h-3.5" />
              </Button>
            </ExpenseFormDialog>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-destructive hover:text-destructive"
              aria-label="Delete"
              onClick={async () => {
                if (!confirm('यह खर्च रिकॉर्ड हटाना चाहते हैं?')) return
                const r = await fetch(`/api/expenses/${expense.id}`, { method: 'DELETE' })
                if (r.ok) {
                  onRefresh()
                  toast({ title: 'खर्च हटाया गया' })
                } else {
                  toast({ title: 'हटाने में विफल', variant: 'destructive' })
                }
              }}
            >
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

/* --------------------------- Expense Form Dialog --------------------------- */
function ExpenseFormDialog({
  open,
  setOpen,
  editExpense,
  members,
  categories,
  onSaved,
  children,
}: {
  open: boolean
  setOpen: (v: boolean) => void
  editExpense: Expense | null
  members: Member[]
  categories: string[]
  onSaved: () => void
  children: React.ReactNode
}) {
  const { toast } = useToast()
  const [submitting, setSubmitting] = useState(false)
  const [memberId, setMemberId] = useState('')
  const [category, setCategory] = useState('')
  const [amount, setAmount] = useState('')
  const [description, setDescription] = useState('')
  const [expenseDate, setExpenseDate] = useState('')

  useEffect(() => {
    if (open) {
      // For group expenses (memberId null), select the "__group__" option; else the member id
      setMemberId(editExpense?.memberId || (editExpense && !editExpense.member ? '__group__' : ''))
      setCategory(editExpense?.category || (categories[0] || ''))
      setAmount(editExpense ? String(editExpense.amount) : '')
      setDescription(editExpense?.description || '')
      setExpenseDate(editExpense ? toISODate(editExpense.expenseDate) : toISODate(new Date()))
    }
  }, [editExpense, open, categories])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // memberId is optional — empty means group expense
    if (!category || !amount || !expenseDate) {
      toast({ title: 'श्रेणी, राशि और तिथि आवश्यक हैं', variant: 'destructive' })
      return
    }
    setSubmitting(true)
    try {
      const payload = {
        // Send memberId only if a real member is selected; otherwise null (group expense)
        memberId: memberId && memberId !== '__group__' ? memberId : null,
        category,
        amount: Number(amount),
        description: description || null,
        expenseDate,
      }
      const url = editExpense ? `/api/expenses/${editExpense.id}` : '/api/expenses'
      const method = editExpense ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'सहेजने में विफल', description: data?.message, variant: 'destructive' })
        return
      }
      onSaved()
    } catch {
      toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="premium-dialog p-0 overflow-hidden border-0 sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        {/* Gradient header */}
        <div className="premium-dialog-header bg-gradient-to-br from-amber-500 via-orange-500 to-red-500 px-5 py-4 sm:px-6 sm:py-5">
          <div className="relative flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shrink-0 shadow-lg">
              <Receipt className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <DialogTitle className="text-base sm:text-lg font-bold text-white leading-tight">
                {editExpense ? 'खर्च संपादित करें' : 'नया खर्च जोड़ें'}
              </DialogTitle>
              <DialogDescription className="text-xs text-white/80 mt-1">
                सदस्य पर हुए खर्च का विवरण दर्ज करें। सदस्य न चुनें तो समूह (Group) का खर्च दर्ज होगा।
              </DialogDescription>
            </div>
          </div>
        </div>
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          {/* Member + Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">
                सदस्य <span className="text-muted-foreground font-normal">(वैकल्पिक — न चुनें तो समूह का खर्च)</span>
              </Label>
              <Select value={memberId || '__group__'} onValueChange={setMemberId}>
                <SelectTrigger className="premium-input h-10"><SelectValue placeholder="सदस्य चुनें" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__group__" className="text-indigo-700 font-medium">
                    🏛️ समूह (Group — All)
                  </SelectItem>
                  {members.map((m) => (
                    <SelectItem key={m.id} value={m.id}>{m.name} ({m.memberCode})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">खर्च श्रेणी *</Label>
              <CategoryPicker
                value={category}
                onChange={setCategory}
                categories={categories}
                placeholder="श्रेणी चुनें या स्वयं लिखें"
              />
            </div>
          </div>

          {/* Amount + Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">राशि (₹) *</Label>
              <Input
                type="number"
                min={0}
                step="1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
                placeholder="500"
                className="premium-input h-10"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">तिथि *</Label>
              <Input
                type="date"
                value={expenseDate}
                onChange={(e) => setExpenseDate(e.target.value)}
                required
                className="premium-input h-10"
              />
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium">पूरा विवरण (Description)</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="खर्च का विस्तृत विवरण लिखें... जैसे: मासिक राशन खरीद, दवा एवं डॉक्टर फीस, यात्रा का कारण, etc."
              rows={3}
              className="premium-input resize-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={submitting} className="press-effect h-10">
              रद्द करें
            </Button>
            <Button type="submit" disabled={submitting} className="premium-button text-white font-semibold h-10">
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {editExpense ? 'अपडेट करें' : 'खर्च जोड़ें'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

/* --------------------- Category Picker (dropdown + self-type) --------------------- */
// A hybrid input: shows existing categories as a dropdown, plus a
// "स्वयं लिखें (Self)" option that reveals a free-text input so the
// user can type any custom category name on the fly.
export function CategoryPicker({
  value,
  onChange,
  categories,
  placeholder,
  compact = false,
}: {
  value: string
  onChange: (v: string) => void
  categories: string[]
  placeholder: string
  compact?: boolean
}) {
  // "self" mode is active when the current value is NOT in the predefined categories
  // (and is non-empty). Otherwise we are in select mode.
  const isSelfMode = value !== '' && !categories.includes(value)
  const [selfMode, setSelfMode] = useState(false)
  const mode: 'select' | 'self' = selfMode || isSelfMode ? 'self' : 'select'

  const handleSelectChange = (v: string) => {
    if (v === '__self__') {
      setSelfMode(true)
      onChange('')
    } else {
      setSelfMode(false)
      onChange(v)
    }
  }

  const handleSwitchToSelect = () => {
    setSelfMode(false)
    onChange(categories[0] || '')
  }

  if (mode === 'self') {
    return (
      <div className="flex gap-1.5">
        <Input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="श्रेणी स्वयं लिखें..."
          className={compact ? 'flex-1 h-8 text-xs' : 'flex-1'}
          autoFocus
        />
        <Button
          type="button"
          variant="outline"
          size="icon"
          className={compact ? 'h-8 w-8' : ''}
          onClick={handleSwitchToSelect}
          title="सूची से चुनें"
        >
          <List className={compact ? 'w-3.5 h-3.5' : 'w-4 h-4'} />
        </Button>
      </div>
    )
  }

  return (
    <Select value={categories.includes(value) ? value : ''} onValueChange={handleSelectChange}>
      <SelectTrigger className={compact ? 'h-8 text-xs' : ''}>
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {categories.map((c) => (
          <SelectItem key={c} value={c}>{c}</SelectItem>
        ))}
        <SelectItem value="__self__" className="text-primary font-medium">
          ✍️ स्वयं लिखें (Self)...
        </SelectItem>
      </SelectContent>
    </Select>
  )
}
