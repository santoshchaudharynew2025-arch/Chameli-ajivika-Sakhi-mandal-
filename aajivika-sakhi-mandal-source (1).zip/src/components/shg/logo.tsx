'use client'

import { useAppStore } from '@/lib/store'
import { LogOut, ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface LogoProps {
  className?: string
  size?: number
}

/**
 * The official Aajivika Sakhi Mandal logo — a colorful circle of
 * stylized human figures representing community unity.
 */
export function Logo({ className, size = 40 }: LogoProps) {
  return (
    <img
      src="/shg-logo.png"
      alt="Aajivika Sakhi Mandal Logo"
      width={size}
      height={size}
      className={cn('object-contain', className)}
    />
  )
}

/**
 * Brand block used in the sidebar header and mobile top bar.
 * Shows the logo + group name + optional group ID + optional joining date.
 */
export function BrandBlock({
  groupName,
  groupCode,
  foundingDate,
  compact = false,
}: {
  groupName?: string | null
  groupCode?: string | null
  foundingDate?: string | null
  compact?: boolean
}) {
  return (
    <div className="flex items-center gap-2.5 min-w-0">
      <div
        className={cn(
          'rounded-xl bg-white shadow-fab flex items-center justify-center shrink-0 p-1',
          compact ? 'w-9 h-9' : 'w-11 h-11'
        )}
      >
        <Logo size={compact ? 28 : 36} />
      </div>
      <div className="min-w-0">
        <div className={cn('font-bold leading-tight truncate', compact ? 'text-xs' : 'text-sm')}>
          {groupName || 'Aajivika Sakhi Mandal'}
        </div>
        <div className="text-[10px] text-muted-foreground leading-tight flex items-center gap-1.5 flex-wrap">
          {groupCode && (
            <span className="font-mono font-semibold text-primary">{groupCode}</span>
          )}
          {groupCode && foundingDate && <span aria-hidden>·</span>}
          {foundingDate && <span>जनित {foundingDate}</span>}
        </div>
      </div>
    </div>
  )
}

/**
 * Compact logout pill — used in the mobile top bar.
 */
export function LogoutPill({ onLogout }: { onLogout: () => void }) {
  return (
    <button
      onClick={onLogout}
      className="press-effect inline-flex items-center gap-1 h-7 px-2 rounded-full text-[11px] font-medium text-destructive bg-destructive/5 border border-destructive/20 hover:bg-destructive/10 transition-colors shrink-0"
      aria-label="Logout"
    >
      <LogOut className="w-3 h-3" />
      <span className="hidden xs:inline">Logout</span>
    </button>
  )
}

/**
 * Admin avatar pill — shows admin name with a shield icon.
 */
export function AdminPill({ name }: { name?: string | null }) {
  return (
    <div className="inline-flex items-center gap-1.5 h-7 px-2 rounded-full text-[11px] font-medium text-primary bg-primary/5 border border-primary/15 shrink-0">
      <ShieldCheck className="w-3 h-3" />
      <span className="truncate max-w-[80px]">{name || 'admin'}</span>
    </div>
  )
}

/**
 * Convenience hook to fetch group settings + admin info for branding.
 * Returns null while loading.
 */
export function useBrandingData() {
  const admin = useAppStore((s) => s.admin)
  return { admin }
}
