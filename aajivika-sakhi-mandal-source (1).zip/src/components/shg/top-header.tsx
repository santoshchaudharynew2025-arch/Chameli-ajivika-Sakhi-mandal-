'use client'

import { useEffect, useState } from 'react'
import { useAppStore, type Section } from '@/lib/store'
import { Badge } from '@/components/ui/badge'
import { Calendar, Database, Hash, Clock } from 'lucide-react'
import { formatTodayLongIST, formatTimeIST } from '@/lib/format'
import { Logo } from '@/components/shg/logo'

interface HeaderData {
  registrationNo: string | null
  groupCode: string | null
  groupName: string | null
  foundingDate: string | null
  meetingDay: string
}

const SECTION_META: Record<Section, { title: string; subtitle: string }> = {
  home: { title: 'Dashboard', subtitle: 'Overview of group savings and loans' },
  members: { title: 'Members', subtitle: 'सदस्य प्रोफाइल एवं हस्ताक्षर रजिस्टर' },
  loans: { title: 'Loans & EMI', subtitle: 'Private and bank loan records' },
  expenses: { title: 'खर्च प्रबंधन', subtitle: 'सदस्यों पर हुए खर्च का विवरण' },
  weekly: { title: 'साप्ताहिक जमा', subtitle: 'हर बुधवार ₹10/सदस्य जमा प्रबंधन' },
  meetings: { title: 'प्रस्ताव', subtitle: 'बैठक के निर्णय एवं वित्तीय सारांश' },
  reports: { title: 'वित्तीय रिपोर्ट्स', subtitle: 'Complete financial reporting dashboard' },
  admin: { title: 'Settings', subtitle: 'Group configuration and member management' },
}

export function TopHeader({ data }: { data: HeaderData | null }) {
  const activeSection = useAppStore((s) => s.activeSection)
  const admin = useAppStore((s) => s.admin)
  const [dbLive, setDbLive] = useState(true)
  const meta = SECTION_META[activeSection]

  // Live Indian time (updates every minute)
  const [istTime, setIstTime] = useState('')
  const [istDate, setIstDate] = useState('')

  useEffect(() => {
    let mounted = true
    const check = async () => {
      try {
        const r = await fetch('/api/dashboard', { cache: 'no-store' })
        if (mounted) setDbLive(r.ok)
      } catch {
        if (mounted) setDbLive(false)
      }
    }
    check()
    const id = setInterval(check, 15000)
    return () => {
      mounted = false
      clearInterval(id)
    }
  }, [])

  // Update IST clock every 30 seconds
  useEffect(() => {
    const update = () => {
      setIstTime(formatTimeIST())
      setIstDate(formatTodayLongIST())
    }
    update()
    const id = setInterval(update, 30000)
    return () => clearInterval(id)
  }, [])

  return (
    <header className="sticky top-0 z-20 bg-card/95 backdrop-blur border-b border-border shadow-card">
      <div className="px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          {/* Left: logo + page title */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-white shadow-card flex items-center justify-center p-1 shrink-0 hidden sm:flex">
              <Logo size={32} />
            </div>
            <div className="min-w-0">
              <h1 className="text-xl sm:text-2xl font-semibold text-foreground leading-tight">
                {meta.title}
              </h1>
              <p className="text-xs sm:text-sm text-muted-foreground mt-0.5">
                {meta.subtitle}
              </p>
            </div>
          </div>

          {/* Right: live status + meta */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* SHG group code badge — prominent */}
            {data?.groupCode && (
              <Badge className="bg-primary text-primary-foreground text-xs font-mono font-semibold">
                <Hash className="w-3 h-3 mr-0.5" />
                {data.groupCode}
              </Badge>
            )}
            <Badge
              variant="outline"
              className="bg-green-50 text-green-700 border-green-200 text-xs font-normal"
            >
              <Database className="w-3 h-3 mr-1" />
              {dbLive ? 'DB Connected' : 'Reconnecting'}
            </Badge>
            <Badge
              variant="outline"
              className="text-xs font-normal hidden sm:inline-flex"
            >
              <Calendar className="w-3 h-3 mr-1" />
              {data?.meetingDay || 'Wednesday'} meeting
            </Badge>
            {/* Live IST date + time badge */}
            <Badge
              variant="outline"
              className="text-xs font-normal hidden md:inline-flex bg-blue-50/50 border-blue-200"
              title="Indian Standard Time"
            >
              <Calendar className="w-3 h-3 mr-1 text-blue-600" />
              {istDate}
            </Badge>
            <Badge
              variant="outline"
              className="text-xs font-mono font-semibold bg-blue-50 text-blue-700 border-blue-200"
              title="Indian Standard Time (IST)"
            >
              <Clock className="w-3 h-3 mr-1" />
              {istTime} <span className="text-[9px] font-normal ml-0.5 opacity-70">IST</span>
            </Badge>
          </div>
        </div>
      </div>
    </header>
  )
}
