'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Checkbox } from '@/components/ui/checkbox'
import { Avatar } from '@/components/shg/avatar'
import {
  Dialog, DialogContent, DialogTitle, DialogDescription, DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { useAppStore } from '@/lib/store'
import { formatINR, formatDate, toISODate } from '@/lib/format'
import {
  CalendarCheck, Plus, Pencil, Loader2, X, MapPin, Clock,
  Users, User, FileText, IndianRupee, HandCoins, ArrowRight, Landmark,
  MessageCircle, Printer, ChevronDown, ChevronUp,
  Wallet, TrendingDown, ShieldCheck, BookOpen,
} from 'lucide-react'

interface Member { id: string; name: string; post: string; phone: string | null }
interface Meeting {
  id: string
  resolutionNo: number
  meetingDate: string
  location: string | null
  meetingTime: string | null
  chairperson: string | null
  secretary: string | null
  treasurer: string | null
  bkName: string | null
  presentCount: number
  absentCount: number
  presentMembers: string | null
  absentMembers: string | null
  topic: string | null
  decisions: string | null
  totalSavings: number
  totalPending: number
  totalAdvance: number
  totalLoanGiven: number
  totalLoanCollected: number
  groupFundBalance: number
  totalExpenses: number
  nextMeetingDate: string | null
  nextMeetingLocation: string | null
  nextMeetingHost: string | null
  notes: string | null
}
interface GroupSettings {
  groupName: string | null
  presidentName: string | null
  authorizedSignatoryName: string | null
}

export function MeetingsSection() {
  const [meetings, setMeetings] = useState<Meeting[]>([])
  const [members, setMembers] = useState<Member[]>([])
  const [groupSettings, setGroupSettings] = useState<GroupSettings | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshKey, setRefreshKey] = useState(0)
  const [addOpen, setAddOpen] = useState(false)
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const admin = useAppStore((s) => s.admin)
  const { toast } = useToast()

  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const [mRes, memRes, sRes] = await Promise.all([
          fetch('/api/meetings', { cache: 'no-store' }),
          fetch('/api/members', { cache: 'no-store' }),
          fetch('/api/settings', { cache: 'no-store' }),
        ])
        const [m, mem, s] = await Promise.all([mRes.json(), memRes.json(), sRes.json()])
        if (mounted) {
          if (m.ok) setMeetings(m.meetings)
          if (mem.ok) setMembers(mem.members.map((x: Member) => ({ id: x.id, name: x.name, post: x.post, phone: x.phone })))
          if (s.ok) setGroupSettings(s.settings)
        }
      } catch { /* swallow */ } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
  }, [refreshKey])

  // Auto-fill officials from settings + members
  const getOfficial = (post: string) => members.find((m) => m.post === post)?.name || ''
  const defaultChairperson = groupSettings?.presidentName || getOfficial('अध्यक्ष') || ''
  const defaultSecretary = getOfficial('सचिव') || ''
  const defaultTreasurer = getOfficial('कोषाध्यक्ष') || ''
  const defaultBK = getOfficial('बी.के.') || ''
  const groupName = groupSettings?.groupName || 'आजीविका सखी मंडल'

  const buildWhatsAppMessage = (m: Meeting) => {
    let msg = `🌸 *${groupName}*\n*प्रस्ताव संख्या - ${String(m.resolutionNo).padStart(2, '0')}*\n\n`
    msg += `📅 तिथि: ${formatDate(m.meetingDate)}\n`
    msg += `📍 स्थान: ${m.location || '—'}\n`
    if (m.meetingTime) msg += `⏰ समय: ${m.meetingTime}\n`
    msg += `👤 अध्यक्ष: ${m.chairperson || '—'}\n`
    msg += `✍️ सचिव: ${m.secretary || '—'}\n`
    if (m.treasurer) msg += `💰 कोषाध्यक्ष: ${m.treasurer}\n`
    if (m.bkName) msg += `📖 बी.के.: ${m.bkName}\n`
    msg += `👥 उपस्थित: ${m.presentCount} | अनुपस्थित: ${m.absentCount}\n\n`
    msg += `📝 *विषय:* ${m.topic || '—'}\n\n`
    msg += `💰 *वित्तीय सारांश:*\n`
    msg += `✅ जमा: ${formatINR(m.totalSavings)}\n`
    msg += `⏳ बकाया: ${formatINR(m.totalPending)}\n`
    msg += `⬆️ एडवांस: ${formatINR(m.totalAdvance)}\n`
    msg += `💸 लोन दिया: ${formatINR(m.totalLoanGiven)}\n`
    msg += `💰 लोन वसूली: ${formatINR(m.totalLoanCollected)}\n`
    msg += `📋 खर्च: ${formatINR(m.totalExpenses)}\n`
    msg += `🏦 समूह कोष: ${formatINR(m.groupFundBalance)}\n\n`
    if (m.decisions) {
      try {
        const decisions = JSON.parse(m.decisions) as Array<{ desc: string }>
        msg += `📋 *निर्णय:*\n`
        decisions.forEach((d, i) => { msg += `${i + 1}. ${d.desc}\n` })
      } catch { /* */ }
    }
    msg += `\n📅 *अगली बैठक:* ${m.nextMeetingDate ? formatDate(m.nextMeetingDate) : '—'}\n`
    if (m.nextMeetingHost) msg += `🏠 मेज़बान: ${m.nextMeetingHost}\n`
    if (m.nextMeetingLocation) msg += `📍 स्थान: ${m.nextMeetingLocation}\n`
    return encodeURIComponent(msg)
  }

  const shareWhatsApp = (m: Meeting) => {
    window.open(`https://wa.me/?text=${buildWhatsAppMessage(m)}`, '_blank')
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-baseline gap-2 flex-wrap">
          <h2 className="text-lg font-semibold">प्रस्ताव (Meeting Resolutions)</h2>
          <span className="text-sm text-muted-foreground">({meetings.length} बैठकें)</span>
        </div>
        {admin && (
          <MeetingFormDialog
            open={addOpen}
            setOpen={setAddOpen}
            editMeeting={null}
            members={members}
            groupName={groupName}
            defaultChairperson={defaultChairperson}
            defaultSecretary={defaultSecretary}
            defaultTreasurer={defaultTreasurer}
            defaultBK={defaultBK}
            onSaved={() => { setAddOpen(false); setRefreshKey((k) => k + 1) }}
          >
            <Button size="sm" className="h-9 premium-button text-white font-semibold">
              <Plus className="w-4 h-4" />नया प्रस्ताव
            </Button>
          </MeetingFormDialog>
        )}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => <div key={i} className="h-32 bg-muted/60 animate-pulse rounded-xl" />)}
        </div>
      ) : meetings.length === 0 ? (
        <Card><CardContent className="py-12 text-center text-sm text-muted-foreground">
          <CalendarCheck className="w-10 h-10 mx-auto mb-3 opacity-30" />
          कोई बैठक रिकॉर्ड नहीं है।
        </CardContent></Card>
      ) : (
        <div className="space-y-3">
          {meetings.map((m) => {
            const isExpanded = expandedId === m.id
            let decisions: Array<{ desc: string; action?: string; date?: string; member?: string; remark?: string }> = []
            try { if (m.decisions) decisions = JSON.parse(m.decisions) } catch { /* */ }
            return (
              <Card key={m.id} className="premium-card overflow-hidden">
                {/* Orange header — group name + प्रस्ताव संख्या */}
                <div className="bg-gradient-to-r from-orange-500 to-amber-500 px-4 py-3 text-white">
                  <div className="text-center font-bold text-sm mb-1">🌸 {groupName}</div>
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-bold text-sm">प्रस्ताव संख्या - {String(m.resolutionNo).padStart(2, '0')}</div>
                    <div className="flex items-center gap-1">
                      <Button size="sm" variant="ghost" className="h-7 text-[10px] text-white bg-white/20 hover:bg-white/30" onClick={() => shareWhatsApp(m)}>
                        <MessageCircle className="w-3 h-3 mr-1" />WhatsApp
                      </Button>
                      <Button size="sm" variant="ghost" className="h-7 w-7 text-white bg-white/20 hover:bg-white/30 p-0" onClick={() => window.print()}>
                        <Printer className="w-3 h-3" />
                      </Button>
                      {admin && <EditMeetingButton meeting={m} members={members} groupName={groupName} defaults={{ chairperson: defaultChairperson, secretary: defaultSecretary, treasurer: defaultTreasurer, bkName: defaultBK }} onSaved={() => setRefreshKey((k) => k + 1)} />}
                    </div>
                  </div>
                </div>

                <CardContent className="p-4 space-y-3">
                  {/* Officials grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                    <OfficialBox icon={<ShieldCheck className="w-3 h-3" />} label="अध्यक्ष" value={m.chairperson || '—'} />
                    <OfficialBox icon={<FileText className="w-3 h-3" />} label="सचिव" value={m.secretary || '—'} />
                    <OfficialBox icon={<Wallet className="w-3 h-3" />} label="कोषाध्यक्ष" value={m.treasurer || '—'} />
                    <OfficialBox icon={<BookOpen className="w-3 h-3" />} label="बी.के." value={m.bkName || '—'} />
                  </div>

                  {/* Meeting details */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                    <DetailItem icon={<CalendarCheck className="w-3 h-3" />} label="तिथि" value={formatDate(m.meetingDate)} />
                    <DetailItem icon={<Clock className="w-3 h-3" />} label="समय" value={m.meetingTime || '—'} />
                    <DetailItem icon={<MapPin className="w-3 h-3" />} label="स्थान" value={m.location || '—'} />
                  </div>

                  {m.topic && (
                    <div className="text-xs bg-primary/5 rounded-lg p-2 border border-primary/10">
                      <span className="font-semibold text-primary">विषय: </span>{m.topic}
                    </div>
                  )}

                  {/* Attendance */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">
                      <Users className="w-3 h-3 mr-1" />{m.presentCount} उपस्थित
                    </Badge>
                    {m.absentCount > 0 && (
                      <Badge className="bg-red-100 text-red-700 hover:bg-red-100 text-xs">{m.absentCount} अनुपस्थित</Badge>
                    )}
                  </div>

                  {/* Financial summary */}
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                    <FinBox label="जमा" value={formatINR(m.totalSavings)} color="text-green-600" />
                    <FinBox label="बकाया" value={formatINR(m.totalPending)} color="text-amber-600" />
                    <FinBox label="एडवांस" value={formatINR(m.totalAdvance)} color="text-blue-600" />
                    <FinBox label="खर्च" value={formatINR(m.totalExpenses)} color="text-red-600" />
                    <FinBox label="लोन दिया" value={formatINR(m.totalLoanGiven)} color="text-orange-600" />
                    <FinBox label="लोन वसूल" value={formatINR(m.totalLoanCollected)} color="text-purple-600" />
                  </div>

                  {/* Group fund balance — prominent */}
                  <div className="rounded-xl bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 p-3 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Wallet className="w-5 h-5 text-primary" />
                      <div>
                        <div className="text-[10px] text-muted-foreground uppercase tracking-wide">समूह कोष (Group Fund)</div>
                        <div className="text-lg font-bold text-primary">{formatINR(m.groupFundBalance)}</div>
                      </div>
                    </div>
                  </div>

                  {/* Expand button */}
                  {(decisions.length > 0 || m.notes || m.nextMeetingDate || m.presentMembers) && (
                    <Button variant="ghost" size="sm" className="w-full text-xs h-8" onClick={() => setExpandedId(isExpanded ? null : m.id)}>
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5 mr-1" /> : <ChevronDown className="w-3.5 h-3.5 mr-1" />}
                      {isExpanded ? 'कम देखें' : 'पूरा विवरण देखें'}
                    </Button>
                  )}

                  {isExpanded && (
                    <div className="space-y-3 pt-2 border-t">
                      {/* Decisions */}
                      {decisions.length > 0 && (
                        <div>
                          <div className="premium-section-label"><FileText className="w-3 h-3" />बैठक के निर्णय</div>
                          <div className="space-y-2">
                            {decisions.map((d, i) => (
                              <div key={i} className="rounded-lg bg-muted/40 border border-border/50 p-2.5 text-xs">
                                <div className="font-medium">{i + 1}. {d.desc}</div>
                                <div className="flex gap-3 mt-1 text-[10px] text-muted-foreground flex-wrap">
                                  {d.action && <span>कार्यवाही: <span className="font-medium text-foreground">{d.action}</span></span>}
                                  {d.member && <span>सदस्य: <span className="font-medium text-foreground">{d.member}</span></span>}
                                  {d.date && <span>दिनांक: <span className="font-medium text-foreground">{formatDate(d.date)}</span></span>}
                                  {d.remark && <span>टिप्पणी: <span className="font-medium text-foreground">{d.remark}</span></span>}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Present members */}
                      {m.presentMembers && (
                        <div>
                          <div className="premium-section-label"><Users className="w-3 h-3" />उपस्थित सदस्य ({m.presentCount})</div>
                          <div className="text-xs text-muted-foreground">{m.presentMembers}</div>
                        </div>
                      )}

                      {/* Absent members */}
                      {m.absentMembers && (
                        <div>
                          <div className="premium-section-label text-red-600"><Users className="w-3 h-3" />अनुपस्थित सदस्य ({m.absentCount})</div>
                          <div className="text-xs text-red-600">{m.absentMembers}</div>
                        </div>
                      )}

                      {/* Next meeting */}
                      {m.nextMeetingDate && (
                        <div className="rounded-lg bg-blue-50 border border-blue-100 p-3">
                          <div className="text-xs font-semibold text-blue-700 flex items-center gap-1.5 mb-1">
                            <ArrowRight className="w-3.5 h-3.5" />अगली बैठक
                          </div>
                          <div className="text-xs space-y-0.5">
                            <div>📅 तिथि: <span className="font-semibold">{formatDate(m.nextMeetingDate)}</span></div>
                            {m.nextMeetingHost && <div>🏠 मेज़बान: <span className="font-semibold">{m.nextMeetingHost}</span></div>}
                            {m.nextMeetingLocation && <div>📍 स्थान: <span className="font-semibold">{m.nextMeetingLocation}</span></div>}
                          </div>
                        </div>
                      )}

                      {m.notes && <div className="text-xs text-muted-foreground italic">📝 {m.notes}</div>}
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}

/* ----------- Edit Meeting Button ----------- */
function EditMeetingButton({ meeting, members, groupName, defaults, onSaved }: {
  meeting: Meeting; members: Member[]; groupName: string
  defaults: { chairperson: string; secretary: string; treasurer: string; bkName: string }
  onSaved: () => void
}) {
  const [open, setOpen] = useState(false)
  return (
    <MeetingFormDialog open={open} setOpen={setOpen} editMeeting={meeting} members={members} groupName={groupName}
      defaultChairperson={defaults.chairperson} defaultSecretary={defaults.secretary}
      defaultTreasurer={defaults.treasurer} defaultBK={defaults.bkName} onSaved={onSaved}>
      <Button size="sm" variant="ghost" className="h-7 w-7 text-white bg-white/20 hover:bg-white/30 p-0" onClick={(e) => e.stopPropagation()}>
        <Pencil className="w-3 h-3" />
      </Button>
    </MeetingFormDialog>
  )
}

/* ===================== Meeting Form Dialog ===================== */
function MeetingFormDialog({ open, setOpen, editMeeting, members, groupName, defaultChairperson, defaultSecretary, defaultTreasurer, defaultBK, onSaved, children }: {
  open: boolean; setOpen: (v: boolean) => void; editMeeting: Meeting | null
  members: Member[]; groupName: string
  defaultChairperson: string; defaultSecretary: string; defaultTreasurer: string; defaultBK: string
  onSaved: () => void; children: React.ReactNode
}) {
  const { toast } = useToast()
  const [submitting, setSubmitting] = useState(false)
  const [meetingDate, setMeetingDate] = useState('')
  const [location, setLocation] = useState('')
  const [meetingTime, setMeetingTime] = useState('11:00 AM')
  const [chairperson, setChairperson] = useState('')
  const [secretary, setSecretary] = useState('')
  const [treasurer, setTreasurer] = useState('')
  const [bkName, setBkName] = useState('')
  const [presentMemberIds, setPresentMemberIds] = useState<Set<string>>(new Set())
  const [topic, setTopic] = useState('')
  const [decisionsText, setDecisionsText] = useState('')
  const [totalSavings, setTotalSavings] = useState('')
  const [totalPending, setTotalPending] = useState('')
  const [totalAdvance, setTotalAdvance] = useState('')
  const [totalLoanGiven, setTotalLoanGiven] = useState('')
  const [totalLoanCollected, setTotalLoanCollected] = useState('')
  const [totalExpenses, setTotalExpenses] = useState('')
  const [groupFundBalance, setGroupFundBalance] = useState('')
  const [nextMeetingDate, setNextMeetingDate] = useState('')
  const [nextMeetingHost, setNextMeetingHost] = useState('')
  const [nextMeetingLocation, setNextMeetingLocation] = useState('')
  const [notes, setNotes] = useState('')
  // Loan transactions within meeting
  const [loanTxns, setLoanTxns] = useState<Array<{ type: string; memberId: string; memberName: string; amount: string; interest: string; interestRate: string; loanType: string; bankName: string; liveBalance: string }>>([])
  const todayStr = toISODate(new Date())

  useEffect(() => {
    if (open) {
      setMeetingDate(editMeeting ? toISODate(editMeeting.meetingDate) : toISODate(new Date()))
      setLocation(editMeeting?.location || '')
      setMeetingTime(editMeeting?.meetingTime || '11:00 AM')
      setChairperson(editMeeting?.chairperson || defaultChairperson)
      setSecretary(editMeeting?.secretary || defaultSecretary)
      setTreasurer(editMeeting?.treasurer || defaultTreasurer)
      setBkName(editMeeting?.bkName || defaultBK)
      // Parse present members
      if (editMeeting?.presentMembers) {
        const names = editMeeting.presentMembers.split(',').map((s) => s.trim())
        const ids = new Set<string>()
        members.forEach((m) => {
          if (names.some((n) => m.name.includes(n) || n.includes(m.name))) ids.add(m.id)
        })
        setPresentMemberIds(ids)
      } else {
        setPresentMemberIds(new Set(members.map((m) => m.id))) // default all present
      }
      setTopic(editMeeting?.topic || '')
      if (editMeeting?.decisions) {
        try { const d = JSON.parse(editMeeting.decisions) as Array<{ desc: string }>; setDecisionsText(d.map((x) => x.desc).join('\n')) } catch { setDecisionsText('') }
      } else setDecisionsText('')
      setTotalSavings(String(editMeeting?.totalSavings || ''))
      setTotalPending(String(editMeeting?.totalPending || ''))
      setTotalAdvance(String(editMeeting?.totalAdvance || ''))
      setTotalLoanGiven(String(editMeeting?.totalLoanGiven || ''))
      setTotalLoanCollected(String(editMeeting?.totalLoanCollected || ''))
      setTotalExpenses(String(editMeeting?.totalExpenses || ''))
      setGroupFundBalance(String(editMeeting?.groupFundBalance || ''))
      setNextMeetingDate(editMeeting?.nextMeetingDate ? toISODate(editMeeting.nextMeetingDate) : '')
      setNextMeetingHost(editMeeting?.nextMeetingHost || '')
      setNextMeetingLocation(editMeeting?.nextMeetingLocation || '')
      setNotes(editMeeting?.notes || '')
      setLoanTxns([])
    }
  }, [editMeeting, open, members, defaultChairperson, defaultSecretary, defaultTreasurer, defaultBK])

  const addLoanTxn = (type: string) => {
    setLoanTxns((prev) => [...prev, { type, memberId: '', memberName: '', amount: '', interest: '', interestRate: '', loanType: type === 'loan_payment' ? 'bank' : '', bankName: '', liveBalance: '' }])
  }
  const removeLoanTxn = (idx: number) => {
    setLoanTxns((prev) => prev.filter((_, i) => i !== idx))
  }
  const updateLoanTxn = async (idx: number, field: string, value: string) => {
    setLoanTxns((prev) => prev.map((t, i) => {
      if (i !== idx) return t
      const updated = { ...t, [field]: value }
      if (field === 'memberId') {
        const m = members.find((x) => x.id === value)
        updated.memberName = m?.name || ''
        // Fetch live loan balance for this member
        if (t.type === 'loan_payment') {
          fetchLiveBalance(value, t.loanType).then((bal) => {
            setLoanTxns((prev2) => prev2.map((t2, i2) => i2 === idx ? { ...t2, liveBalance: bal } : t2))
          })
        }
      }
      if (field === 'loanType' && t.type === 'loan_payment' && t.memberId) {
        fetchLiveBalance(t.memberId, value).then((bal) => {
          setLoanTxns((prev2) => prev2.map((t2, i2) => i2 === idx ? { ...t2, liveBalance: bal } : t2))
        })
      }
      return updated
    }))
  }
  const fetchLiveBalance = async (memberId: string, loanType: string) => {
    try {
      const res = await fetch(`/api/loan-payments?memberId=${memberId}&loanType=${loanType}`, { cache: 'no-store' })
      const data = await res.json()
      if (data.ok && data.payments.length > 0) {
        const lastPayment = data.payments[0]
        return formatINR(lastPayment.remainingBalance)
      }
      // If no payments, fetch the loan itself
      const loanRes = await fetch(`/api/loans/${loanType}`, { cache: 'no-store' })
      const loanData = await loanRes.json()
      if (loanData.ok) {
        const memberLoans = loanData.loans.filter((l: { memberId: string }) => l.memberId === memberId)
        if (loanType === 'bank') {
          const total = memberLoans.reduce((s: number, l: { bankLoanShare: number; emiPaid: number }) => s + l.bankLoanShare - l.emiPaid, 0)
          return total > 0 ? formatINR(total) : '₹0'
        } else {
          const total = memberLoans.reduce((s: number, l: { loanAmount: number; repaymentAmount: number }) => s + l.loanAmount - l.repaymentAmount, 0)
          return total > 0 ? formatINR(total) : '₹0'
        }
      }
      return '₹0'
    } catch {
      return '—'
    }
  }

  const togglePresent = (id: string) => {
    setPresentMemberIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!meetingDate) { toast({ title: 'तिथि आवश्यक है', variant: 'destructive' }); return }
    setSubmitting(true)
    const presentNames = members.filter((m) => presentMemberIds.has(m.id)).map((m) => m.name).join(', ')
    const absentNames = members.filter((m) => !presentMemberIds.has(m.id)).map((m) => m.name).join(', ')
    const decisionLines = decisionsText.split('\n').filter((l) => l.trim())
    const decisionsJson = JSON.stringify(decisionLines.map((desc) => ({ desc: desc.trim() })))
    try {
      const payload = {
        meetingDate, location, meetingTime, chairperson, secretary, treasurer, bkName,
        presentCount: presentMemberIds.size, absentCount: members.length - presentMemberIds.size,
        presentMembers: presentNames, absentMembers: absentNames,
        topic, decisions: decisionsJson,
        totalSavings, totalPending, totalAdvance, totalLoanGiven, totalLoanCollected,
        totalExpenses, groupFundBalance,
        nextMeetingDate, nextMeetingHost, nextMeetingLocation, notes,
        loanTransactions: editMeeting ? [] : loanTxns.filter((t) => t.memberId && t.amount).map((t) => ({
          type: t.type, memberId: t.memberId, amount: t.amount,
          interest: t.interest, interestRate: t.interestRate,
          loanType: t.loanType, bankName: t.bankName,
        })),
      }
      const url = editMeeting ? `/api/meetings/${editMeeting.id}` : '/api/meetings'
      const method = editMeeting ? 'PUT' : 'POST'
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
      const data = await res.json()
      if (!res.ok || !data.ok) { toast({ title: 'सहेजने में विफल', variant: 'destructive' }); return }
      onSaved()
      toast({ title: editMeeting ? 'प्रस्ताव अपडेट हुआ' : 'नया प्रस्ताव दर्ज हुआ' })
    } catch { toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' }) } finally { setSubmitting(false) }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="premium-dialog p-0 overflow-hidden border-0 sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <div className="premium-dialog-header bg-gradient-to-br from-orange-500 via-amber-500 to-yellow-500 px-5 py-4">
          <div className="relative flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shrink-0 shadow-lg">
              <CalendarCheck className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <DialogTitle className="text-base font-bold text-white">{groupName}</DialogTitle>
              <DialogDescription className="text-xs text-white/80 mt-0.5">
                {editMeeting ? 'प्रस्ताव संपादित करें' : 'नया प्रस्ताव दर्ज करें'} — बैठक का पूरा विवरण
              </DialogDescription>
            </div>
          </div>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* Meeting details */}
          <div className="premium-section-label"><CalendarCheck className="w-3 h-3" />बैठक विवरण</div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1"><Label className="text-xs font-medium">तिथि *</Label><Input type="date" max={todayStr} value={meetingDate} onChange={(e) => setMeetingDate(e.target.value)} required className="premium-input h-9" /></div>
            <div className="space-y-1"><Label className="text-xs font-medium">समय</Label><Input value={meetingTime} onChange={(e) => setMeetingTime(e.target.value)} className="premium-input h-9" /></div>
          </div>
          <div className="space-y-1"><Label className="text-xs font-medium">स्थान (किसके घर)</Label><Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="सुनीता देवी के घर, हरमू" className="premium-input h-9" /></div>

          {/* Officials */}
          <div className="premium-section-label"><ShieldCheck className="w-3 h-3" />पदाधिकारी</div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1"><Label className="text-xs font-medium">अध्यक्ष</Label><Input value={chairperson} onChange={(e) => setChairperson(e.target.value)} className="premium-input h-9" /></div>
            <div className="space-y-1"><Label className="text-xs font-medium">सचिव</Label><Input value={secretary} onChange={(e) => setSecretary(e.target.value)} className="premium-input h-9" /></div>
            <div className="space-y-1"><Label className="text-xs font-medium">कोषाध्यक्ष</Label><Input value={treasurer} onChange={(e) => setTreasurer(e.target.value)} className="premium-input h-9" /></div>
            <div className="space-y-1"><Label className="text-xs font-medium">बी.के.</Label><Input value={bkName} onChange={(e) => setBkName(e.target.value)} className="premium-input h-9" /></div>
          </div>

          {/* Attendance */}
          <div className="premium-section-label"><Users className="w-3 h-3" />उपस्थिति ({presentMemberIds.size}/{members.length})</div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-40 overflow-y-auto scroll-area p-1 rounded-lg border border-border/50">
            {members.map((m) => (
              <label key={m.id} className="flex items-center gap-2 text-xs cursor-pointer p-1 rounded hover:bg-muted/50">
                <Checkbox checked={presentMemberIds.has(m.id)} onCheckedChange={() => togglePresent(m.id)} />
                <span className="truncate">{m.name}</span>
              </label>
            ))}
          </div>

          {/* Topic + Decisions */}
          <div className="space-y-1"><Label className="text-xs font-medium">विषय</Label><Input value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="मासिक बचत एवं ऋण वितरण" className="premium-input h-9" /></div>
          <div className="premium-section-label"><FileText className="w-3 h-3" />निर्णय (एक प्रति पंक्ति)</div>
          <Textarea value={decisionsText} onChange={(e) => setDecisionsText(e.target.value)} placeholder={'सभी सदस्यों से ₹10 जमा की गई\ncसरला को ₹6000 लोन स्वीकृत'} rows={3} className="premium-input resize-none" />

          {/* Financials */}
          <div className="premium-section-label"><IndianRupee className="w-3 h-3" />वित्तीय सारांश</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="space-y-1"><Label className="text-xs">जमा ₹</Label><Input type="number" min={0} value={totalSavings} onChange={(e) => setTotalSavings(e.target.value)} className="premium-input h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">बकाया ₹</Label><Input type="number" min={0} value={totalPending} onChange={(e) => setTotalPending(e.target.value)} className="premium-input h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">एडवांस ₹</Label><Input type="number" min={0} value={totalAdvance} onChange={(e) => setTotalAdvance(e.target.value)} className="premium-input h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">खर्च ₹</Label><Input type="number" min={0} value={totalExpenses} onChange={(e) => setTotalExpenses(e.target.value)} className="premium-input h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">लोन दिया ₹</Label><Input type="number" min={0} value={totalLoanGiven} onChange={(e) => setTotalLoanGiven(e.target.value)} className="premium-input h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">लोन वसूल ₹</Label><Input type="number" min={0} value={totalLoanCollected} onChange={(e) => setTotalLoanCollected(e.target.value)} className="premium-input h-9" /></div>
            <div className="space-y-1 col-span-2"><Label className="text-xs font-bold text-primary">समूह कोष ₹</Label><Input type="number" min={0} value={groupFundBalance} onChange={(e) => setGroupFundBalance(e.target.value)} className="premium-input h-9 font-bold text-primary" /></div>
          </div>

          {/* Loan Transactions — auto-create loan records */}
          {!editMeeting && (
            <div>
              <div className="premium-section-label"><HandCoins className="w-3 h-3" />लोन लेन-देन (इस बैठक में)</div>
              <p className="text-[10px] text-muted-foreground mb-2">बैठक में दिए गए लोन या वसूले गए भुगतान दर्ज करें — सदस्य की प्रोफ़ाइल में अपने आप जुड़ जाएंगे</p>
              <div className="flex gap-2 mb-2 flex-wrap">
                <Button type="button" size="sm" variant="outline" className="h-7 text-[10px] press-effect" onClick={() => addLoanTxn('bank_loan_given')}>
                  <Landmark className="w-3 h-3 mr-1" />बैंक लोन दिया
                </Button>
                <Button type="button" size="sm" variant="outline" className="h-7 text-[10px] press-effect" onClick={() => addLoanTxn('private_loan_given')}>
                  <HandCoins className="w-3 h-3 mr-1" />प्राइवेट लोन दिया
                </Button>
                <Button type="button" size="sm" variant="outline" className="h-7 text-[10px] press-effect" onClick={() => addLoanTxn('loan_payment')}>
                  <IndianRupee className="w-3 h-3 mr-1" />लोन भुगतान वसूल
                </Button>
              </div>
              {/* Transaction list */}
              {loanTxns.length > 0 && (
                <div className="space-y-2">
                  {loanTxns.map((tx, idx) => (
                    <div key={idx} className="rounded-lg border border-border/50 bg-muted/20 p-2.5 space-y-2">
                      <div className="flex items-center justify-between">
                        <Badge className={`text-[9px] ${tx.type === 'bank_loan_given' ? 'bg-blue-100 text-blue-700' : tx.type === 'private_loan_given' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'}`}>
                          {tx.type === 'bank_loan_given' ? '🏦 बैंक लोन दिया' : tx.type === 'private_loan_given' ? '💰 प्राइवेट लोन दिया' : '✅ भुगतान वसूल'}
                        </Badge>
                        <Button type="button" variant="ghost" size="icon" className="h-6 w-6 text-destructive" onClick={() => removeLoanTxn(idx)}>
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                      {/* Live balance for payment type */}
                      {tx.type === 'loan_payment' && tx.memberId && tx.liveBalance && (
                        <div className="text-[10px] bg-red-50 border border-red-100 rounded px-2 py-1 text-red-700">
                          📊 वर्तमान बकाया: <span className="font-bold">{tx.liveBalance}</span>
                        </div>
                      )}
                      <div className="grid grid-cols-2 gap-2">
                        <Select value={tx.memberId} onValueChange={(v) => updateLoanTxn(idx, 'memberId', v)}>
                          <SelectTrigger className="premium-input h-8 text-xs"><SelectValue placeholder="सदस्य चुनें" /></SelectTrigger>
                          <SelectContent>
                            {members.map((m) => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
                          </SelectContent>
                        </Select>
                        <Input type="number" min={0} placeholder="राशि ₹" value={tx.amount} onChange={(e) => updateLoanTxn(idx, 'amount', e.target.value)} className="premium-input h-8 text-xs" />
                      </div>
                      {/* Interest rate for loan given */}
                      {(tx.type === 'bank_loan_given' || tx.type === 'private_loan_given') && (
                        <Input type="number" min={0} step="0.1" placeholder="ब्याज दर % (जैसे 1.5)" value={tx.interestRate} onChange={(e) => updateLoanTxn(idx, 'interestRate', e.target.value)} className="premium-input h-8 text-xs" />
                      )}
                      {tx.type === 'loan_payment' && (
                        <div className="grid grid-cols-2 gap-2">
                          <Select value={tx.loanType} onValueChange={(v) => updateLoanTxn(idx, 'loanType', v)}>
                            <SelectTrigger className="premium-input h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="bank">बैंक लोन</SelectItem>
                              <SelectItem value="private">प्राइवेट लोन</SelectItem>
                            </SelectContent>
                          </Select>
                          <Input type="number" min={0} placeholder="ब्याज ₹" value={tx.interest} onChange={(e) => updateLoanTxn(idx, 'interest', e.target.value)} className="premium-input h-8 text-xs" />
                        </div>
                      )}
                      {tx.type === 'bank_loan_given' && (
                        <Input placeholder="बैंक का नाम" value={tx.bankName} onChange={(e) => updateLoanTxn(idx, 'bankName', e.target.value)} className="premium-input h-8 text-xs" />
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Next meeting */}
          <div className="premium-section-label"><ArrowRight className="w-3 h-3" />अगली बैठक</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1"><Label className="text-xs">अगली तिथि</Label><Input type="date" value={nextMeetingDate} onChange={(e) => setNextMeetingDate(e.target.value)} className="premium-input h-9" /></div>
            <div className="space-y-1"><Label className="text-xs">मेज़बान (किसके घर)</Label><Input value={nextMeetingHost} onChange={(e) => setNextMeetingHost(e.target.value)} placeholder="गीता कुमारी" className="premium-input h-9" /></div>
          </div>
          <div className="space-y-1"><Label className="text-xs">अगली बैठक स्थान</Label><Input value={nextMeetingLocation} onChange={(e) => setNextMeetingLocation(e.target.value)} placeholder="गीता कुमारी के घर, बरियातू" className="premium-input h-9" /></div>
          <div className="space-y-1"><Label className="text-xs">टिप्पणी</Label><Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="बैठक सफल रही..." className="premium-input h-9" /></div>

          <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={submitting} className="press-effect h-9"><X className="w-3.5 h-3.5" />रद्द</Button>
            <Button type="submit" disabled={submitting} className="premium-button text-white font-semibold h-9">
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {submitting ? '...' : editMeeting ? 'अपडेट' : 'दर्ज करें'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

/* ===================== Helpers ===================== */
function OfficialBox({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-lg bg-muted/30 border border-border/30 p-2">
      <div className="text-[9px] text-muted-foreground flex items-center gap-1">{icon}{label}</div>
      <div className="text-xs font-medium truncate">{value}</div>
    </div>
  )
}
function DetailItem({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-1.5 text-muted-foreground">
      {icon}<span className="text-[10px]">{label}:</span>
      <span className="font-medium text-foreground text-[11px] truncate">{value}</span>
    </div>
  )
}
function FinBox({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="rounded-lg bg-muted/30 border border-border/30 p-1.5 text-center">
      <div className="text-[9px] text-muted-foreground">{label}</div>
      <div className={`text-xs font-bold ${color}`}>{value}</div>
    </div>
  )
}
