'use client'

import { useEffect, useState } from 'react'
import { useAppStore, type Section } from '@/lib/store'
import { cn } from '@/lib/utils'
import { LayoutDashboard, Users, HandCoins, Receipt, CalendarCheck, BarChart3, Settings } from 'lucide-react'
import { formatTimeIST } from '@/lib/format'
import { BrandBlock, LogoutPill } from '@/components/shg/logo'

interface NavItem {
  id: Section
  label: string
  icon: React.ComponentType<{ className?: string }>
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Home', icon: LayoutDashboard },
  { id: 'members', label: 'Members', icon: Users },
  { id: 'loans', label: 'Loans', icon: HandCoins },
  { id: 'expenses', label: 'खर्च', icon: Receipt },
  { id: 'weekly', label: 'जमा', icon: CalendarCheck },
  { id: 'reports', label: 'Reports', icon: BarChart3 },
  { id: 'admin', label: 'Settings', icon: Settings },
]

/**
 * Mobile bottom navigation — fixed at bottom on small screens only.
 * Looks like a native mobile app tab bar with raised active pill.
 */
export function MobileBottomNav() {
  const activeSection = useAppStore((s) => s.activeSection)
  const setActiveSection = useAppStore((s) => s.setActiveSection)
  const admin = useAppStore((s) => s.admin)

  return (
    <nav
      className="lg:hidden fixed bottom-0 inset-x-0 z-50 bg-card/95 backdrop-blur-xl border-t border-border shadow-nav"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      aria-label="Primary"
    >
      <div className="grid grid-cols-7 max-w-md mx-auto">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon
          const isActive = activeSection === item.id
          const isDisabled = !admin && item.id === 'admin'
          return (
            <button
              key={item.id}
              onClick={() => !isDisabled && setActiveSection(item.id)}
              disabled={isDisabled}
              className={cn(
                'press-effect relative flex flex-col items-center justify-center gap-1 py-2 text-[10px] font-medium transition-colors min-h-[60px]',
                isActive
                  ? 'text-primary'
                  : 'text-muted-foreground',
                isDisabled && 'opacity-40 cursor-not-allowed'
              )}
              aria-current={isActive ? 'page' : undefined}
              aria-label={item.label}
            >
              {/* Raised active pill background with 3D shadow */}
              {isActive && (
                <span
                  className="absolute top-1 w-12 h-8 rounded-full bg-primary/10 shadow-fab"
                  aria-hidden
                />
              )}
              <Icon
                className={cn(
                  'relative w-5 h-5 transition-transform',
                  isActive && 'scale-110 -translate-y-0.5'
                )}
              />
              <span className="relative leading-tight">{item.label}</span>
              {/* Active indicator dot */}
              {isActive && (
                <span className="absolute bottom-1 w-1 h-1 rounded-full bg-primary" aria-hidden />
              )}
            </button>
          )
        })}
      </div>
    </nav>
  )
}

interface MobileTopBarProps {
  pageTitle: string
  groupName?: string | null
  groupCode?: string | null
  foundingDate?: string | null
}

/**
 * Mobile top bar — compact app-like header.
 * Shows the official logo + group name + group ID + founding date on the left,
 * and IST time + logout button on the right.
 */
export function MobileTopBar({ pageTitle, groupName, groupCode, foundingDate }: MobileTopBarProps) {
  const logout = useAppStore((s) => s.logout)
  // Live IST time for the mobile header
  const [istTime, setIstTime] = useState('')
  useEffect(() => {
    const update = () => setIstTime(formatTimeIST())
    update()
    const id = setInterval(update, 30000)
    return () => clearInterval(id)
  }, [])

  return (
    <header className="lg:hidden sticky top-0 z-40 bg-card/95 backdrop-blur-xl border-b border-border shadow-card">
      {/* Row 1: brand block + IST time + logout */}
      <div className="flex items-center justify-between px-3 h-14 max-w-md mx-auto gap-2">
        <BrandBlock
          groupName={groupName}
          groupCode={groupCode}
          foundingDate={foundingDate}
          compact
        />
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="font-mono text-[11px] font-semibold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200" title="Indian Standard Time">
            {istTime} <span className="text-[8px] font-normal opacity-70">IST</span>
          </span>
          <LogoutPill onLogout={logout} />
        </div>
      </div>
      {/* Row 2: page title strip */}
      <div className="px-3 pb-1.5 max-w-md mx-auto">
        <div className="text-[11px] text-muted-foreground font-medium truncate">{pageTitle}</div>
      </div>
    </header>
  )
}
