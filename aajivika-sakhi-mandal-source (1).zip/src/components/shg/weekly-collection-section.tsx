'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar } from '@/components/shg/avatar'
import { useToast } from '@/hooks/use-toast'
import { useAppStore } from '@/lib/store'
import { formatINR, formatDate, toISODate, formatTimeIST } from '@/lib/format'
import {
  CalendarCheck,
  CheckCircle2,
  Clock4,
  ArrowUpCircle,
  IndianRupee,
  Loader2,
  Save,
  ChevronLeft,
  ChevronRight,
  Users,
  TrendingUp,
} from 'lucide-react'

interface Member {
  id: string
  memberCode: string
  name: string
  photoUrl: string | null
  post: string
}
interface WeeklySaving {
  id: string
  memberId: string
  weekDate: string
  amount: number
  status: string
  advanceWeeks: number
  member: Member
}

// Get the Wednesday for a given date's week
function getWednesday(date: Date): Date {
  const d = new Date(date)
  const day = d.getDay() // 0=Sun, 3=Wed
  const diff = (3 - day + 7) % 7
  if (day > 3) d.setDate(d.getDate() - (day - 3))
  else d.setDate(d.getDate() + diff)
  d.setHours(0, 0, 0, 0)
  return d
}

export function WeeklyCollectionSection() {
  const admin = useAppStore((s) => s.admin)
  const { toast } = useToast()
  const [members, setMembers] = useState<Member[]>([])
  const [savings, setSavings] = useState<WeeklySaving[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [refreshKey, setRefreshKey] = useState(0)
  const [currentWeek, setCurrentWeek] = useState(getWednesday(new Date()))
  const [amounts, setAmounts] = useState<Record<string, { amount: string; status: string }>>({})

  useEffect(() => {
    let mounted = true
    const load = async () => {
      setLoading(true)
      try {
        const weekStr = toISODate(currentWeek)
        const [mRes, sRes] = await Promise.all([
          fetch('/api/members', { cache: 'no-store' }),
          fetch(`/api/weekly-savings?weekDate=${weekStr}`, { cache: 'no-store' }),
        ])
        const [m, s] = await Promise.all([mRes.json(), sRes.json()])
        if (mounted) {
          if (m.ok) setMembers(m.members.map((x: Member) => ({ id: x.id, memberCode: x.memberCode, name: x.name, photoUrl: x.photoUrl, post: x.post })))
          if (s.ok) setSavings(s.savings || [])
          // Initialize amounts from existing data
          const newAmounts: Record<string, { amount: string; status: string }> = {}
          for (const sv of (s.savings || [])) {
            newAmounts[sv.memberId] = {
              amount: String(sv.amount),
              status: sv.status,
            }
          }
          // Default unpaid members to pending with ₹0
          for (const mem of (m.members || [])) {
            if (!newAmounts[mem.id]) {
              newAmounts[mem.id] = { amount: '0', status: 'pending' }
            }
          }
          setAmounts(newAmounts)
        }
      } catch { /* swallow */ } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
  }, [currentWeek, refreshKey])

  const weekDateStr = toISODate(currentWeek)

  // Stats
  const paidCount = Object.values(amounts).filter((a) => a.status === 'paid').length
  const pendingCount = Object.values(amounts).filter((a) => a.status === 'pending').length
  const advanceCount = Object.values(amounts).filter((a) => a.status === 'advance').length
  const totalCollected = Object.values(amounts).reduce((s, a) => s + (Number(a.amount) || 0), 0)

  const setStatus = (memberId: string, status: string) => {
    const perMember = 10
    setAmounts((prev) => {
      const current = prev[memberId] || { amount: '0', status: 'pending' }
      let amount = current.amount
      if (status === 'paid') amount = String(perMember)
      else if (status === 'pending') amount = '0'
      else if (status === 'advance' && Number(amount) < perMember * 2) amount = String(perMember * 2)
      return { ...prev, [memberId]: { amount, status } }
    })
  }

  const setAmount = (memberId: string, amount: string) => {
    const perMember = 10
    const amt = Number(amount) || 0
    let status = 'pending'
    if (amt >= perMember * 2) status = 'advance'
    else if (amt >= perMember) status = 'paid'
    else if (amt > 0) status = 'paid'
    else status = 'pending'
    setAmounts((prev) => ({ ...prev, [memberId]: { amount, status } }))
  }

  const handleSave = async () => {
    setSaving(true)
    let saved = 0
    for (const mem of members) {
      const data = amounts[mem.id]
      if (!data) continue
      try {
        await fetch('/api/weekly-savings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            memberId: mem.id,
            weekDate: weekDateStr,
            amount: Number(data.amount) || 0,
            status: data.status,
            advanceWeeks: data.status === 'advance' ? Math.floor((Number(data.amount) || 0) / 10) - 1 : 0,
          }),
        })
        saved++
      } catch { /* swallow */ }
    }
    setSaving(false)
    setRefreshKey((k) => k + 1)
    toast({ title: `${saved} सदस्यों की जमा दर्ज हुई`, description: `कुल ${formatINR(totalCollected)} जमा` })
  }

  const goPrevWeek = () => {
    const d = new Date(currentWeek)
    d.setDate(d.getDate() - 7)
    setCurrentWeek(d)
  }
  const goNextWeek = () => {
    const d = new Date(currentWeek)
    d.setDate(d.getDate() + 7)
    setCurrentWeek(d)
  }

  return (
    <div className="space-y-4">
      {/* Title */}
      <div className="flex items-baseline gap-2 flex-wrap">
        <h2 className="text-lg font-semibold">साप्ताहिक जमा प्रबंधन</h2>
        <span className="text-sm text-muted-foreground">
          हर बुधवार — ₹10/सदस्य
        </span>
      </div>

      {/* Week navigator */}
      <Card className="shadow-card-3d bg-gradient-to-br from-primary/5 to-transparent border-primary/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-3">
              <Button variant="outline" size="icon" className="h-9 w-9 press-effect" onClick={goPrevWeek}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <div className="text-center">
                <div className="text-[10px] text-muted-foreground uppercase tracking-wide">बैठक तिथि</div>
                <div className="text-base font-bold text-primary">{formatDate(weekDateStr)}</div>
              </div>
              <Button variant="outline" size="icon" className="h-9 w-9 press-effect" onClick={goNextWeek}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
            {/* Quick stats */}
            <div className="flex items-center gap-2 flex-wrap">
              <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">
                <CheckCircle2 className="w-3 h-3 mr-1" />{paidCount} जमा
              </Badge>
              <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-xs">
                <Clock4 className="w-3 h-3 mr-1" />{pendingCount} बकाया
              </Badge>
              <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 text-xs">
                <ArrowUpCircle className="w-3 h-3 mr-1" />{advanceCount} एडवांस
              </Badge>
              <Badge className="bg-primary text-primary-foreground text-xs">
                <IndianRupee className="w-3 h-3 mr-0.5" />{formatINR(totalCollected)}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Member list — mark paid/pending/advance */}
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 bg-muted/60 animate-pulse rounded-lg" />
          ))}
        </div>
      ) : (
        <>
          <div className="space-y-2">
            {members.map((m) => {
              const data = amounts[m.id] || { amount: '0', status: 'pending' }
              return (
                <Card key={m.id} className="premium-card overflow-hidden">
                  <CardContent className="p-3 flex items-center gap-3">
                    <Avatar src={m.photoUrl} name={m.name} size={36} />
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">{m.name}</div>
                      <div className="text-[10px] text-muted-foreground font-mono">{m.memberCode}</div>
                    </div>
                    {/* Amount input */}
                    <div className="w-20 shrink-0">
                      <Input
                        type="number"
                        min={0}
                        step={10}
                        value={data.amount}
                        onChange={(e) => setAmount(m.id, e.target.value)}
                        className="premium-input h-8 text-xs text-center"
                        placeholder="0"
                      />
                    </div>
                    {/* Status buttons */}
                    <div className="flex gap-1 shrink-0">
                      <Button
                        size="sm"
                        variant={data.status === 'paid' ? 'default' : 'outline'}
                        className={`h-7 text-[10px] px-2 press-effect ${data.status === 'paid' ? 'bg-green-600 text-white' : ''}`}
                        onClick={() => setStatus(m.id, 'paid')}
                      >
                        जमा
                      </Button>
                      <Button
                        size="sm"
                        variant={data.status === 'pending' ? 'default' : 'outline'}
                        className={`h-7 text-[10px] px-2 press-effect ${data.status === 'pending' ? 'bg-amber-500 text-white' : ''}`}
                        onClick={() => setStatus(m.id, 'pending')}
                      >
                        बकाया
                      </Button>
                      <Button
                        size="sm"
                        variant={data.status === 'advance' ? 'default' : 'outline'}
                        className={`h-7 text-[10px] px-2 press-effect ${data.status === 'advance' ? 'bg-blue-600 text-white' : ''}`}
                        onClick={() => setStatus(m.id, 'advance')}
                      >
                        एडवांस
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Save button */}
          {admin && (
            <div className="sticky bottom-20 lg:bottom-4 z-30">
              <Button
                className="w-full premium-button text-white font-bold h-12 press-effect shadow-lg"
                onClick={handleSave}
                disabled={saving}
              >
                {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                {saving ? 'सहेज रहे हैं...' : `सभी जमा दर्ज करें (${formatINR(totalCollected)})`}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  )
}
