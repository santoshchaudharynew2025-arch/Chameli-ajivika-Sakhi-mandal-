'use client'

import { useEffect, useMemo, useState, useRef } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useToast } from '@/hooks/use-toast'
import { useAppStore } from '@/lib/store'
import { formatDate, toISODate } from '@/lib/format'
import { CategoryPicker } from '@/components/shg/expenses-section'
import { PhotoUpload, Avatar } from '@/components/shg/avatar'
import { MemberLoanReport } from '@/components/shg/member-loan-report'
import {
  Search,
  CheckCircle2,
  Clock4,
  Users,
  Landmark,
  Phone,
  MapPin,
  Plus,
  Pencil,
  Trash2,
  ShieldCheck,
  Banknote,
  Eye,
  IdCard,
  User,
  Calendar,
  Home,
  Award,
  PenLine,
  Receipt,
  FileText,
  LayoutGrid,
  HandCoins,
} from 'lucide-react'

// Posts with bilingual labels
const POSTS = [
  { value: 'अध्यक्ष', label: 'अध्यक्ष (President)' },
  { value: 'सचिव', label: 'सचिव (Secretary)' },
  { value: 'कोषाध्यक्ष', label: 'कोषाध्यक्ष (Treasurer)' },
  { value: 'बी.के.', label: 'बी.के. (Book Keeper)' },
  { value: 'सदस्य', label: 'सदस्य (Member)' },
]

// Post badge colors
const POST_COLORS: Record<string, string> = {
  'अध्यक्ष': 'bg-purple-100 text-purple-700 hover:bg-purple-100',
  'सचिव': 'bg-green-100 text-green-700 hover:bg-green-100',
  'कोषाध्यक्ष': 'bg-amber-100 text-amber-700 hover:bg-amber-100',
  'बी.के.': 'bg-pink-100 text-pink-700 hover:bg-pink-100',
  'सदस्य': 'bg-gray-100 text-gray-700 hover:bg-gray-100',
}

interface Member {
  id: string
  serialNo: number
  memberCode: string
  name: string
  guardianName: string | null
  post: string
  age: number | null
  education: string | null
  occupation: string | null
  village: string | null
  district: string | null
  joiningDate: string
  kycStatus: string
  bankName: string | null
  accountNo: string | null
  ifscCode: string | null
  phone: string | null
  address: string | null
  photoUrl: string | null
  signMark: string
  privateLoans: unknown[]
  bankLoans: unknown[]
}

export function MembersSection() {
  const [members, setMembers] = useState<Member[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState<'all' | 'verified' | 'pending' | 'office'>('all')
  const [tab, setTab] = useState<'table' | 'cards' | 'bank'>('table')
  const admin = useAppStore((s) => s.admin)
  const { toast } = useToast()
  const [refreshKey, setRefreshKey] = useState(0)
  const [addOpen, setAddOpen] = useState(false)
  const [detailMember, setDetailMember] = useState<Member | null>(null)

  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const res = await fetch('/api/members', { cache: 'no-store' })
        const data = await res.json()
        if (mounted && data.ok) setMembers(data.members)
      } catch {
        /* swallow */
      } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
  }, [refreshKey])

  const filtered = useMemo(() => {
    return members.filter((m) => {
      const q = search.toLowerCase().trim()
      const matchesSearch =
        !q ||
        m.name.toLowerCase().includes(q) ||
        m.memberCode.toLowerCase().includes(q) ||
        (m.guardianName || '').toLowerCase().includes(q) ||
        (m.village || '').toLowerCase().includes(q) ||
        (m.district || '').toLowerCase().includes(q) ||
        (m.education || '').toLowerCase().includes(q) ||
        (m.occupation || '').toLowerCase().includes(q) ||
        (m.phone || '').includes(q)
      const isOfficeBearer = !['सदस्य'].includes(m.post)
      const matchesFilter =
        filter === 'all' ||
        (filter === 'verified' && m.kycStatus === 'Verified') ||
        (filter === 'pending' && m.kycStatus !== 'Verified') ||
        (filter === 'office' && isOfficeBearer)
      return matchesSearch && matchesFilter
    })
  }, [members, search, filter])

  const verifiedCount = members.filter((m) => m.kycStatus === 'Verified').length
  const pendingCount = members.length - verifiedCount
  const officeBearerCount = members.filter((m) => !['सदस्य'].includes(m.post)).length

  return (
    <div className="space-y-4">
      {/* Title row + Add Member button */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-baseline gap-2 flex-wrap">
          <h2 className="text-lg font-semibold">सदस्यों की प्रोफाइल एवं हस्ताक्षर</h2>
          <span className="text-sm text-muted-foreground">
            ({members.length} सदस्य)
          </span>
        </div>
        {admin && (
          <MemberFormDialog
            open={addOpen}
            setOpen={setAddOpen}
            editMember={null}
            existingCodes={members.map((m) => m.memberCode)}
            onSaved={() => {
              setAddOpen(false)
              setRefreshKey((k) => k + 1)
              toast({ title: 'सदस्य सफलतापूर्वक जोड़ा गया' })
            }}
          >
            <Button size="sm" className="h-9">
              <Plus className="w-4 h-4" />
              सदस्य जोड़ें
            </Button>
          </MemberFormDialog>
        )}
      </div>

      {/* Search + filter row */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="नाम, आईडी, पति का नाम, ग्राम से खोजें..."
            className="pl-9 h-9"
          />
        </div>
        <Select
          value={filter}
          onValueChange={(v) => setFilter(v as 'all' | 'verified' | 'pending' | 'office')}
        >
          <SelectTrigger className="w-[160px] h-9">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">सभी सदस्य</SelectItem>
            <SelectItem value="verified">सत्यापित (Verified)</SelectItem>
            <SelectItem value="pending">लंबित (Pending)</SelectItem>
            <SelectItem value="office">पदाधिकारी (Office Bearers)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* KYC summary chips */}
      <div className="flex items-center gap-2 flex-wrap">
        <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">
          <CheckCircle2 className="w-3 h-3 mr-1" />
          {verifiedCount} सत्यापित
        </Badge>
        {pendingCount > 0 && (
          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 text-xs">
            <Clock4 className="w-3 h-3 mr-1" />
            {pendingCount} लंबित
          </Badge>
        )}
        <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-100 text-xs">
          <Award className="w-3 h-3 mr-1" />
          {officeBearerCount} पदाधिकारी
        </Badge>
      </div>

      {/* Tab toggle: Excel table / Card view / Bank details */}
      <Tabs value={tab} onValueChange={(v) => setTab(v as 'table' | 'cards' | 'bank')}>
        <TabsList className="h-9">
          <TabsTrigger value="table" className="text-xs">
            <Users className="w-3.5 h-3.5 mr-1.5" />
            रजिस्टर
          </TabsTrigger>
          <TabsTrigger value="cards" className="text-xs">
            <LayoutGrid className="w-3.5 h-3.5 mr-1.5" />
            कार्ड व्यू
          </TabsTrigger>
          <TabsTrigger value="bank" className="text-xs">
            <Landmark className="w-3.5 h-3.5 mr-1.5" />
            बैंक विवरण
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Content */}
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 bg-muted/60 animate-pulse rounded-lg" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            <Users className="w-10 h-10 mx-auto mb-3 opacity-30" />
            कोई सदस्य नहीं मिला।
          </CardContent>
        </Card>
      ) : tab === 'table' ? (
        <MemberTable
          members={filtered}
          admin={!!admin}
          onRefresh={() => setRefreshKey((k) => k + 1)}
          onView={setDetailMember}
          totalCount={members.length}
        />
      ) : tab === 'cards' ? (
        <MemberCardGrid
          members={filtered}
          admin={!!admin}
          onRefresh={() => setRefreshKey((k) => k + 1)}
          onView={setDetailMember}
        />
      ) : (
        <div className="space-y-2">
          {filtered.map((m) => (
            <BankCard key={m.id} member={m} admin={!!admin} onRefresh={() => setRefreshKey((k) => k + 1)} onView={() => setDetailMember(m)} />
          ))}
        </div>
      )}

      {/* Member detail dialog */}
      <MemberDetailDialog
        member={detailMember}
        open={!!detailMember}
        onOpenChange={(o) => !o && setDetailMember(null)}
      />
    </div>
  )
}

/* ------------------------------- Excel-Style Table ------------------------------- */
function MemberTable({
  members,
  admin,
  onRefresh,
  onView,
  totalCount,
}: {
  members: Member[]
  admin: boolean
  onRefresh: () => void
  onView: (m: Member) => void
  totalCount: number
}) {
  const { toast } = useToast()
  // Calculate totals
  const membersWithAge = members.filter((m) => m.age)
  const totalAge = membersWithAge.reduce((s, m) => s + (m.age || 0), 0)
  const avgAge = membersWithAge.length > 0 ? Math.round(totalAge / membersWithAge.length) : 0
  const verifiedCount = members.filter((m) => m.kycStatus === 'Verified').length

  return (
    <Card className="shadow-card-3d overflow-hidden">
      {/* Header banner — Excel-style blue */}
      <div className="bg-gradient-to-r from-blue-700 to-blue-600 text-white px-4 py-2.5">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="font-semibold text-sm flex items-center gap-2">
            <Users className="w-4 h-4" />
            सदस्यों की प्रोफाइल एवं हस्ताक्षर
          </div>
          <div className="text-xs text-blue-100">
            Members Profile &amp; Signatures
          </div>
        </div>
      </div>

      <ScrollArea className="w-full scroll-area">
        <Table className="text-xs">
          <TableHeader>
            <TableRow className="bg-blue-50 hover:bg-blue-50 border-b-2 border-blue-200">
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap">सं.<br/><span className="text-[9px] font-normal text-blue-600">No.</span></TableHead>
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap">सदस्य आईडी<br/><span className="text-[9px] font-normal text-blue-600">Member ID</span></TableHead>
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap">सदस्य का नाम<br/><span className="text-[9px] font-normal text-blue-600">Member Name</span></TableHead>
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap">पति का नाम<br/><span className="text-[9px] font-normal text-blue-600">Husband's Name</span></TableHead>
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap">पद<br/><span className="text-[9px] font-normal text-blue-600">Post</span></TableHead>
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap">आयु<br/><span className="text-[9px] font-normal text-blue-600">Age</span></TableHead>
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap">शिक्षा<br/><span className="text-[9px] font-normal text-blue-600">Education</span></TableHead>
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap">व्यवसाय<br/><span className="text-[9px] font-normal text-blue-600">Occupation</span></TableHead>
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap">ग्राम<br/><span className="text-[9px] font-normal text-blue-600">Village</span></TableHead>
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap">जनपद<br/><span className="text-[9px] font-normal text-blue-600">District</span></TableHead>
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap text-center">चिह्न<br/><span className="text-[9px] font-normal text-blue-600">Sign</span></TableHead>
              <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 whitespace-nowrap text-center">हस्ताक्षर / अंगूठा<br/><span className="text-[9px] font-normal text-blue-600">Signature / Thumb</span></TableHead>
              {admin && <TableHead className="font-semibold text-blue-900 text-[11px] h-9 px-2 text-right">क्रिया<br/><span className="text-[9px] font-normal text-blue-600">Actions</span></TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {members.map((m, idx) => {
              const isOfficeBearer = !['सदस्य'].includes(m.post)
              return (
                <TableRow
                  key={m.id}
                  className={`cursor-pointer hover:bg-blue-50/50 transition-colors ${idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/30'}`}
                  onClick={() => onView(m)}
                >
                  <TableCell className="px-2 py-2 font-medium text-center">{m.serialNo}</TableCell>
                  <TableCell className="px-2 py-2 font-mono font-semibold text-blue-700">{m.memberCode}</TableCell>
                  <TableCell className="px-2 py-2 font-medium">
                    <div className="flex items-center gap-2">
                      <Avatar src={m.photoUrl} name={m.name} size={28} ring={false} />
                      <span>{m.name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="px-2 py-2 text-muted-foreground">{m.guardianName || '—'}</TableCell>
                  <TableCell className="px-2 py-2">
                    <Badge className={`text-[10px] ${POST_COLORS[m.post] || POST_COLORS['सदस्य']}`}>
                      {m.post}
                    </Badge>
                  </TableCell>
                  <TableCell className="px-2 py-2 text-center">{m.age || '—'}</TableCell>
                  <TableCell className="px-2 py-2">{m.education || '—'}</TableCell>
                  <TableCell className="px-2 py-2">{m.occupation || '—'}</TableCell>
                  <TableCell className="px-2 py-2">{m.village || '—'}</TableCell>
                  <TableCell className="px-2 py-2">{m.district || '—'}</TableCell>
                  <TableCell className="px-2 py-2 text-center">
                    {m.signMark === 'सही' ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-green-100 text-green-700">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </span>
                    ) : (
                      <span className="text-muted-foreground text-[10px]">—</span>
                    )}
                  </TableCell>
                  <TableCell className="px-2 py-2 text-center">
                    {m.kycStatus === 'Verified' ? (
                      <span className="inline-block px-2 py-0.5 rounded bg-green-50 text-green-700 text-[10px] font-medium border border-green-200">
                        ✓ सही
                      </span>
                    ) : (
                      <span className="inline-block px-2 py-0.5 rounded bg-amber-50 text-amber-700 text-[10px] font-medium border border-amber-200">
                        लंबित
                      </span>
                    )}
                  </TableCell>
                  {admin && (
                    <TableCell className="px-2 py-2 text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="flex justify-end gap-0.5">
                        <Button variant="ghost" size="icon" className="h-7 w-7" aria-label="View" onClick={() => onView(m)}>
                          <Eye className="w-3.5 h-3.5" />
                        </Button>
                        <LoanReportButton member={m} />
                        <EditMemberButton
                          member={m}
                          existingCodes={[]}
                          onSaved={() => {
                            onRefresh()
                            toast({ title: 'सदस्य अपडेट हुआ' })
                          }}
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          aria-label="Delete"
                          onClick={async () => {
                            if (!confirm(`सदस्य "${m.name}" को हटाना चाहते हैं? सभी ऋण रिकॉर्ड भी हट जाएंगे।`)) return
                            const r = await fetch(`/api/members/${m.id}`, { method: 'DELETE' })
                            if (r.ok) {
                              onRefresh()
                              toast({ title: 'सदस्य हटाया गया' })
                            } else {
                              toast({ title: 'हटाने में विफल', variant: 'destructive' })
                            }
                          }}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              )
            })}
            {/* Total row — Excel-style */}
            <TableRow className="bg-blue-100/50 border-t-2 border-blue-300 font-semibold">
              <TableCell colSpan={5} className="px-2 py-2 text-right text-blue-900 text-[11px]">
                कुल सदस्य (Total Members):
              </TableCell>
              <TableCell className="px-2 py-2 text-center text-blue-900">{totalCount}</TableCell>
              <TableCell colSpan={4} className="px-2 py-2 text-right text-blue-900 text-[11px]">
                औसत आयु: <span className="font-bold">{avgAge}</span> वर्ष
              </TableCell>
              <TableCell className="px-2 py-2 text-center text-green-700">
                <CheckCircle2 className="w-3.5 h-3.5 inline" />
              </TableCell>
              <TableCell className="px-2 py-2 text-center text-green-700 text-[11px]">
                {verifiedCount}/{totalCount} सही
              </TableCell>
              {admin && <TableCell className="px-2 py-2" />}
            </TableRow>
          </TableBody>
        </Table>
      </ScrollArea>
    </Card>
  )
}

/* ------------------------------- Bank Card ------------------------------- */
function BankCard({
  member,
  admin,
  onRefresh,
  onView,
}: {
  member: Member
  admin: boolean
  onRefresh: () => void
  onView: () => void
}) {
  return (
    <Card className="shadow-card lift-on-hover hover:shadow-card-hover cursor-pointer" onClick={onView}>
      <CardContent className="p-4 flex items-center gap-4">
        <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-100 to-blue-50 flex items-center justify-center shrink-0 shadow-fab">
          <Landmark className="w-5 h-5 text-blue-600" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="font-medium text-sm">{member.name}</div>
            <Badge className={`text-[10px] ${POST_COLORS[member.post] || POST_COLORS['सदस्य']}`}>
              {member.post}
            </Badge>
          </div>
          <div className="text-xs text-muted-foreground mt-1 flex items-center gap-3 flex-wrap">
            <span className="font-mono">{member.memberCode}</span>
            {member.education && <span>शिक्षा: {member.education}</span>}
            {member.occupation && <span>व्यवसाय: {member.occupation}</span>}
            <span>{member.bankName || '—'}</span>
            <span className="font-mono">{member.accountNo ? maskAccount(member.accountNo) : '—'}</span>
            <span className="font-mono">{member.ifscCode || '—'}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function maskAccount(acct: string): string {
  if (!acct || acct.length <= 6) return acct
  return `${acct.slice(0, 3)}••••${acct.slice(-4)}`
}

/* ===================== Member Card Grid (premium 3D cards) ===================== */
function MemberCardGrid({
  members,
  admin,
  onRefresh,
  onView,
}: {
  members: Member[]
  admin: boolean
  onRefresh: () => void
  onView: (m: Member) => void
}) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {members.map((m) => (
        <MemberCard3D
          key={m.id}
          member={m}
          admin={admin}
          onRefresh={onRefresh}
          onView={onView}
        />
      ))}
    </div>
  )
}

function MemberCard3D({
  member,
  admin,
  onRefresh,
  onView,
}: {
  member: Member
  admin: boolean
  onRefresh: () => void
  onView: (m: Member) => void
}) {
  const { toast } = useToast()
  const isVerified = member.kycStatus === 'Verified'
  const loanCount = member.privateLoans.length + member.bankLoans.length
  const cardRef = useRef<HTMLDivElement>(null)

  // 3D tilt on mouse move
  const handleMouseMove = (e: React.MouseEvent) => {
    const card = cardRef.current
    if (!card) return
    const rect = card.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    const centerX = rect.width / 2
    const centerY = rect.height / 2
    const rotateX = ((y - centerY) / centerY) * -4
    const rotateY = ((x - centerX) / centerX) * 4
    card.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-3px)`
  }
  const handleMouseLeave = () => {
    const card = cardRef.current
    if (card) card.style.transform = 'perspective(800px) rotateX(0) rotateY(0) translateY(0)'
  }

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative overflow-hidden rounded-2xl bg-white border border-border transition-transform duration-200 ease-out cursor-pointer"
      style={{ boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05), 0 10px 30px -5px rgba(0,0,0,0.08)' }}
      onClick={() => onView(member)}
    >
      {/* Gradient header strip with photo */}
      <div className="relative bg-gradient-to-br from-primary via-[oklch(0.4_0.14_150)] to-[oklch(0.35_0.12_160)] p-4">
        {/* Decorative blob */}
        <div className="absolute -right-6 -top-6 w-24 h-24 rounded-full bg-white/10 blur-2xl" aria-hidden />
        <div className="relative flex items-center gap-3">
          {/* Photo */}
          <div className="shrink-0">
            {member.photoUrl ? (
              <div className="w-14 h-14 rounded-2xl overflow-hidden ring-2 ring-white/50 shadow-lg">
                <img src={member.photoUrl} alt={member.name} className="w-full h-full object-cover" />
              </div>
            ) : (
              <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-md border-2 border-white/40 flex items-center justify-center shadow-lg">
                <Avatar name={member.name} size={28} ring={false} />
              </div>
            )}
          </div>
          {/* Name + post */}
          <div className="flex-1 min-w-0">
            <div className="font-bold text-white text-sm truncate">{member.name}</div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <Badge className={`text-[9px] border-0 ${POST_COLORS[member.post] || POST_COLORS['सदस्य']}`}>
                {member.post}
              </Badge>
              {isVerified ? (
                <Badge className="bg-green-500/30 text-green-50 border-0 text-[9px]">
                  <CheckCircle2 className="w-2.5 h-2.5 mr-0.5" />✓
                </Badge>
              ) : (
                <Badge className="bg-amber-500/30 text-amber-50 border-0 text-[9px]">
                  <Clock4 className="w-2.5 h-2.5 mr-0.5" />…
                </Badge>
              )}
            </div>
          </div>
        </div>
        {/* Member ID */}
        <div className="relative mt-2 text-[10px] text-white/70 font-mono">
          ID: {member.memberCode}
        </div>
      </div>

      {/* Body */}
      <div className="p-4 space-y-3">
        {/* Info grid */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <User className="w-3 h-3 shrink-0" />
            <span className="truncate">{member.guardianName || '—'}</span>
          </div>
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Calendar className="w-3 h-3 shrink-0" />
            <span>{member.age ? `${member.age} वर्ष` : '—'}</span>
          </div>
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Home className="w-3 h-3 shrink-0" />
            <span className="truncate">{member.village || '—'}</span>
          </div>
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <MapPin className="w-3 h-3 shrink-0" />
            <span className="truncate">{member.district || '—'}</span>
          </div>
        </div>

        {/* Education + Occupation badges */}
        <div className="flex flex-wrap gap-1">
          {member.education && (
            <Badge variant="outline" className="text-[9px] bg-purple-50 border-purple-100 text-purple-600">
              <Award className="w-2.5 h-2.5 mr-0.5" />{member.education}
            </Badge>
          )}
          {member.occupation && (
            <Badge variant="outline" className="text-[9px] bg-blue-50 border-blue-100 text-blue-600">
              <Banknote className="w-2.5 h-2.5 mr-0.5" />{member.occupation}
            </Badge>
          )}
          {loanCount > 0 && (
            <Badge variant="outline" className="text-[9px] bg-amber-50 border-amber-100 text-amber-600">
              <HandCoins className="w-2.5 h-2.5 mr-0.5" />{loanCount} लोन
            </Badge>
          )}
        </div>

        {/* Phone */}
        {member.phone && (
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Phone className="w-3 h-3 shrink-0" />
            <span className="font-mono">{member.phone}</span>
          </div>
        )}

        {/* Actions */}
        {admin && (
          <div className="flex items-center gap-1 pt-2 border-t border-border/50">
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-[10px] flex-1 press-effect"
              onClick={(e) => { e.stopPropagation(); onView(member) }}
            >
              <Eye className="w-3 h-3 mr-1" />प्रोफ़ाइल
            </Button>
            <LoanReportButton member={member} />
            <EditMemberButton
              member={member}
              existingCodes={[]}
              onSaved={() => { onRefresh(); toast({ title: 'सदस्य अपडेट हुआ' }) }}
            />
          </div>
        )}
      </div>
    </div>
  )
}

/* --------------------------- Member Detail Dialog --------------------------- */
function MemberDetailDialog({
  member,
  open,
  onOpenChange,
}: {
  member: Member | null
  open: boolean
  onOpenChange: (v: boolean) => void
}) {
  if (!member) return null
  const loanCount = member.privateLoans.length + member.bankLoans.length

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="premium-dialog p-0 overflow-hidden border-0 sm:max-w-[560px] max-h-[90vh] overflow-y-auto">
        {/* Premium gradient header with member photo */}
        <div className="premium-dialog-header bg-gradient-to-br from-primary via-[oklch(0.4_0.14_150)] to-[oklch(0.35_0.12_160)] px-5 py-5 sm:px-6 sm:py-6">
          <div className="relative flex items-center gap-4">
            {/* 3D photo frame */}
            <div className="shrink-0">
              {member.photoUrl ? (
                <div className="w-20 h-20 rounded-2xl overflow-hidden ring-4 ring-white/40 shadow-2xl" style={{ boxShadow: '0 8px 24px -4px rgba(0,0,0,0.3), 0 0 0 4px rgba(255,255,255,0.4)' }}>
                  <img src={member.photoUrl} alt={member.name} className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="w-20 h-20 rounded-2xl bg-white/20 backdrop-blur-md border-2 border-white/40 flex items-center justify-center shadow-2xl">
                  <User className="w-10 h-10 text-white" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <DialogTitle className="text-lg font-bold text-white leading-tight">
                  {member.name}
                </DialogTitle>
                <Badge className={`text-[10px] ${POST_COLORS[member.post] || POST_COLORS['सदस्य']} border-0`}>
                  {member.post}
                </Badge>
              </div>
              <DialogDescription className="text-xs text-white/80 mt-1 font-mono">
                सदस्य आईडी: {member.memberCode}
              </DialogDescription>
              <div className="text-[10px] text-white/60 mt-0.5">
                सदस्य का सम्पूर्ण विवरण एवं हस्ताक्षर
              </div>
            </div>
          </div>
        </div>

        <div className="p-5 sm:p-6 space-y-5">
        {/* Detail grid */}
        <div className="grid grid-cols-2 gap-3 text-sm">
          <DetailItem icon={<User className="w-3.5 h-3.5" />} label="पति का नाम" value={member.guardianName || '—'} />
          <DetailItem icon={<Calendar className="w-3.5 h-3.5" />} label="आयु" value={member.age ? `${member.age} वर्ष` : '—'} />
          <DetailItem icon={<Award className="w-3.5 h-3.5" />} label="शिक्षा" value={member.education || '—'} />
          <DetailItem icon={<Banknote className="w-3.5 h-3.5" />} label="व्यवसाय" value={member.occupation || '—'} />
          <DetailItem icon={<Home className="w-3.5 h-3.5" />} label="ग्राम" value={member.village || '—'} />
          <DetailItem icon={<MapPin className="w-3.5 h-3.5" />} label="जनपद" value={member.district || '—'} />
          <DetailItem icon={<Calendar className="w-3.5 h-3.5" />} label="शामिल होने की तिथि" value={formatDate(member.joiningDate)} />
          <DetailItem icon={<Banknote className="w-3.5 h-3.5" />} label="ऋण संख्या" value={`${loanCount} ऋण`} />
        </div>

        <Separator />

        {/* Bank details */}
        <div className="space-y-2">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            बैंक विवरण
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <DetailItem icon={<Landmark className="w-3.5 h-3.5" />} label="बैंक का नाम" value={member.bankName || '—'} />
            <DetailItem icon={<IdCard className="w-3.5 h-3.5" />} label="खाता संख्या" value={member.accountNo || '—'} mono />
            <DetailItem icon={<IdCard className="w-3.5 h-3.5" />} label="IFSC कोड" value={member.ifscCode || '—'} mono />
            <DetailItem icon={<Phone className="w-3.5 h-3.5" />} label="फ़ोन" value={member.phone || '—'} mono />
          </div>
        </div>

        <Separator />

        {/* Signature section — Secretary verification */}
        <div className="space-y-3">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            हस्ताक्षर / अंगूठा (Signature / Thumb)
          </div>
          <div className="flex items-center justify-between p-3 rounded-lg border-2 border-dashed border-green-300 bg-green-50/50">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                <PenLine className="w-5 h-5 text-green-700" />
              </div>
              <div>
                <div className="text-sm font-semibold text-green-800">✓ सही (Verified)</div>
                <div className="text-[11px] text-green-700">
                  सचिव द्वारा जांचा एवं सत्यापित
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-muted-foreground">परवानगी</div>
              <div className="text-xs font-mono font-semibold text-green-800">
                {member.memberCode}
              </div>
            </div>
          </div>
          <div className="text-[11px] text-muted-foreground text-center italic">
            &quot;मैं घोषित करता/करती हूं कि उपरोक्त जानकारी सत्य है। समूह के नियमों का पालन करूंगी/करूंगा।&quot;
          </div>
        </div>

        <Separator />

        {/* Member's expenses */}
        <MemberExpensesList memberId={member.id} memberName={member.name} />

        <div className="flex justify-end pt-2 border-t border-border/50">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="press-effect h-10">
            बंद करें
          </Button>
        </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

/* --------------------- Member Expenses List (in detail dialog) --------------------- */
function MemberExpensesList({ memberId, memberName }: { memberId: string; memberName: string }) {
  const [expenses, setExpenses] = useState<Array<{
    id: string; category: string; amount: number; description: string | null; expenseDate: string
  }>>([])
  const [categories, setCategories] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshKey, setRefreshKey] = useState(0)
  const { toast } = useToast()
  const admin = useAppStore((s) => s.admin)

  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const [eRes, cRes] = await Promise.all([
          fetch(`/api/expenses?memberId=${memberId}`, { cache: 'no-store' }),
          fetch('/api/expense-categories', { cache: 'no-store' }),
        ])
        const [e, c] = await Promise.all([eRes.json(), cRes.json()])
        if (mounted) {
          if (e.ok) setExpenses(e.expenses)
          if (c.ok) setCategories(c.categories.map((x: { name: string }) => x.name))
        }
      } catch { /* swallow */ } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
  }, [memberId, refreshKey])

  const total = expenses.reduce((s, e) => s + e.amount, 0)

  const handleDelete = async (id: string) => {
    if (!confirm('यह खर्च रिकॉर्ड हटाना चाहते हैं?')) return
    const r = await fetch(`/api/expenses/${id}`, { method: 'DELETE' })
    if (r.ok) {
      setRefreshKey((k) => k + 1)
      toast({ title: 'खर्च हटाया गया' })
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
          <Receipt className="w-3.5 h-3.5" />
          खर्च विवरण ({expenses.length})
        </div>
        <div className="text-sm font-bold text-primary">
          कुल: ₹{total.toLocaleString('en-IN')}
        </div>
      </div>

      {loading ? (
        <div className="h-16 bg-muted/60 animate-pulse rounded-lg" />
      ) : expenses.length === 0 ? (
        <div className="text-center text-xs text-muted-foreground py-4 bg-muted/30 rounded-lg">
          <Receipt className="w-8 h-8 mx-auto mb-2 opacity-30" />
          इस सदस्य पर अभी कोई खर्च दर्ज नहीं है।
        </div>
      ) : (
        <div className="space-y-1.5 max-h-48 overflow-y-auto scroll-area">
          {expenses.map((e) => (
            <div key={e.id} className="flex items-start gap-2 p-2.5 rounded-lg bg-muted/40 hover:bg-muted/60 transition-colors group">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge className="text-[10px] bg-primary/10 text-primary hover:bg-primary/10 border-0">
                    {e.category}
                  </Badge>
                  <span className="font-bold text-sm text-primary">
                    ₹{e.amount.toLocaleString('en-IN')}
                  </span>
                  <span className="text-[10px] text-muted-foreground">{formatDate(e.expenseDate)}</span>
                </div>
                {e.description && (
                  <div className="text-[11px] text-muted-foreground mt-1 leading-relaxed">
                    {e.description}
                  </div>
                )}
              </div>
              {admin && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive shrink-0"
                  onClick={() => handleDelete(e.id)}
                  aria-label="Delete expense"
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Inline add expense */}
      {admin && (
        <QuickAddExpense
          memberId={memberId}
          memberName={memberName}
          categories={categories}
          onSaved={() => setRefreshKey((k) => k + 1)}
        />
      )}
    </div>
  )
}

function QuickAddExpense({
  memberId,
  memberName,
  categories,
  onSaved,
}: {
  memberId: string
  memberName: string
  categories: string[]
  onSaved: () => void
}) {
  const { toast } = useToast()
  const [open, setOpen] = useState(false)
  const [category, setCategory] = useState(categories[0] || '')
  const [amount, setAmount] = useState('')
  const [description, setDescription] = useState('')
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (open) {
      setCategory(categories[0] || '')
      setAmount('')
      setDescription('')
    }
  }, [open, categories])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!category || !amount) {
      toast({ title: 'श्रेणी और राशि आवश्यक हैं', variant: 'destructive' })
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/expenses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          memberId,
          category,
          amount: Number(amount),
          description: description || null,
          expenseDate: toISODate(new Date()),
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'जोड़ने में विफल', description: data?.message, variant: 'destructive' })
        return
      }
      setOpen(false)
      onSaved()
      toast({ title: `${memberName} पर खर्च जोड़ा गया` })
    } catch {
      toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  if (!open) {
    return (
      <Button
        variant="outline"
        size="sm"
        className="w-full h-8 text-xs press-effect"
        onClick={() => setOpen(true)}
      >
        <Plus className="w-3.5 h-3.5" />
        इस सदस्य पर खर्च जोड़ें
      </Button>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-2 p-3 rounded-lg border border-primary/20 bg-primary/5">
      <div className="text-[11px] font-semibold text-primary">नया खर्च जोड़ें — {memberName}</div>
      <div className="grid grid-cols-2 gap-2">
        <CategoryPicker
          value={category}
          onChange={setCategory}
          categories={categories}
          placeholder="श्रेणी"
          compact
        />
        <Input
          type="number"
          min={0}
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="राशि ₹"
          className="h-8 text-xs"
          required
        />
      </div>
      <Input
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="विवरण (वैकल्पिक)"
        className="h-8 text-xs"
      />
      <div className="flex gap-2">
        <Button type="button" variant="outline" size="sm" className="h-7 text-xs flex-1" onClick={() => setOpen(false)}>
          रद्द करें
        </Button>
        <Button type="submit" size="sm" className="h-7 text-xs flex-1" disabled={submitting}>
          {submitting ? '...' : 'जोड़ें'}
        </Button>
      </div>
    </form>
  )
}

function DetailItem({
  icon,
  label,
  value,
  mono,
}: {
  icon: React.ReactNode
  label: string
  value: string
  mono?: boolean
}) {
  return (
    <div className="space-y-0.5">
      <div className="text-[11px] text-muted-foreground flex items-center gap-1">
        {icon}
        {label}
      </div>
      <div className={`text-sm font-medium ${mono ? 'font-mono' : ''}`}>{value}</div>
    </div>
  )
}

/* ----------- Loan Report Button (opens per-member loan report) ----------- */
function LoanReportButton({ member }: { member: Member }) {
  const [open, setOpen] = useState(false)
  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        className="h-7 w-7 text-blue-600 hover:text-blue-700"
        aria-label="Loan Report"
        onClick={() => setOpen(true)}
        title="लोन रिपोर्ट देखें"
      >
        <FileText className="w-3.5 h-3.5" />
      </Button>
      <MemberLoanReport member={member} open={open} onOpenChange={setOpen} />
    </>
  )
}

/* ----------- Edit Member Button (manages its own dialog state) ----------- */
function EditMemberButton({
  member,
  existingCodes,
  onSaved,
}: {
  member: Member
  existingCodes: string[]
  onSaved: () => void
}) {
  const [open, setOpen] = useState(false)
  return (
    <MemberFormDialog
      open={open}
      setOpen={setOpen}
      editMember={member}
      existingCodes={existingCodes}
      onSaved={onSaved}
    >
      <Button variant="ghost" size="icon" className="h-7 w-7" aria-label="Edit">
        <Pencil className="w-3.5 h-3.5" />
      </Button>
    </MemberFormDialog>
  )
}

/* --------------------------- Member Form Dialog --------------------------- */
function MemberFormDialog({
  open,
  setOpen,
  editMember,
  existingCodes,
  onSaved,
  children,
}: {
  open: boolean
  setOpen: (v: boolean) => void
  editMember: Member | null
  existingCodes: string[]
  onSaved: () => void
  children: React.ReactNode
}) {
  const { toast } = useToast()
  const [submitting, setSubmitting] = useState(false)
  const [memberCode, setMemberCode] = useState('')
  const [name, setName] = useState('')
  const [guardianName, setGuardianName] = useState('')
  const [post, setPost] = useState('सदस्य')
  const [age, setAge] = useState('')
  const [education, setEducation] = useState('')
  const [occupation, setOccupation] = useState('')
  const [village, setVillage] = useState('')
  const [district, setDistrict] = useState('')
  const [joiningDate, setJoiningDate] = useState('')
  const [kycStatus, setKycStatus] = useState('Verified')
  const [bankName, setBankName] = useState('')
  const [accountNo, setAccountNo] = useState('')
  const [ifscCode, setIfscCode] = useState('')
  const [phone, setPhone] = useState('')
  const [address, setAddress] = useState('')
  const [photoUrl, setPhotoUrl] = useState<string | null>(null)

  // Generate next member code suggestion
  const generateNextCode = () => {
    const codes = existingCodes.map((c) => c)
    const nums = codes
      .map((c) => parseInt(c.replace(/\D/g, ''), 10))
      .filter((n) => !isNaN(n))
    const max = nums.length > 0 ? Math.max(...nums) : 3844415
    return `JH${max + 1}`
  }

  useEffect(() => {
    if (open) {
      setMemberCode(editMember?.memberCode || generateNextCode())
      setName(editMember?.name || '')
      setGuardianName(editMember?.guardianName || '')
      setPost(editMember?.post || 'सदस्य')
      setAge(editMember?.age ? String(editMember.age) : '')
      setEducation(editMember?.education || '')
      setOccupation(editMember?.occupation || '')
      setVillage(editMember?.village || '')
      setDistrict(editMember?.district || 'Ranchi')
      setJoiningDate(editMember ? toISODate(editMember.joiningDate) : toISODate(new Date()))
      setKycStatus(editMember?.kycStatus || 'Verified')
      setBankName(editMember?.bankName || '')
      setAccountNo(editMember?.accountNo || '')
      setIfscCode(editMember?.ifscCode || '')
      setPhone(editMember?.phone || '')
      setAddress(editMember?.address || '')
      setPhotoUrl(editMember?.photoUrl || null)
    }
  }, [editMember, open])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name || !joiningDate || !memberCode) {
      toast({ title: 'सदस्य आईडी, नाम और शामिल होने की तिथि आवश्यक है', variant: 'destructive' })
      return
    }
    // Check unique memberCode (for new members)
    if (!editMember && existingCodes.includes(memberCode)) {
      toast({
        title: 'सदस्य आईडी पहले से मौजूद है',
        description: `आईडी "${memberCode}" पहले से किसी अन्य सदस्य को दी गई है।`,
        variant: 'destructive',
      })
      return
    }
    setSubmitting(true)
    try {
      const payload = {
        memberCode,
        name,
        guardianName: guardianName || null,
        post,
        age: age ? Number(age) : null,
        education: education || null,
        occupation: occupation || null,
        village: village || null,
        district: district || null,
        joiningDate,
        kycStatus,
        bankName: bankName || null,
        accountNo: accountNo || null,
        ifscCode: ifscCode || null,
        phone: phone || null,
        address: address || null,
        photoUrl: photoUrl || null,
      }
      const url = editMember ? `/api/members/${editMember.id}` : '/api/members'
      const method = editMember ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'सहेजने में विफल', description: data?.message, variant: 'destructive' })
        return
      }
      onSaved()
    } catch {
      toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="premium-dialog p-0 overflow-hidden border-0 sm:max-w-[560px] max-h-[90vh] overflow-y-auto">
        {/* Gradient header */}
        <div className="premium-dialog-header bg-gradient-to-br from-primary via-[oklch(0.4_0.14_150)] to-[oklch(0.35_0.12_160)] px-5 py-4 sm:px-6 sm:py-5">
          <div className="relative flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shrink-0 shadow-lg">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <DialogTitle className="text-base sm:text-lg font-bold text-white leading-tight">
                {editMember ? 'सदस्य संपादित करें' : 'नया सदस्य जोड़ें'}
              </DialogTitle>
              <DialogDescription className="text-xs text-white/80 mt-1">
                सदस्य की पूरी जानकारी भरें। सचिव द्वारा जांच के बाद &quot;✓ सही&quot; स्वतः लग जाएगा।
              </DialogDescription>
            </div>
          </div>
        </div>
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-5">
          {/* Photo upload — 3D circular frame */}
          <div className="flex justify-center pb-2">
            <PhotoUpload value={photoUrl} onChange={setPhotoUrl} name={name} size={96} />
          </div>

          {/* Section: Basic Identity */}
          <div className="space-y-3">
            <div className="premium-section-label">
              <User className="w-3 h-3" />
              बुनियादी पहचान
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">सदस्य आईडी (ID) *</Label>
                <div className="flex gap-1">
                  <Input
                    value={memberCode}
                    onChange={(e) => setMemberCode(e.target.value.toUpperCase())}
                    required
                    placeholder="JH3844426"
                    className="premium-input font-mono h-10"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="h-10 w-10 shrink-0"
                    onClick={() => setMemberCode(generateNextCode())}
                    title="अगला आईडी जनरेट करें"
                  >
                    <IdCard className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">पद (Post) *</Label>
                <Select value={post} onValueChange={setPost}>
                  <SelectTrigger className="premium-input h-10"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {POSTS.map((p) => (
                      <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">सदस्य का नाम *</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} required placeholder="सुनीता देवी" className="premium-input h-10" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">पति का नाम</Label>
                <Input value={guardianName} onChange={(e) => setGuardianName(e.target.value)} placeholder="श्रीराम रमेश" className="premium-input h-10" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">आयु</Label>
                <Input type="number" min={1} max={120} value={age} onChange={(e) => setAge(e.target.value)} placeholder="38" className="premium-input h-10" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">शिक्षा (Education)</Label>
                <Input value={education} onChange={(e) => setEducation(e.target.value)} placeholder="10वीं" className="premium-input h-10" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">व्यवसाय (Occupation)</Label>
                <Input value={occupation} onChange={(e) => setOccupation(e.target.value)} placeholder="खेतिहर" className="premium-input h-10" />
              </div>
            </div>
          </div>

          <Separator />

          {/* Section: Address */}
          <div className="space-y-3">
            <div className="premium-section-label">
              <Home className="w-3 h-3" />
              पता एवं संपर्क
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">ग्राम (Village)</Label>
                <Input value={village} onChange={(e) => setVillage(e.target.value)} placeholder="हरमू" className="premium-input h-10" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">जनपद (District)</Label>
                <Input value={district} onChange={(e) => setDistrict(e.target.value)} placeholder="रांची" className="premium-input h-10" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">शामिल होने की तिथि *</Label>
                <Input type="date" value={joiningDate} onChange={(e) => setJoiningDate(e.target.value)} required className="premium-input h-10" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">KYC स्थिति</Label>
                <Select value={kycStatus} onValueChange={setKycStatus}>
                  <SelectTrigger className="premium-input h-10"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Verified">सत्यापित (Verified)</SelectItem>
                    <SelectItem value="Pending">लंबित (Pending)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">फ़ोन</Label>
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="9835102345" className="premium-input h-10 font-mono" />
            </div>
          </div>

          <Separator />

          {/* Section: Bank */}
          <div className="space-y-3">
            <div className="premium-section-label">
              <Landmark className="w-3 h-3" />
              बैंक विवरण
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">बैंक का नाम</Label>
              <Input value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="State Bank of India" className="premium-input h-10" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">खाता संख्या</Label>
                <Input value={accountNo} onChange={(e) => setAccountNo(e.target.value)} placeholder="38291047652" className="premium-input h-10 font-mono" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">IFSC कोड</Label>
                <Input value={ifscCode} onChange={(e) => setIfscCode(e.target.value)} placeholder="SBIN0004521" className="premium-input h-10 font-mono" />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={submitting} className="press-effect h-10">
              रद्द करें
            </Button>
            <Button type="submit" disabled={submitting} className="premium-button text-white font-semibold h-10">
              {submitting ? 'सहेज रहे हैं...' : editMember ? 'अपडेट करें' : 'सदस्य जोड़ें'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
