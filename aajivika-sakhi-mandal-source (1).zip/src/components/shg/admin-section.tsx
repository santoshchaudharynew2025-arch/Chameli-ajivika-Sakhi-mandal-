'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { useAppStore } from '@/lib/store'
import { toISODate, formatDate } from '@/lib/format'
import { PhotoUpload } from '@/components/shg/avatar'
import {
  Settings as SettingsIcon,
  Save,
  Loader2,
  Building2,
  Calendar,
  PiggyBank,
  ShieldCheck,
  Landmark,
  Banknote,
  Percent,
  Receipt,
  Plus,
  Trash2,
  Pencil,
  Check,
  X,
  LogOut,
  Hash,
} from 'lucide-react'

interface Settings {
  registrationNo: string | null
  groupCode: string | null
  groupName: string | null
  foundingDate: string | null
  meetingDay: string
  weeklySavingsPerMember: number
  presidentName: string | null
  authorizedSignatoryName: string | null
  bankName: string | null
  bankBranch: string | null
  district: string | null
  minSavings: number
  maxSavings: number
  maxLoanAmount: number
  interestRate: number
}

export function AdminSection() {
  const [tab, setTab] = useState<'settings' | 'profile'>('settings')
  return (
    <div className="space-y-4">
      <div className="flex items-baseline gap-2 flex-wrap">
        <h2 className="text-lg font-semibold">समूह सेटिंग्स एवं प्रोफ़ाइल</h2>
        <span className="text-sm text-muted-foreground">
          पंजीकरण, बैंक, बचत नियम एवं एडमिन प्रोफ़ाइल
        </span>
      </div>
      {/* Tabs */}
      <div className="flex gap-1 border-b">
        <button
          onClick={() => setTab('settings')}
          className={`px-3 py-2 text-xs sm:text-sm font-medium border-b-2 transition ${
            tab === 'settings'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <SettingsIcon className="w-3.5 h-3.5 inline mr-1.5" />
          समूह सेटिंग्स
        </button>
        <button
          onClick={() => setTab('profile')}
          className={`px-3 py-2 text-xs sm:text-sm font-medium border-b-2 transition ${
            tab === 'profile'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5 inline mr-1.5" />
          एडमिन प्रोफ़ाइल
        </button>
      </div>
      {tab === 'settings' ? <GroupSettingsForm /> : <AdminProfile />}
    </div>
  )
}

function GroupSettingsForm() {
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [s, setS] = useState<Settings | null>(null)
  // form fields
  const [registrationNo, setRegistrationNo] = useState('')
  const [groupCode, setGroupCode] = useState('')
  const [groupName, setGroupName] = useState('')
  const [foundingDate, setFoundingDate] = useState('')
  const [meetingDay, setMeetingDay] = useState('Wednesday')
  const [weeklySavingsPerMember, setWeeklySavingsPerMember] = useState('10')
  const [presidentName, setPresidentName] = useState('')
  const [authorizedSignatoryName, setAuthorizedSignatoryName] = useState('')
  const [bankName, setBankName] = useState('')
  const [bankBranch, setBankBranch] = useState('')
  const [district, setDistrict] = useState('')
  const [minSavings, setMinSavings] = useState('2')
  const [maxSavings, setMaxSavings] = useState('5')
  const [maxLoanAmount, setMaxLoanAmount] = useState('10000')
  const [interestRate, setInterestRate] = useState('1.5')

  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const res = await fetch('/api/settings', { cache: 'no-store' })
        const data = await res.json()
        if (mounted && data.ok) {
          const st = data.settings
          setS(st)
          setRegistrationNo(st.registrationNo || '')
          setGroupCode(st.groupCode || '')
          setGroupName(st.groupName || '')
          setFoundingDate(toISODate(st.foundingDate))
          setMeetingDay(st.meetingDay || 'Wednesday')
          setWeeklySavingsPerMember(String(st.weeklySavingsPerMember || 10))
          setPresidentName(st.presidentName || '')
          setAuthorizedSignatoryName(st.authorizedSignatoryName || '')
          setBankName(st.bankName || '')
          setBankBranch(st.bankBranch || '')
          setDistrict(st.district || '')
          setMinSavings(String(st.minSavings || 2))
          setMaxSavings(String(st.maxSavings || 5))
          setMaxLoanAmount(String(st.maxLoanAmount || 10000))
          setInterestRate(String(st.interestRate || 1.5))
        }
      } catch { /* swallow */ } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          registrationNo,
          groupCode,
          groupName,
          foundingDate: foundingDate || null,
          meetingDay,
          weeklySavingsPerMember: Number(weeklySavingsPerMember),
          presidentName,
          authorizedSignatoryName,
          bankName,
          bankBranch,
          district,
          minSavings: Number(minSavings),
          maxSavings: Number(maxSavings),
          maxLoanAmount: Number(maxLoanAmount),
          interestRate: Number(interestRate),
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'सहेजने में विफल', variant: 'destructive' })
        return
      }
      setS(data.settings)
      toast({ title: 'सेटिंग्स सफलतापूर्वक सहेजी गईं' })
    } catch {
      toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return <div className="h-72 bg-muted/60 animate-pulse rounded-lg" />
  }

  return (
    <div className="space-y-4">
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Section: SHG Identity */}
        <Card className="shadow-card-3d">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Building2 className="w-4 h-4 text-primary" />
              समूह की पहचान
            </CardTitle>
            <CardDescription className="text-xs">
              SHG registration details and group ID.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs flex items-center gap-1">
                  <Building2 className="w-3 h-3" />
                  समूह का नाम
                </Label>
                <Input value={groupName} onChange={(e) => setGroupName(e.target.value)} placeholder="Aajivika Sakhi Mandal" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs flex items-center gap-1">
                  <Building2 className="w-3 h-3" />
                  पंजीकरण संख्या (e-Nibandhan)
                </Label>
                <Input value={registrationNo} onChange={(e) => setRegistrationNo(e.target.value)} placeholder="JH-ENB-2024-00874" />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  समूह आईडी (SHG Code)
                </Label>
                <Input
                  value={groupCode}
                  onChange={(e) => setGroupCode(e.target.value.toUpperCase())}
                  placeholder="JH340302"
                  className="font-mono font-semibold text-primary"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  गठन तिथि
                </Label>
                <Input type="date" value={foundingDate} onChange={(e) => setFoundingDate(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  बैठक का दिन
                </Label>
                <Select value={meetingDay} onValueChange={setMeetingDay}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'].map((d) => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Section: Office Bearers */}
        <Card className="shadow-card-3d">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-primary" />
              पदाधिकारी
            </CardTitle>
            <CardDescription className="text-xs">
              अध्यक्ष, उपाध्यक्ष, सचिव, कोषाध्यक्ष के नाम।
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs">अध्यक्ष (President)</Label>
                <Input value={presidentName} onChange={(e) => setPresidentName(e.target.value)} placeholder="सुनीता देवी" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">अधिकृत हस्ताक्षरकर्ता</Label>
                <Input value={authorizedSignatoryName} onChange={(e) => setAuthorizedSignatoryName(e.target.value)} placeholder="सुनीता देवी" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Section: Bank */}
        <Card className="shadow-card-3d">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Landmark className="w-4 h-4 text-primary" />
              बैंक विवरण
            </CardTitle>
            <CardDescription className="text-xs">
              समूह के बैंक खाते की जानकारी।
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5 sm:col-span-2">
                <Label className="text-xs">बैंक का नाम</Label>
                <Input value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="Jharkhand Rajya Gramin Bank" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">शाखा</Label>
                <Input value={bankBranch} onChange={(e) => setBankBranch(e.target.value)} placeholder="Silchar" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">जनपद</Label>
                <Input value={district} onChange={(e) => setDistrict(e.target.value)} placeholder="Ranchi" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Section: Savings & Loan Rules */}
        <Card className="shadow-card-3d">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <PiggyBank className="w-4 h-4 text-primary" />
              बचत एवं ऋण नियम
            </CardTitle>
            <CardDescription className="text-xs">
              साप्ताहिक बचत, अधिकतम ऋण राशि एवं ब्याज दर।
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs flex items-center gap-1">
                  <PiggyBank className="w-3 h-3" />
                  साप्ताहिक बचत (₹)
                </Label>
                <Input type="number" min={1} value={weeklySavingsPerMember} onChange={(e) => setWeeklySavingsPerMember(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">न्यूनतम बचत (₹)</Label>
                <Input type="number" min={0} value={minSavings} onChange={(e) => setMinSavings(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">अधिकतम बचत (₹)</Label>
                <Input type="number" min={0} value={maxSavings} onChange={(e) => setMaxSavings(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs flex items-center gap-1">
                  <Banknote className="w-3 h-3" />
                  अधिकतम ऋण (₹)
                </Label>
                <Input type="number" min={0} step="500" value={maxLoanAmount} onChange={(e) => setMaxLoanAmount(e.target.value)} />
              </div>
              <div className="space-y-1.5 col-span-2 sm:col-span-1">
                <Label className="text-xs flex items-center gap-1">
                  <Percent className="w-3 h-3" />
                  ब्याज दर (% प्रति माह)
                </Label>
                <Input type="number" min={0} step="0.1" value={interestRate} onChange={(e) => setInterestRate(e.target.value)} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Save button */}
        <div className="flex justify-end">
          <Button type="submit" disabled={saving} className="press-effect">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            सेटिंग्स सहेजें
          </Button>
        </div>
      </form>

      {/* Expense Categories Management */}
      <ExpenseCategoriesManager />

      {/* Current config preview */}
      <Card className="bg-muted/40 shadow-card">
        <CardContent className="p-4">
          <div className="text-xs text-muted-foreground mb-2 font-medium">वर्तमान कॉन्फ़िगरेशन</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <ConfigItem label="समूह आईडी" value={s?.groupCode || '—'} />
            <ConfigItem label="गठन" value={s?.foundingDate ? formatDate(s.foundingDate) : '—'} />
            <ConfigItem label="बैठक" value={s?.meetingDay || 'Wednesday'} />
            <ConfigItem label="बचत/सप्ताह" value={`₹${s?.weeklySavingsPerMember || 10}`} />
            <ConfigItem label="बैंक" value={s?.bankName || '—'} />
            <ConfigItem label="शाखा" value={s?.bankBranch || '—'} />
            <ConfigItem label="ब्याज दर" value={`${s?.interestRate || 1.5}% / माह`} />
            <ConfigItem label="अधिकतम ऋण" value={`₹${s?.maxLoanAmount || 10000}`} />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function ConfigItem({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</div>
      <div className="font-medium text-sm mt-0.5 truncate">{value}</div>
    </div>
  )
}

/* --------------------- Admin Profile --------------------- */
function AdminProfile() {
  const admin = useAppStore((s) => s.admin)
  const setAdmin = useAppStore((s) => s.setAdmin)
  const logout = useAppStore((s) => s.logout)
  const { toast } = useToast()
  const [groupSettings, setGroupSettings] = useState<Settings | null>(null)
  const [editing, setEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  // Editable fields
  const [editName, setEditName] = useState('')
  const [editEmail, setEditEmail] = useState('')
  const [editPhone, setEditPhone] = useState('')
  const [editPhotoUrl, setEditPhotoUrl] = useState<string | null>(null)
  const [editPassword, setEditPassword] = useState('')

  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const [sRes, pRes] = await Promise.all([
          fetch('/api/settings', { cache: 'no-store' }),
          fetch('/api/admin/profile', { cache: 'no-store' }),
        ])
        const [sData, pData] = await Promise.all([sRes.json(), pRes.json()])
        if (mounted) {
          if (sData.ok) setGroupSettings(sData.settings)
          if (pData.ok) {
            setEditName(pData.admin.name || '')
            setEditEmail(pData.admin.email || '')
            setEditPhone(pData.admin.phone || '')
            setEditPhotoUrl(pData.admin.photoUrl || null)
          }
        }
      } catch {
        /* swallow */
      }
    }
    load()
  }, [])

  const handleLogout = () => {
    logout()
    toast({ title: 'Logged out successfully' })
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      const res = await fetch('/api/admin/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editName,
          email: editEmail,
          phone: editPhone,
          photoUrl: editPhotoUrl,
          password: editPassword || undefined,
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'Save failed', variant: 'destructive' })
        return
      }
      // Update the store so the header/sidebar reflect the new name/photo
      setAdmin({
        id: admin?.id || '',
        username: admin?.username || 'admin',
        name: data.admin.name,
        photoUrl: data.admin.photoUrl,
      })
      setEditPassword('')
      setEditing(false)
      toast({ title: 'प्रोफ़ाइल अपडेट हुई' })
    } catch {
      toast({ title: 'Network error', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-4">
      {/* Admin profile card */}
      <Card className="shadow-card-3d overflow-hidden">
        {/* Gradient header with photo */}
        <div className="premium-dialog-header bg-gradient-to-br from-primary via-[oklch(0.4_0.14_150)] to-[oklch(0.35_0.12_160)] p-6 text-white relative">
          <div className="flex items-center gap-4 relative">
            {/* 3D photo frame */}
            {editing ? (
              <PhotoUpload value={editPhotoUrl} onChange={setEditPhotoUrl} name={editName} size={80} />
            ) : (
              <div className="shrink-0">
                {admin?.photoUrl ? (
                  <div className="w-20 h-20 rounded-full overflow-hidden ring-4 ring-white/40 shadow-2xl">
                    <img src={admin.photoUrl} alt={admin.name || 'Admin'} className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-md border-2 border-white/40 flex items-center justify-center shadow-2xl">
                    <ShieldCheck className="w-10 h-10 text-white" />
                  </div>
                )}
              </div>
            )}
            <div className="min-w-0">
              <div className="text-xs text-white/80 font-medium uppercase tracking-wide">Administrator</div>
              <div className="text-xl font-bold leading-tight truncate">
                {editing ? editName : (admin?.name || admin?.username || 'admin')}
              </div>
              <div className="text-sm text-white/80 mt-0.5 font-mono">
                @{admin?.username || 'admin'}
              </div>
            </div>
            {/* Edit button (top-right) */}
            {!editing && (
              <Button
                size="sm"
                variant="secondary"
                className="ml-auto bg-white/20 backdrop-blur-md text-white border-white/30 hover:bg-white/30 press-effect shrink-0"
                onClick={() => setEditing(true)}
              >
                <Pencil className="w-3.5 h-3.5" />
                Edit
              </Button>
            )}
          </div>
        </div>

        <CardContent className="p-5 space-y-4">
          {editing ? (
            /* Edit form */
            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Display Name</Label>
                  <Input value={editName} onChange={(e) => setEditName(e.target.value)} placeholder="सुनीता देवी" className="premium-input h-10" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Email</Label>
                  <Input type="email" value={editEmail} onChange={(e) => setEditEmail(e.target.value)} placeholder="admin@example.com" className="premium-input h-10" />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Phone</Label>
                  <Input value={editPhone} onChange={(e) => setEditPhone(e.target.value)} placeholder="9835102345" className="premium-input h-10 font-mono" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">New Password <span className="text-muted-foreground font-normal">(leave blank to keep)</span></Label>
                  <Input type="password" value={editPassword} onChange={(e) => setEditPassword(e.target.value)} placeholder="••••••••" className="premium-input h-10" />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-border/50">
                <Button type="button" variant="outline" onClick={() => { setEditing(false); setEditPassword('') }} disabled={saving} className="press-effect h-10">
                  रद्द करें
                </Button>
                <Button type="submit" disabled={saving} className="premium-button text-white font-semibold h-10">
                  {saving ? 'सहेज रहे हैं...' : 'प्रोफ़ाइल सहेजें'}
                </Button>
              </div>
            </form>
          ) : (
            <>
              {/* Profile details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                <ProfileItem
                  icon={<ShieldCheck className="w-3.5 h-3.5" />}
                  label="Username"
                  value={admin?.username || 'admin'}
                  mono
                />
                <ProfileItem
                  icon={<Building2 className="w-3.5 h-3.5" />}
                  label="Group Name"
                  value={groupSettings?.groupName || 'Aajivika Sakhi Mandal'}
                />
                <ProfileItem
                  icon={<Hash className="w-3.5 h-3.5" />}
                  label="Group ID"
                  value={groupSettings?.groupCode || '—'}
                  mono
                />
                <ProfileItem
                  icon={<Calendar className="w-3.5 h-3.5" />}
                  label="Member Since"
                  value={groupSettings?.foundingDate ? formatDate(groupSettings.foundingDate) : '—'}
                />
              </div>

              <Separator />

              {/* Role & permissions */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                  Role &amp; Permissions
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">✓ Member Management</Badge>
                  <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">✓ Loan Records</Badge>
                  <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">✓ Expense Records</Badge>
                  <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">✓ Group Settings</Badge>
                  <Badge className="bg-green-100 text-green-700 hover:bg-green-100 text-xs">✓ Categories</Badge>
                </div>
              </div>

              <Separator />

              {/* Logout button */}
              <Button
                variant="outline"
                className="w-full text-destructive hover:text-destructive hover:bg-destructive/5 press-effect"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4" />
                Logout from Dashboard
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function ProfileItem({
  icon,
  label,
  value,
  mono,
}: {
  icon: React.ReactNode
  label: string
  value: string
  mono?: boolean
}) {
  return (
    <div className="space-y-0.5">
      <div className="text-[11px] text-muted-foreground flex items-center gap-1">
        {icon}
        {label}
      </div>
      <div className={`text-sm font-medium ${mono ? 'font-mono' : ''}`}>{value}</div>
    </div>
  )
}

/* --------------------- Expense Categories Manager --------------------- */
interface ExpenseCategory { id: string; name: string }

function ExpenseCategoriesManager() {
  const { toast } = useToast()
  const [categories, setCategories] = useState<ExpenseCategory[]>([])
  const [loading, setLoading] = useState(true)
  const [newName, setNewName] = useState('')
  const [adding, setAdding] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState('')
  const [refreshKey, setRefreshKey] = useState(0)

  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const res = await fetch('/api/expense-categories', { cache: 'no-store' })
        const data = await res.json()
        if (mounted && data.ok) setCategories(data.categories)
      } catch { /* swallow */ } finally {
        if (mounted) setLoading(false)
      }
    }
    load()
  }, [refreshKey])

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newName.trim()) return
    setAdding(true)
    try {
      const res = await fetch('/api/expense-categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'जोड़ने में विफल', description: data?.message, variant: 'destructive' })
        return
      }
      setNewName('')
      setRefreshKey((k) => k + 1)
      toast({ title: 'श्रेणी जोड़ी गई' })
    } catch {
      toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' })
    } finally {
      setAdding(false)
    }
  }

  const handleUpdate = async (id: string) => {
    if (!editName.trim()) return
    try {
      const res = await fetch(`/api/expense-categories/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: editName }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'अपडेट में विफल', description: data?.message, variant: 'destructive' })
        return
      }
      setEditingId(null)
      setRefreshKey((k) => k + 1)
      toast({ title: 'श्रेणी अपडेट हुई' })
    } catch {
      toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' })
    }
  }

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`श्रेणी "${name}" हटाना चाहते हैं?`)) return
    try {
      const res = await fetch(`/api/expense-categories/${id}`, { method: 'DELETE' })
      if (res.ok) {
        setRefreshKey((k) => k + 1)
        toast({ title: 'श्रेणी हटाई गई' })
      } else {
        toast({ title: 'हटाने में विफल', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'नेटवर्क त्रुटि', variant: 'destructive' })
    }
  }

  return (
    <Card className="shadow-card-3d">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Receipt className="w-4 h-4 text-primary" />
          खर्च श्रेणियाँ (Expense Categories)
        </CardTitle>
        <CardDescription className="text-xs">
          खर्च की श्रेणियाँ जोड़ें, संपादित करें या हटाएँ। जैसे: रोटी खर्च, यात्रा खर्च, चिकित्सा खर्च।
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add new category form */}
        <form onSubmit={handleAdd} className="flex gap-2">
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="नई श्रेणी का नाम... (जैसे: मरम्मत खर्च)"
            className="h-9"
          />
          <Button type="submit" size="sm" className="h-9 press-effect" disabled={adding || !newName.trim()}>
            {adding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            जोड़ें
          </Button>
        </form>

        {/* List of categories */}
        {loading ? (
          <div className="h-20 bg-muted/60 animate-pulse rounded-lg" />
        ) : categories.length === 0 ? (
          <div className="text-center text-xs text-muted-foreground py-6">
            कोई श्रेणी नहीं है। ऊपर नई श्रेणी जोड़ें।
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <div
                key={cat.id}
                className="flex items-center gap-1.5 bg-secondary/60 rounded-full pl-3 pr-1 py-1 group"
              >
                {editingId === cat.id ? (
                  <>
                    <Input
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="h-6 w-32 text-xs px-2 py-0"
                      autoFocus
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleUpdate(cat.id)
                        if (e.key === 'Escape') setEditingId(null)
                      }}
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-6 w-6 press-effect"
                      onClick={() => handleUpdate(cat.id)}
                      aria-label="Save"
                    >
                      <Check className="w-3 h-3 text-green-600" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-6 w-6 press-effect"
                      onClick={() => setEditingId(null)}
                      aria-label="Cancel"
                    >
                      <X className="w-3 h-3 text-muted-foreground" />
                    </Button>
                  </>
                ) : (
                  <>
                    <Badge className="bg-primary/10 text-primary hover:bg-primary/10 text-xs font-medium border-0">
                      <Receipt className="w-3 h-3 mr-1" />
                      {cat.name}
                    </Badge>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-6 w-6 press-effect opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => {
                        setEditingId(cat.id)
                        setEditName(cat.name)
                      }}
                      aria-label="Edit"
                    >
                      <Pencil className="w-3 h-3 text-muted-foreground" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-6 w-6 press-effect opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive"
                      onClick={() => handleDelete(cat.id, cat.name)}
                      aria-label="Delete"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
