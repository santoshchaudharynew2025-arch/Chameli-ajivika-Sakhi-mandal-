'use client'

import { useEffect, useState } from 'react'
import { useAppStore, type Section } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { BrandBlock } from '@/components/shg/logo'
import { formatDate } from '@/lib/format'
import {
  LayoutDashboard,
  Users,
  HandCoins,
  Receipt,
  CalendarCheck,
  FileText,
  BarChart3,
  Settings,
  LogOut,
  ShieldCheck,
} from 'lucide-react'

interface NavItem {
  id: Section
  label: string
  description: string
  icon: React.ComponentType<{ className?: string }>
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Dashboard', description: 'Overview & summary', icon: LayoutDashboard },
  { id: 'members', label: 'Members', description: 'Member directory', icon: Users },
  { id: 'loans', label: 'Loans & EMI', description: 'Loan records', icon: HandCoins },
  { id: 'expenses', label: 'खर्च (Expenses)', description: 'Member expenses', icon: Receipt },
  { id: 'weekly', label: 'साप्ताहिक जमा', description: 'Weekly ₹10 collection', icon: CalendarCheck },
  { id: 'meetings', label: 'प्रस्ताव (Meetings)', description: 'Meeting resolutions', icon: FileText },
  { id: 'reports', label: 'Reports', description: 'Financial reports', icon: BarChart3 },
  { id: 'admin', label: 'Settings', description: 'Group settings', icon: Settings },
]

interface BrandingSettings {
  groupName: string | null
  groupCode: string | null
  foundingDate: string | null
}

function useNavState() {
  const activeSection = useAppStore((s) => s.activeSection)
  const setActiveSection = useAppStore((s) => s.setActiveSection)
  const admin = useAppStore((s) => s.admin)
  const logout = useAppStore((s) => s.logout)
  return { activeSection, setActiveSection, admin, logout }
}

/**
 * Fetches the group settings (name, code, founding date) for branding.
 */
function useBrandingSettings() {
  const [data, setData] = useState<BrandingSettings | null>(null)
  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const res = await fetch('/api/settings', { cache: 'no-store' })
        const json = await res.json()
        if (mounted && json.ok) {
          setData({
            groupName: json.settings.groupName,
            groupCode: json.settings.groupCode,
            foundingDate: json.settings.foundingDate,
          })
        }
      } catch {
        /* swallow */
      }
    }
    load()
  }, [])
  return data
}

/**
 * Sidebar content shared between desktop sidebar and mobile drawer.
 */
function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const { activeSection, setActiveSection, admin, logout } = useNavState()
  const settings = useBrandingSettings()
  const foundingDateStr = settings?.foundingDate ? formatDate(settings.foundingDate) : null

  return (
    <div className="flex flex-col h-full bg-card">
      {/* Brand header — official logo + group name + group ID + founding date */}
      <div className="p-4 border-b border-border">
        <BrandBlock
          groupName={settings?.groupName}
          groupCode={settings?.groupCode}
          foundingDate={foundingDateStr}
        />
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 overflow-y-auto scroll-area" aria-label="Primary">
        <ul className="space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon
            const isActive = activeSection === item.id
            const isDisabled = !admin && item.id === 'admin'
            return (
              <li key={item.id}>
                <button
                  onClick={() => {
                    if (isDisabled) return
                    setActiveSection(item.id)
                    onNavigate?.()
                  }}
                  disabled={isDisabled}
                  className={cn(
                    'press-effect w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all text-left',
                    isActive
                      ? 'bg-primary/10 text-primary shadow-card'
                      : 'text-foreground hover:bg-muted hover:shadow-card',
                    isDisabled && 'opacity-40 cursor-not-allowed'
                  )}
                  aria-current={isActive ? 'page' : undefined}
                >
                  <Icon className={cn('w-4 h-4 shrink-0 transition-transform', isActive && 'scale-110')} />
                  <div className="flex-1 min-w-0">
                    <div className="leading-tight">{item.label}</div>
                    <div className="text-[10px] text-muted-foreground leading-tight font-normal">
                      {item.description}
                    </div>
                  </div>
                </button>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Footer: admin + logout */}
      <div className="p-3 border-t border-border space-y-2">
        {admin && (
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-muted/50 shadow-card">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-3.5 h-3.5 text-primary" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-medium truncate">
                {admin.name || admin.username}
              </div>
              <div className="text-[10px] text-muted-foreground">Administrator</div>
            </div>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          className="press-effect w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/5"
          onClick={() => {
            logout()
            onNavigate?.()
          }}
        >
          <LogOut className="w-4 h-4" />
          Logout
        </Button>
      </div>
    </div>
  )
}

/**
 * Desktop fixed sidebar (>= lg screens). Always visible on desktop.
 */
export function DesktopSidebar() {
  return (
    <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 lg:z-30 border-r border-border bg-card shadow-card">
      <SidebarContent />
    </aside>
  )
}
