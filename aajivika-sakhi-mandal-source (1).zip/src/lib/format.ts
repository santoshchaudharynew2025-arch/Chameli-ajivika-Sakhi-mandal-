// All date/time helpers in this file work in Indian Standard Time (IST),
// which is Asia/Kolkata (UTC+5:30). This keeps the UI consistent regardless
// of where the server runs (e.g. UTC on cloud servers).

export const IST_TIMEZONE = 'Asia/Kolkata'

/**
 * Returns a Date object representing the current moment. The Date itself is
 * timezone-agnostic (it's a UTC instant), but all formatting helpers below
 * convert it to IST before displaying.
 */
export function nowInIST(): Date {
  return new Date()
}

/**
 * Convert any Date to its IST representation by shifting the underlying
 * UTC milliseconds. This makes .getDate() / .getMonth() / .getFullYear()
 * return the Indian calendar values even when the host is in UTC.
 */
function toISTDate(date: Date): Date {
  // IST = UTC + 5h 30m. We also need to undo the host's local offset so the
  // resulting Date's local-time getters return IST values.
  const IST_OFFSET_MIN = 5 * 60 + 30 // 330
  const hostOffsetMin = -date.getTimezoneOffset() // minutes east of UTC
  const shiftMin = IST_OFFSET_MIN - hostOffsetMin
  return new Date(date.getTime() + shiftMin * 60 * 1000)
}

export function formatINR(amount: number): string {
  // Indian numbering system: 1,00,000 format
  const rounded = Math.round(amount)
  const sign = rounded < 0 ? '-' : ''
  const abs = Math.abs(rounded)
  const str = abs.toString()
  let lastThree = str.substring(str.length - 3)
  const otherNumbers = str.substring(0, str.length - 3)
  if (otherNumbers !== '') lastThree = ',' + lastThree
  const formatted = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree
  return `${sign}₹${formatted}`
}

/**
 * Format a date as DD/MM/YYYY in Indian Standard Time.
 */
export function formatDate(date: Date | string | null | undefined): string {
  if (!date) return '—'
  const d = typeof date === 'string' ? new Date(date) : date
  if (isNaN(d.getTime())) return '—'
  const ist = toISTDate(d)
  const dd = String(ist.getUTCDate()).padStart(2, '0')
  const mm = String(ist.getUTCMonth() + 1).padStart(2, '0')
  const yyyy = ist.getUTCFullYear()
  return `${dd}/${mm}/${yyyy}`
}

/**
 * Format a date with time as DD/MM/YYYY, hh:mm AM/PM in IST.
 */
export function formatDateTime(date: Date | string | null | undefined): string {
  if (!date) return '—'
  const d = typeof date === 'string' ? new Date(date) : date
  if (isNaN(d.getTime())) return '—'
  const ist = toISTDate(d)
  const dd = String(ist.getUTCDate()).padStart(2, '0')
  const mm = String(ist.getUTCMonth() + 1).padStart(2, '0')
  const yyyy = ist.getUTCFullYear()
  let hours = ist.getUTCHours()
  const minutes = String(ist.getUTCMinutes()).padStart(2, '0')
  const ampm = hours >= 12 ? 'PM' : 'AM'
  hours = hours % 12 || 12
  return `${dd}/${mm}/${yyyy}, ${hours}:${minutes} ${ampm}`
}

/**
 * Format only the time as hh:mm AM/PM in IST.
 */
export function formatTime(date: Date | string | null | undefined): string {
  if (!date) return '—'
  const d = typeof date === 'string' ? new Date(date) : date
  if (isNaN(d.getTime())) return '—'
  const ist = toISTDate(d)
  let hours = ist.getUTCHours()
  const minutes = String(ist.getUTCMinutes()).padStart(2, '0')
  const ampm = hours >= 12 ? 'PM' : 'AM'
  hours = hours % 12 || 12
  return `${hours}:${minutes} ${ampm}`
}

/**
 * Returns the ISO date string (YYYY-MM-DD) in IST — used for <input type="date">.
 */
export function toISODate(date: Date | string | null | undefined): string {
  if (!date) return ''
  const d = typeof date === 'string' ? new Date(date) : date
  if (isNaN(d.getTime())) return ''
  const ist = toISTDate(d)
  const yyyy = ist.getUTCFullYear()
  const mm = String(ist.getUTCMonth() + 1).padStart(2, '0')
  const dd = String(ist.getUTCDate()).padStart(2, '0')
  return `${yyyy}-${mm}-${dd}`
}

/**
 * Format the current IST date as a long readable string for headers.
 * Example: "Monday, 06 Jul 2026"
 */
export function formatTodayLongIST(): string {
  return nowInIST().toLocaleDateString('en-IN', {
    weekday: 'long',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    timeZone: IST_TIMEZONE,
  })
}

/**
 * Format the current IST time as hh:mm AM/PM.
 */
export function formatTimeIST(): string {
  return nowInIST().toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
    timeZone: IST_TIMEZONE,
  })
}
