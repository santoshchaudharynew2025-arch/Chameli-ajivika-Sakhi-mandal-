'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type Section = 'home' | 'members' | 'loans' | 'expenses' | 'weekly' | 'meetings' | 'reports' | 'admin'

interface AdminUser {
  id: string
  username: string
  name: string | null
  photoUrl?: string | null
}

interface AppState {
  // Auth
  admin: AdminUser | null
  setAdmin: (admin: AdminUser | null) => void
  logout: () => void
  // Navigation
  activeSection: Section
  setActiveSection: (s: Section) => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      admin: null,
      setAdmin: (admin) => set({ admin }),
      logout: () => set({ admin: null, activeSection: 'home' }),
      activeSection: 'home',
      setActiveSection: (activeSection) => set({ activeSection }),
    }),
    { name: 'aajivika-sakhi' }
  )
)
