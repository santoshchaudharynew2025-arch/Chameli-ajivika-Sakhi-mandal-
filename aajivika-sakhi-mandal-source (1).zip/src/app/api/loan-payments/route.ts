import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/loan-payments — list all loan payments with member info
// Optional: ?memberId=xxx or ?loanType=bank|private
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const memberId = searchParams.get('memberId')
    const loanType = searchParams.get('loanType')

    const where: Record<string, unknown> = {}
    if (memberId) where.memberId = memberId
    if (loanType) where.loanType = loanType

    const payments = await db.loanPayment.findMany({
      where,
      include: { member: true },
      orderBy: { paymentDate: 'desc' },
    })
    return NextResponse.json({ ok: true, payments })
  } catch (e) {
    console.error('Fetch loan payments error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to fetch loan payments' },
      { status: 500 }
    )
  }
}

// POST /api/loan-payments — add a new payment entry
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { memberId, loanType, loanId, paymentDate, paymentTime, amount, principal, interest, remainingBalance, paymentMode, receiptNo, remarks } = body

    if (!memberId || !loanType || !paymentDate || amount === undefined) {
      return NextResponse.json(
        { ok: false, message: 'Member, loan type, date and amount are required' },
        { status: 400 }
      )
    }

    const payment = await db.loanPayment.create({
      data: {
        memberId,
        loanType,
        loanId: loanId || '',
        paymentDate: new Date(paymentDate),
        paymentTime: paymentTime || null,
        amount: Number(amount),
        principal: Number(principal) || 0,
        interest: Number(interest) || 0,
        remainingBalance: Number(remainingBalance) || 0,
        paymentMode: paymentMode || 'cash',
        receiptNo: receiptNo || null,
        remarks: remarks || null,
      },
      include: { member: true },
    })
    return NextResponse.json({ ok: true, payment })
  } catch (e) {
    console.error('Create loan payment error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to create loan payment' },
      { status: 500 }
    )
  }
}
