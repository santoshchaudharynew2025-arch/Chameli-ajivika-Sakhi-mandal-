import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

type Params = { params: Promise<{ id: string }> }

// PUT /api/loan-payments/[id] — update a payment entry
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    const body = await req.json()
    const { paymentDate, paymentTime, amount, principal, interest, remainingBalance, paymentMode, receiptNo, remarks } = body

    const payment = await db.loanPayment.update({
      where: { id },
      data: {
        ...(paymentDate !== undefined && { paymentDate: new Date(paymentDate) }),
        ...(paymentTime !== undefined && { paymentTime: paymentTime || null }),
        ...(amount !== undefined && { amount: Number(amount) }),
        ...(principal !== undefined && { principal: Number(principal) }),
        ...(interest !== undefined && { interest: Number(interest) }),
        ...(remainingBalance !== undefined && { remainingBalance: Number(remainingBalance) }),
        ...(paymentMode !== undefined && { paymentMode }),
        ...(receiptNo !== undefined && { receiptNo: receiptNo || null }),
        ...(remarks !== undefined && { remarks: remarks || null }),
      },
      include: { member: true },
    })
    return NextResponse.json({ ok: true, payment })
  } catch (e) {
    console.error('Update loan payment error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to update payment' },
      { status: 500 }
    )
  }
}

// DELETE /api/loan-payments/[id]
export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    await db.loanPayment.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('Delete loan payment error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to delete payment' },
      { status: 500 }
    )
  }
}
