import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/expense-categories — list all categories
export async function GET() {
  try {
    const categories = await db.expenseCategory.findMany({
      orderBy: { name: 'asc' },
    })
    return NextResponse.json({ ok: true, categories })
  } catch (e) {
    console.error('Fetch expense categories error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to fetch categories' },
      { status: 500 }
    )
  }
}

// POST /api/expense-categories — create a new category
export async function POST(req: NextRequest) {
  try {
    const { name } = await req.json()
    if (!name || !name.trim()) {
      return NextResponse.json(
        { ok: false, message: 'Category name is required' },
        { status: 400 }
      )
    }
    const existing = await db.expenseCategory.findFirst({
      where: { name: name.trim() },
    })
    if (existing) {
      return NextResponse.json(
        { ok: false, message: `Category "${name.trim()}" already exists` },
        { status: 400 }
      )
    }
    const category = await db.expenseCategory.create({
      data: { name: name.trim() },
    })
    return NextResponse.json({ ok: true, category })
  } catch (e) {
    console.error('Create expense category error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to create category' },
      { status: 500 }
    )
  }
}
