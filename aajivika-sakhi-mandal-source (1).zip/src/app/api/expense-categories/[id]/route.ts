import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

type Params = { params: Promise<{ id: string }> }

// PUT /api/expense-categories/[id] — rename a category
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    const { name } = await req.json()
    if (!name || !name.trim()) {
      return NextResponse.json(
        { ok: false, message: 'Category name is required' },
        { status: 400 }
      )
    }
    const existing = await db.expenseCategory.findFirst({
      where: { name: name.trim(), NOT: { id } },
    })
    if (existing) {
      return NextResponse.json(
        { ok: false, message: `Category "${name.trim()}" already exists` },
        { status: 400 }
      )
    }
    const category = await db.expenseCategory.update({
      where: { id },
      data: { name: name.trim() },
    })
    return NextResponse.json({ ok: true, category })
  } catch (e) {
    console.error('Update expense category error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to update category' },
      { status: 500 }
    )
  }
}

// DELETE /api/expense-categories/[id]
export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    await db.expenseCategory.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('Delete expense category error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to delete category' },
      { status: 500 }
    )
  }
}
