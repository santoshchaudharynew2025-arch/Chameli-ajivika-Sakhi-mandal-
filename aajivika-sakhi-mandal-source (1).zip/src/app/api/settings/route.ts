import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/settings
export async function GET() {
  try {
    let settings = await db.settings.findFirst()
    if (!settings) {
      settings = await db.settings.create({ data: {} })
    }
    return NextResponse.json({ ok: true, settings })
  } catch (e) {
    console.error('Fetch settings error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to fetch settings' },
      { status: 500 }
    )
  }
}

// PUT /api/settings
export async function PUT(req: NextRequest) {
  try {
    const body = await req.json()
    const {
      registrationNo,
      groupCode,
      groupName,
      foundingDate,
      meetingDay,
      weeklySavingsPerMember,
      presidentName,
      authorizedSignatoryName,
      bankName,
      bankBranch,
      district,
      minSavings,
      maxSavings,
      maxLoanAmount,
      interestRate,
    } = body
    let settings = await db.settings.findFirst()
    const data = {
      ...(registrationNo !== undefined && { registrationNo }),
      ...(groupCode !== undefined && { groupCode }),
      ...(groupName !== undefined && { groupName }),
      ...(foundingDate !== undefined && {
        foundingDate: foundingDate ? new Date(foundingDate) : null,
      }),
      ...(meetingDay !== undefined && { meetingDay }),
      ...(weeklySavingsPerMember !== undefined && {
        weeklySavingsPerMember: Number(weeklySavingsPerMember),
      }),
      ...(presidentName !== undefined && { presidentName }),
      ...(authorizedSignatoryName !== undefined && { authorizedSignatoryName }),
      ...(bankName !== undefined && { bankName }),
      ...(bankBranch !== undefined && { bankBranch }),
      ...(district !== undefined && { district }),
      ...(minSavings !== undefined && { minSavings: Number(minSavings) }),
      ...(maxSavings !== undefined && { maxSavings: Number(maxSavings) }),
      ...(maxLoanAmount !== undefined && { maxLoanAmount: Number(maxLoanAmount) }),
      ...(interestRate !== undefined && { interestRate: Number(interestRate) }),
    }
    if (!settings) {
      settings = await db.settings.create({ data })
    } else {
      settings = await db.settings.update({ where: { id: settings.id }, data })
    }
    return NextResponse.json({ ok: true, settings })
  } catch (e) {
    console.error('Update settings error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to update settings' },
      { status: 500 }
    )
  }
}
