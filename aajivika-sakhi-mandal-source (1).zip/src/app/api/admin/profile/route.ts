import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/admin/profile — get current admin profile (first admin, since single-admin system)
export async function GET() {
  try {
    const admin = await db.admin.findFirst({
      select: {
        id: true,
        username: true,
        name: true,
        email: true,
        phone: true,
        photoUrl: true,
      },
    })
    if (!admin) {
      return NextResponse.json(
        { ok: false, message: 'No admin found' },
        { status: 404 }
      )
    }
    return NextResponse.json({ ok: true, admin })
  } catch (e) {
    console.error('Fetch admin profile error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to fetch admin profile' },
      { status: 500 }
    )
  }
}

// PUT /api/admin/profile — update admin profile (name, email, phone, photoUrl, password)
export async function PUT(req: NextRequest) {
  try {
    const body = await req.json()
    const { name, email, phone, photoUrl, password } = body

    const admin = await db.admin.findFirst()
    if (!admin) {
      return NextResponse.json(
        { ok: false, message: 'No admin found' },
        { status: 404 }
      )
    }

    const updated = await db.admin.update({
      where: { id: admin.id },
      data: {
        ...(name !== undefined && { name: name || null }),
        ...(email !== undefined && { email: email || null }),
        ...(phone !== undefined && { phone: phone || null }),
        ...(photoUrl !== undefined && { photoUrl: photoUrl || null }),
        // Only update password if a new one is provided (non-empty)
        ...(password !== undefined && password && { password }),
      },
      select: {
        id: true,
        username: true,
        name: true,
        email: true,
        phone: true,
        photoUrl: true,
      },
    })
    return NextResponse.json({ ok: true, admin: updated })
  } catch (e) {
    console.error('Update admin profile error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to update admin profile' },
      { status: 500 }
    )
  }
}
