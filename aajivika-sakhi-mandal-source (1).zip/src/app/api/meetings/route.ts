import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/meetings
export async function GET() {
  try {
    const meetings = await db.meeting.findMany({ orderBy: { meetingDate: 'desc' } })
    return NextResponse.json({ ok: true, meetings })
  } catch (e) {
    console.error('Fetch meetings error:', e)
    return NextResponse.json({ ok: false, message: 'Failed' }, { status: 500 })
  }
}

// POST /api/meetings — creates meeting AND auto-creates loan records
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const count = await db.meeting.count()

    // Create the meeting record
    const meeting = await db.meeting.create({
      data: {
        resolutionNo: count + 1,
        meetingDate: new Date(body.meetingDate),
        location: body.location || null,
        meetingTime: body.meetingTime || null,
        chairperson: body.chairperson || null,
        secretary: body.secretary || null,
        treasurer: body.treasurer || null,
        bkName: body.bkName || null,
        presentCount: Number(body.presentCount) || 0,
        absentCount: Number(body.absentCount) || 0,
        presentMembers: body.presentMembers || null,
        absentMembers: body.absentMembers || null,
        topic: body.topic || null,
        decisions: body.decisions || null,
        totalSavings: Number(body.totalSavings) || 0,
        totalPending: Number(body.totalPending) || 0,
        totalAdvance: Number(body.totalAdvance) || 0,
        totalLoanGiven: Number(body.totalLoanGiven) || 0,
        totalLoanCollected: Number(body.totalLoanCollected) || 0,
        groupFundBalance: Number(body.groupFundBalance) || 0,
        totalExpenses: Number(body.totalExpenses) || 0,
        nextMeetingDate: body.nextMeetingDate ? new Date(body.nextMeetingDate) : null,
        nextMeetingLocation: body.nextMeetingLocation || null,
        nextMeetingHost: body.nextMeetingHost || null,
        notes: body.notes || null,
      },
    })

    // Auto-create loan records from meeting transactions
    const transactions = body.loanTransactions || []
    for (const tx of transactions) {
      if (tx.type === 'bank_loan_given') {
        // Create bank loan record
        await db.bankLoan.create({
          data: {
            memberId: tx.memberId,
            bankLoanShare: Number(tx.amount),
            emiPaid: 0,
            interestPaid: 0,
            interestRate: Number(tx.interestRate) || 0,
            paymentDate: new Date(body.meetingDate),
            bankName: tx.bankName || 'Bank Loan',
          },
        })
      } else if (tx.type === 'private_loan_given') {
        // Create private loan record
        await db.privateLoan.create({
          data: {
            memberId: tx.memberId,
            loanAmount: Number(tx.amount),
            interestRate: Number(tx.interestRate) || 0,
            disbursementDate: new Date(body.meetingDate),
            repaymentAmount: 0,
            repaymentDate: null,
          },
        })
      } else if (tx.type === 'loan_payment') {
        // Create loan payment record
        const principal = Number(tx.amount) - (Number(tx.interest) || 0)
        await db.loanPayment.create({
          data: {
            memberId: tx.memberId,
            loanType: tx.loanType || 'bank',
            loanId: tx.loanId || '',
            paymentDate: new Date(body.meetingDate),
            paymentTime: body.meetingTime || null,
            amount: Number(tx.amount),
            principal,
            interest: Number(tx.interest) || 0,
            remainingBalance: Number(tx.remainingBalance) || 0,
            paymentMode: tx.paymentMode || 'cash',
            remarks: `प्रस्ताव #${meeting.resolutionNo} में भुगतान`,
          },
        })
      }
    }

    return NextResponse.json({ ok: true, meeting })
  } catch (e) {
    console.error('Create meeting error:', e)
    return NextResponse.json({ ok: false, message: 'Failed' }, { status: 500 })
  }
}
