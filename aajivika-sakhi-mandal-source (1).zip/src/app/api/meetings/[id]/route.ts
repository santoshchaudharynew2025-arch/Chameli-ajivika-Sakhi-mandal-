import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

type Params = { params: Promise<{ id: string }> }

// PUT /api/meetings/[id]
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    const body = await req.json()
    const meeting = await db.meeting.update({
      where: { id },
      data: {
        ...(body.meetingDate !== undefined && { meetingDate: new Date(body.meetingDate) }),
        ...(body.location !== undefined && { location: body.location || null }),
        ...(body.meetingTime !== undefined && { meetingTime: body.meetingTime || null }),
        ...(body.chairperson !== undefined && { chairperson: body.chairperson || null }),
        ...(body.secretary !== undefined && { secretary: body.secretary || null }),
        ...(body.treasurer !== undefined && { treasurer: body.treasurer || null }),
        ...(body.bkName !== undefined && { bkName: body.bkName || null }),
        ...(body.presentCount !== undefined && { presentCount: Number(body.presentCount) || 0 }),
        ...(body.absentCount !== undefined && { absentCount: Number(body.absentCount) || 0 }),
        ...(body.presentMembers !== undefined && { presentMembers: body.presentMembers || null }),
        ...(body.absentMembers !== undefined && { absentMembers: body.absentMembers || null }),
        ...(body.topic !== undefined && { topic: body.topic || null }),
        ...(body.decisions !== undefined && { decisions: body.decisions || null }),
        ...(body.totalSavings !== undefined && { totalSavings: Number(body.totalSavings) || 0 }),
        ...(body.totalPending !== undefined && { totalPending: Number(body.totalPending) || 0 }),
        ...(body.totalAdvance !== undefined && { totalAdvance: Number(body.totalAdvance) || 0 }),
        ...(body.totalLoanGiven !== undefined && { totalLoanGiven: Number(body.totalLoanGiven) || 0 }),
        ...(body.totalLoanCollected !== undefined && { totalLoanCollected: Number(body.totalLoanCollected) || 0 }),
        ...(body.groupFundBalance !== undefined && { groupFundBalance: Number(body.groupFundBalance) || 0 }),
        ...(body.totalExpenses !== undefined && { totalExpenses: Number(body.totalExpenses) || 0 }),
        ...(body.nextMeetingDate !== undefined && { nextMeetingDate: body.nextMeetingDate ? new Date(body.nextMeetingDate) : null }),
        ...(body.nextMeetingLocation !== undefined && { nextMeetingLocation: body.nextMeetingLocation || null }),
        ...(body.nextMeetingHost !== undefined && { nextMeetingHost: body.nextMeetingHost || null }),
        ...(body.notes !== undefined && { notes: body.notes || null }),
      },
    })
    return NextResponse.json({ ok: true, meeting })
  } catch (e) {
    console.error('Update meeting error:', e)
    return NextResponse.json({ ok: false, message: 'Failed' }, { status: 500 })
  }
}

// DELETE /api/meetings/[id]
export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    await db.meeting.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('Delete meeting error:', e)
    return NextResponse.json({ ok: false, message: 'Failed' }, { status: 500 })
  }
}
