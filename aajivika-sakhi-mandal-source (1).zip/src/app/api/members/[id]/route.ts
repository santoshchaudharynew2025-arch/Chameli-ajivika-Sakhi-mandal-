import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

type Params = { params: Promise<{ id: string }> }

// PUT /api/members/[id]
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    const body = await req.json()
    const {
      memberCode,
      name,
      guardianName,
      post,
      age,
      education,
      occupation,
      village,
      district,
      joiningDate,
      kycStatus,
      bankName,
      accountNo,
      ifscCode,
      phone,
      address,
      photoUrl,
    } = body

    // Check for memberCode uniqueness (excluding current member)
    if (memberCode) {
      const existing = await db.member.findFirst({
        where: { memberCode, NOT: { id } },
      })
      if (existing) {
        return NextResponse.json(
          { ok: false, message: `Member ID "${memberCode}" already belongs to another member.` },
          { status: 400 }
        )
      }
    }

    const member = await db.member.update({
      where: { id },
      data: {
        ...(memberCode !== undefined && { memberCode: memberCode.trim() }),
        ...(name !== undefined && { name: name.trim() }),
        ...(guardianName !== undefined && { guardianName: guardianName || null }),
        ...(post !== undefined && { post }),
        ...(age !== undefined && { age: age ? Number(age) : null }),
        ...(education !== undefined && { education: education || null }),
        ...(occupation !== undefined && { occupation: occupation || null }),
        ...(village !== undefined && { village: village || null }),
        ...(district !== undefined && { district: district || null }),
        ...(joiningDate !== undefined && { joiningDate: new Date(joiningDate) }),
        ...(kycStatus !== undefined && { kycStatus }),
        ...(bankName !== undefined && { bankName: bankName || null }),
        ...(accountNo !== undefined && { accountNo: accountNo || null }),
        ...(ifscCode !== undefined && { ifscCode: ifscCode || null }),
        ...(phone !== undefined && { phone: phone || null }),
        ...(address !== undefined && { address: address || null }),
        ...(photoUrl !== undefined && { photoUrl: photoUrl || null }),
      },
    })
    return NextResponse.json({ ok: true, member })
  } catch (e) {
    console.error('Update member error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to update member' },
      { status: 500 }
    )
  }
}

// DELETE /api/members/[id]
export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    await db.member.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('Delete member error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to delete member' },
      { status: 500 }
    )
  }
}
