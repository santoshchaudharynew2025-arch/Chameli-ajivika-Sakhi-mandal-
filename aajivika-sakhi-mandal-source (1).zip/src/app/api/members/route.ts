import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/members — list all members with their loans
export async function GET() {
  try {
    const members = await db.member.findMany({
      orderBy: { serialNo: 'asc' },
      include: {
        privateLoans: { orderBy: { disbursementDate: 'desc' } },
        bankLoans: { orderBy: { createdAt: 'desc' } },
      },
    })
    return NextResponse.json({ ok: true, members })
  } catch (e) {
    console.error('Fetch members error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to fetch members' },
      { status: 500 }
    )
  }
}

// POST /api/members — create a new member
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const {
      memberCode,
      name,
      guardianName,
      post,
      age,
      education,
      occupation,
      village,
      district,
      joiningDate,
      kycStatus,
      bankName,
      accountNo,
      ifscCode,
      phone,
      address,
      photoUrl,
    } = body

    if (!name || !joiningDate || !memberCode) {
      return NextResponse.json(
        { ok: false, message: 'Member ID, name and joining date are required' },
        { status: 400 }
      )
    }

    // Check if memberCode already exists
    const existing = await db.member.findFirst({ where: { memberCode } })
    if (existing) {
      return NextResponse.json(
        { ok: false, message: `Member ID "${memberCode}" already exists. Please use a unique ID.` },
        { status: 400 }
      )
    }

    // Determine next serialNo
    const count = await db.member.count()
    const member = await db.member.create({
      data: {
        serialNo: count + 1,
        memberCode: memberCode.trim(),
        name: name.trim(),
        guardianName: guardianName?.trim() || null,
        post: post || 'सदस्य',
        age: age ? Number(age) : null,
        education: education?.trim() || null,
        occupation: occupation?.trim() || null,
        village: village?.trim() || null,
        district: district?.trim() || null,
        joiningDate: new Date(joiningDate),
        kycStatus: kycStatus || 'Pending',
        bankName: bankName || null,
        accountNo: accountNo || null,
        ifscCode: ifscCode || null,
        phone: phone || null,
        address: address || null,
        photoUrl: photoUrl || null,
        // Secretary verifies the entry automatically — mark as सही
        signMark: 'सही',
      },
    })
    return NextResponse.json({ ok: true, member })
  } catch (e) {
    console.error('Create member error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to create member' },
      { status: 500 }
    )
  }
}
