import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/loans/private — list all private loans with member info
export async function GET() {
  try {
    const loans = await db.privateLoan.findMany({
      include: { member: true },
      orderBy: { disbursementDate: 'desc' },
    })
    return NextResponse.json({ ok: true, loans })
  } catch (e) {
    console.error('Fetch private loans error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to fetch private loans' },
      { status: 500 }
    )
  }
}

// POST /api/loans/private
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { memberId, loanAmount, disbursementDate, repaymentAmount, repaymentDate, note } = body
    if (!memberId || loanAmount === undefined || !disbursementDate) {
      return NextResponse.json(
        { ok: false, message: 'Member, amount and disbursement date are required' },
        { status: 400 }
      )
    }
    const loan = await db.privateLoan.create({
      data: {
        memberId,
        loanAmount: Number(loanAmount),
        disbursementDate: new Date(disbursementDate),
        repaymentAmount: Number(repaymentAmount || 0),
        repaymentDate: repaymentDate ? new Date(repaymentDate) : null,
        note: note || null,
      },
      include: { member: true },
    })
    return NextResponse.json({ ok: true, loan })
  } catch (e) {
    console.error('Create private loan error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to create private loan' },
      { status: 500 }
    )
  }
}
