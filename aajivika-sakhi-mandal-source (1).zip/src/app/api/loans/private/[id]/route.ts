import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

type Params = { params: Promise<{ id: string }> }

// PUT /api/loans/private/[id]
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    const body = await req.json()
    const { loanAmount, disbursementDate, repaymentAmount, repaymentDate, note } = body
    const loan = await db.privateLoan.update({
      where: { id },
      data: {
        ...(loanAmount !== undefined && { loanAmount: Number(loanAmount) }),
        ...(disbursementDate !== undefined && { disbursementDate: new Date(disbursementDate) }),
        ...(repaymentAmount !== undefined && { repaymentAmount: Number(repaymentAmount) }),
        ...(repaymentDate !== undefined && {
          repaymentDate: repaymentDate ? new Date(repaymentDate) : null,
        }),
        ...(note !== undefined && { note: note || null }),
      },
      include: { member: true },
    })
    return NextResponse.json({ ok: true, loan })
  } catch (e) {
    console.error('Update private loan error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to update private loan' },
      { status: 500 }
    )
  }
}

// DELETE /api/loans/private/[id]
export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    await db.privateLoan.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('Delete private loan error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to delete private loan' },
      { status: 500 }
    )
  }
}
