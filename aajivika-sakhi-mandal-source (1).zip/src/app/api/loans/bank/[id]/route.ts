import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

type Params = { params: Promise<{ id: string }> }

// PUT /api/loans/bank/[id]
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    const body = await req.json()
    const { bankLoanShare, emiPaid, interestPaid, paymentDate, bankName, note } = body
    const loan = await db.bankLoan.update({
      where: { id },
      data: {
        ...(bankLoanShare !== undefined && { bankLoanShare: Number(bankLoanShare) }),
        ...(emiPaid !== undefined && { emiPaid: Number(emiPaid) }),
        ...(interestPaid !== undefined && { interestPaid: Number(interestPaid) }),
        ...(paymentDate !== undefined && {
          paymentDate: paymentDate ? new Date(paymentDate) : null,
        }),
        ...(bankName !== undefined && { bankName: bankName || null }),
        ...(note !== undefined && { note: note || null }),
      },
      include: { member: true },
    })
    return NextResponse.json({ ok: true, loan })
  } catch (e) {
    console.error('Update bank loan error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to update bank loan' },
      { status: 500 }
    )
  }
}

// DELETE /api/loans/bank/[id]
export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    await db.bankLoan.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('Delete bank loan error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to delete bank loan' },
      { status: 500 }
    )
  }
}
