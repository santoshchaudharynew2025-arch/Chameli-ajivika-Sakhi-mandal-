import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/loans/bank — list all bank loans with member info
export async function GET() {
  try {
    const loans = await db.bankLoan.findMany({
      include: { member: true },
      orderBy: { createdAt: 'desc' },
    })
    return NextResponse.json({ ok: true, loans })
  } catch (e) {
    console.error('Fetch bank loans error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to fetch bank loans' },
      { status: 500 }
    )
  }
}

// POST /api/loans/bank
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { memberId, bankLoanShare, emiPaid, interestPaid, paymentDate, bankName, note } = body
    if (!memberId || bankLoanShare === undefined) {
      return NextResponse.json(
        { ok: false, message: 'Member and bank loan share are required' },
        { status: 400 }
      )
    }
    const loan = await db.bankLoan.create({
      data: {
        memberId,
        bankLoanShare: Number(bankLoanShare),
        emiPaid: Number(emiPaid || 0),
        interestPaid: Number(interestPaid || 0),
        paymentDate: paymentDate ? new Date(paymentDate) : null,
        bankName: bankName || null,
        note: note || null,
      },
      include: { member: true },
    })
    return NextResponse.json({ ok: true, loan })
  } catch (e) {
    console.error('Create bank loan error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to create bank loan' },
      { status: 500 }
    )
  }
}
