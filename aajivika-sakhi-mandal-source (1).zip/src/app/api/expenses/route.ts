import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/expenses — list all expenses with member info
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const memberId = searchParams.get('memberId')
    const expenses = await db.expense.findMany({
      where: memberId ? { memberId } : undefined,
      include: { member: true },
      orderBy: { expenseDate: 'desc' },
    })
    return NextResponse.json({ ok: true, expenses })
  } catch (e) {
    console.error('Fetch expenses error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to fetch expenses' },
      { status: 500 }
    )
  }
}

// POST /api/expenses
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { memberId, category, amount, description, expenseDate } = body
    // memberId is OPTIONAL — null means a group-level expense
    if (!category || amount === undefined || !expenseDate) {
      return NextResponse.json(
        { ok: false, message: 'Category, amount and date are required' },
        { status: 400 }
      )
    }
    const expense = await db.expense.create({
      data: {
        memberId: memberId || null,
        category: category.trim(),
        amount: Number(amount),
        description: description?.trim() || null,
        expenseDate: new Date(expenseDate),
      },
      include: { member: true },
    })
    return NextResponse.json({ ok: true, expense })
  } catch (e) {
    console.error('Create expense error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to create expense' },
      { status: 500 }
    )
  }
}
