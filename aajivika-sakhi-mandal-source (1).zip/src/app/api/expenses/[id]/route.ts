import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

type Params = { params: Promise<{ id: string }> }

// PUT /api/expenses/[id]
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    const body = await req.json()
    const { memberId, category, amount, description, expenseDate } = body
    const expense = await db.expense.update({
      where: { id },
      data: {
        // Allow setting memberId to null (group expense) by passing empty string or null
        ...(memberId !== undefined && { memberId: memberId || null }),
        ...(category !== undefined && { category: category.trim() }),
        ...(amount !== undefined && { amount: Number(amount) }),
        ...(description !== undefined && { description: description?.trim() || null }),
        ...(expenseDate !== undefined && { expenseDate: new Date(expenseDate) }),
      },
      include: { member: true },
    })
    return NextResponse.json({ ok: true, expense })
  } catch (e) {
    console.error('Update expense error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to update expense' },
      { status: 500 }
    )
  }
}

// DELETE /api/expenses/[id]
export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    const { id } = await params
    await db.expense.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('Delete expense error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to delete expense' },
      { status: 500 }
    )
  }
}
