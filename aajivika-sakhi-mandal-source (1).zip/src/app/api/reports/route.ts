import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/reports — aggregated reporting data
export async function GET() {
  try {
    const [members, settings, privateLoans, bankLoans, expenses, weeklySavings] = await Promise.all([
      db.member.findMany({ include: { privateLoans: true, bankLoans: true, weeklySavings: true } }),
      db.settings.findFirst(),
      db.privateLoan.findMany({ include: { member: true } }),
      db.bankLoan.findMany({ include: { member: true } }),
      db.expense.findMany({ include: { member: true } }),
      db.weeklySaving.findMany({ include: { member: true }, orderBy: { weekDate: 'desc' } }),
    ])

    const weeklySavingsPerMember = settings?.weeklySavingsPerMember ?? 10

    // ===== Executive Summary =====
    const totalMembers = members.length
    const totalSavings = weeklySavings.reduce((s, w) => s + w.amount, 0)
    const totalBankLoan = bankLoans.reduce((s, l) => s + l.bankLoanShare, 0)
    const totalBankLoanPaid = bankLoans.reduce((s, l) => s + l.emiPaid, 0)
    const totalBankInterest = bankLoans.reduce((s, l) => s + l.interestPaid, 0)
    const totalPrivateLoan = privateLoans.reduce((s, l) => s + l.loanAmount, 0)
    const totalPrivateLoanRepaid = privateLoans.reduce((s, l) => s + l.repaymentAmount, 0)
    const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0)

    // Pending & advance from latest week
    const latestWeek = weeklySavings[0]?.weekDate
    let pendingThisWeek = 0
    let advanceThisWeek = 0
    let paidThisWeek = 0
    let pendingMembers = 0
    let advanceMembers = 0
    let paidMembers = 0

    if (latestWeek) {
      const latestDate = new Date(latestWeek)
      latestDate.setHours(0, 0, 0, 0)
      const nextDay = new Date(latestDate)
      nextDay.setDate(nextDay.getDate() + 1)
      const latestWeekSavings = weeklySavings.filter(
        (w) => w.weekDate >= latestDate && w.weekDate < nextDay
      )
      for (const w of latestWeekSavings) {
        if (w.status === 'paid') { paidThisWeek += w.amount; paidMembers++ }
        else if (w.status === 'pending') { pendingThisWeek += weeklySavingsPerMember; pendingMembers++ }
        else if (w.status === 'advance') { advanceThisWeek += w.amount - weeklySavingsPerMember; advanceMembers++ }
      }
    }

    // Today's / this week's / this month's / this year's collection
    const now = new Date()
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    const weekAgo = new Date(now)
    weekAgo.setDate(weekAgo.getDate() - 7)
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1)
    const yearStart = new Date(now.getFullYear(), 0, 1)

    const todayCollection = weeklySavings
      .filter((w) => w.weekDate >= todayStart && w.status === 'paid')
      .reduce((s, w) => s + w.amount, 0)
    const weekCollection = weeklySavings
      .filter((w) => w.weekDate >= weekAgo && w.status === 'paid')
      .reduce((s, w) => s + w.amount, 0)
    const monthCollection = weeklySavings
      .filter((w) => w.weekDate >= monthStart && w.status === 'paid')
      .reduce((s, w) => s + w.amount, 0)
    const yearCollection = weeklySavings
      .filter((w) => w.weekDate >= yearStart && w.status === 'paid')
      .reduce((s, w) => s + w.amount, 0)

    // ===== Member Financial Report =====
    const memberReports = members.map((m) => {
      const mSavings = m.weeklySavings.reduce((s, w) => s + w.amount, 0)
      const mPending = m.weeklySavings
        .filter((w) => w.status === 'pending')
        .length * weeklySavingsPerMember
      const mAdvance = m.weeklySavings
        .filter((w) => w.status === 'advance')
        .reduce((s, w) => s + (w.amount - weeklySavingsPerMember), 0)
      const mBankLoans = m.bankLoans.reduce((s, l) => s + l.bankLoanShare, 0)
      const mBankPaid = m.bankLoans.reduce((s, l) => s + l.emiPaid, 0)
      const mPrivateLoans = m.privateLoans.reduce((s, l) => s + l.loanAmount, 0)
      const mPrivateRepaid = m.privateLoans.reduce((s, l) => s + l.repaymentAmount, 0)
      const mInterest = m.bankLoans.reduce((s, l) => s + l.interestPaid, 0)
      const lastPayment = m.weeklySavings
        .filter((w) => w.status === 'paid')
        .sort((a, b) => b.weekDate.getTime() - a.weekDate.getTime())[0]?.weekDate || null

      return {
        memberId: m.memberCode,
        name: m.name,
        phone: m.phone,
        village: m.village,
        post: m.post,
        photoUrl: m.photoUrl,
        totalSavings: mSavings,
        totalPending: mPending,
        totalAdvance: mAdvance,
        bankLoanTaken: mBankLoans,
        bankLoanPaid: mBankPaid,
        bankLoanRemaining: mBankLoans - mBankPaid,
        privateLoanTaken: mPrivateLoans,
        privateLoanRepaid: mPrivateRepaid,
        privateLoanRemaining: mPrivateLoans - mPrivateRepaid,
        totalInterest: mInterest,
        lastPaymentDate: lastPayment,
      }
    })

    // ===== Weekly Collection (latest week) =====
    const weeklyCollection = latestWeek
      ? weeklySavings
          .filter((w) => {
            const d = new Date(latestWeek)
            d.setHours(0, 0, 0, 0)
            const next = new Date(d)
            next.setDate(next.getDate() + 1)
            return w.weekDate >= d && w.weekDate < next
          })
          .map((w) => ({
            name: w.member.name,
            memberCode: w.member.memberCode,
            photoUrl: w.member.photoUrl,
            amount: w.amount,
            status: w.status,
            advanceWeeks: w.advanceWeeks,
          }))
      : []

    // ===== Pending Report =====
    const pendingReport = memberReports
      .filter((m) => m.totalPending > 0)
      .sort((a, b) => b.totalPending - a.totalPending)

    // ===== Advance Report =====
    const advanceReport = memberReports
      .filter((m) => m.totalAdvance > 0)
      .sort((a, b) => b.totalAdvance - a.totalAdvance)

    return NextResponse.json({
      ok: true,
      report: {
        executive: {
          totalMembers,
          totalSavings,
          totalBankLoan,
          totalBankLoanPaid,
          totalBankLoanRemaining: totalBankLoan - totalBankLoanPaid,
          totalBankInterest,
          totalPrivateLoan,
          totalPrivateLoanRepaid,
          totalPrivateLoanRemaining: totalPrivateLoan - totalPrivateLoanRepaid,
          totalExpenses,
          pendingThisWeek,
          advanceThisWeek,
          paidThisWeek,
          pendingMembers,
          advanceMembers,
          paidMembers,
          todayCollection,
          weekCollection,
          monthCollection,
          yearCollection,
          latestWeekDate: latestWeek,
          weeklySavingsPerMember,
        },
        memberReports,
        weeklyCollection,
        pendingReport,
        advanceReport,
        weeklySavingsHistory: weeklySavings.map((w) => ({
          date: w.weekDate,
          memberName: w.member.name,
          memberCode: w.member.memberCode,
          amount: w.amount,
          status: w.status,
          advanceWeeks: w.advanceWeeks,
        })),
      },
    })
  } catch (e) {
    console.error('Reports error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to generate reports' },
      { status: 500 }
    )
  }
}
