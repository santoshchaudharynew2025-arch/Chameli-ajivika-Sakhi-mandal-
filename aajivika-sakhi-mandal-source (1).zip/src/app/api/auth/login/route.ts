import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// POST /api/auth/login
export async function POST(req: NextRequest) {
  try {
    const { username, password } = await req.json()
    if (!username || !password) {
      return NextResponse.json(
        { ok: false, message: 'Username and password are required' },
        { status: 400 }
      )
    }
    const admin = await db.admin.findFirst({
      where: { username: username.trim(), password },
    })
    if (!admin) {
      return NextResponse.json(
        { ok: false, message: 'Invalid credentials. Please contact the President.' },
        { status: 401 }
      )
    }
    return NextResponse.json({
      ok: true,
      admin: {
        id: admin.id,
        username: admin.username,
        name: admin.name,
        photoUrl: admin.photoUrl,
      },
    })
  } catch (e) {
    console.error('Login error:', e)
    return NextResponse.json(
      { ok: false, message: 'Server error during login' },
      { status: 500 }
    )
  }
}
