import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/weekly-savings — list all weekly savings with member info
// Optional query: ?weekDate=2026-07-01 to filter by specific week
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const weekDate = searchParams.get('weekDate')
    const memberId = searchParams.get('memberId')

    const where: Record<string, unknown> = {}
    if (weekDate) {
      const start = new Date(weekDate)
      start.setHours(0, 0, 0, 0)
      const end = new Date(start)
      end.setDate(end.getDate() + 1)
      where.weekDate = { gte: start, lt: end }
    }
    if (memberId) where.memberId = memberId

    const savings = await db.weeklySaving.findMany({
      where,
      include: { member: true },
      orderBy: { weekDate: 'desc' },
    })
    return NextResponse.json({ ok: true, savings })
  } catch (e) {
    console.error('Fetch weekly savings error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to fetch weekly savings' },
      { status: 500 }
    )
  }
}

// POST /api/weekly-savings — create or update a weekly saving entry
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { memberId, weekDate, amount, status, advanceWeeks, note } = body

    if (!memberId || !weekDate || !status) {
      return NextResponse.json(
        { ok: false, message: 'Member, weekDate and status are required' },
        { status: 400 }
      )
    }

    // Check if entry already exists for this member + weekDate
    const start = new Date(weekDate)
    start.setHours(0, 0, 0, 0)
    const end = new Date(start)
    end.setDate(end.getDate() + 1)

    const existing = await db.weeklySaving.findFirst({
      where: { memberId, weekDate: { gte: start, lt: end } },
    })

    if (existing) {
      // Update existing
      const updated = await db.weeklySaving.update({
        where: { id: existing.id },
        data: {
          amount: Number(amount) || 0,
          status,
          advanceWeeks: Number(advanceWeeks) || 0,
          note: note || null,
        },
        include: { member: true },
      })
      return NextResponse.json({ ok: true, saving: updated })
    }

    // Create new
    const saving = await db.weeklySaving.create({
      data: {
        memberId,
        weekDate: new Date(weekDate),
        amount: Number(amount) || 0,
        status,
        advanceWeeks: Number(advanceWeeks) || 0,
        note: note || null,
      },
      include: { member: true },
    })
    return NextResponse.json({ ok: true, saving })
  } catch (e) {
    console.error('Create weekly saving error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to save weekly saving' },
      { status: 500 }
    )
  }
}
