import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/dashboard — aggregate financial summary
export async function GET() {
  try {
    const [settings, memberCount, privateLoans, bankLoans] = await Promise.all([
      db.settings.findFirst(),
      db.member.count(),
      db.privateLoan.findMany(),
      db.bankLoan.findMany(),
    ])

    const weeklySavingsPerMember = settings?.weeklySavingsPerMember ?? 10
    // Total savings = weekly savings per member * number of weeks since founding
    const foundingDate = settings?.foundingDate ?? new Date('2020-10-14')
    const weeksSinceFounding = Math.max(
      1,
      Math.floor((Date.now() - foundingDate.getTime()) / (7 * 24 * 60 * 60 * 1000))
    )
    const totalSavings = weeklySavingsPerMember * memberCount * weeksSinceFounding

    const totalPrivateLoanDisbursed = privateLoans.reduce(
      (s, l) => s + l.loanAmount,
      0
    )
    const totalPrivateLoanRepaid = privateLoans.reduce(
      (s, l) => s + l.repaymentAmount,
      0
    )
    const totalPrivateLoanOutstanding =
      totalPrivateLoanDisbursed - totalPrivateLoanRepaid

    const totalBankLoanShare = bankLoans.reduce(
      (s, l) => s + l.bankLoanShare,
      0
    )
    const totalEmiPaid = bankLoans.reduce((s, l) => s + l.emiPaid, 0)
    const totalInterestPaid = bankLoans.reduce((s, l) => s + l.interestPaid, 0)

    return NextResponse.json({
      ok: true,
      summary: {
        memberCount,
        weeklySavingsPerMember,
        weeksSinceFounding,
        totalSavings,
        totalPrivateLoanDisbursed,
        totalPrivateLoanRepaid,
        totalPrivateLoanOutstanding,
        totalBankLoanShare,
        totalEmiPaid,
        totalInterestPaid,
        foundingDate,
        meetingDay: settings?.meetingDay ?? 'Wednesday',
        groupCode: settings?.groupCode ?? null,
        groupName: settings?.groupName ?? null,
      },
    })
  } catch (e) {
    console.error('Dashboard error:', e)
    return NextResponse.json(
      { ok: false, message: 'Failed to fetch dashboard summary' },
      { status: 500 }
    )
  }
}
