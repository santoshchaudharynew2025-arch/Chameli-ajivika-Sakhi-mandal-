import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Aajivika Sakhi Mandal | SHG Management",
  description:
    "Aajivika Sakhi Mandal — A women's Self Help Group management dashboard for members, savings, private loans, and bank loan & EMI tracking.",
  keywords: [
    "SHG",
    "Self Help Group",
    "Aajivika Sakhi Mandal",
    "Jharkhand",
    "women empowerment",
    "microfinance",
    "savings",
    "loan",
  ],
  authors: [{ name: "Aajivika Sakhi Mandal" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
