'use client'

import { useEffect, useState, useSyncExternalStore } from 'react'
import { useAppStore } from '@/lib/store'
import { DesktopSidebar } from '@/components/shg/sidebar'
import { TopHeader } from '@/components/shg/top-header'
import { MobileTopBar, MobileBottomNav } from '@/components/shg/mobile-nav'
import { LoginScreen } from '@/components/shg/login-screen'
import { DashboardSection } from '@/components/shg/dashboard-section'
import { MembersSection } from '@/components/shg/members-section'
import { LoansSection } from '@/components/shg/loans-section'
import { ExpensesSection } from '@/components/shg/expenses-section'
import { WeeklyCollectionSection } from '@/components/shg/weekly-collection-section'
import { MeetingsSection } from '@/components/shg/meetings-section'
import { ReportsSection } from '@/components/shg/reports-section'
import { AdminSection } from '@/components/shg/admin-section'
import { formatDate } from '@/lib/format'

interface Settings {
  registrationNo: string | null
  groupCode: string | null
  groupName: string | null
  foundingDate: string | null
  meetingDay: string
}

const SECTION_TITLES: Record<string, string> = {
  home: 'Dashboard',
  members: 'Members',
  loans: 'Loans & EMI',
  expenses: 'खर्च (Expenses)',
  weekly: 'साप्ताहिक जमा',
  meetings: 'प्रस्ताव (Meetings)',
  reports: 'Reports',
  admin: 'Settings',
}

function usePersistHydrated() {
  return useSyncExternalStore(
    (onChange) => {
      const persistApi = useAppStore.persist
      if (!persistApi) return () => {}
      const unsub = persistApi.onFinishHydration(onChange)
      return unsub
    },
    () => (useAppStore.persist?.hasHydrated?.() ?? false),
    () => false
  )
}

export default function Home() {
  const admin = useAppStore((s) => s.admin)
  const activeSection = useAppStore((s) => s.activeSection)
  const setActiveSection = useAppStore((s) => s.setActiveSection)
  const [settings, setSettings] = useState<Settings | null>(null)
  const hydrated = usePersistHydrated()

  useEffect(() => {
    if (!admin) return
    let mounted = true
    const load = async () => {
      try {
        const res = await fetch('/api/settings', { cache: 'no-store' })
        const data = await res.json()
        if (mounted && data.ok) setSettings(data.settings)
      } catch { /* swallow */ }
    }
    load()
    return () => { mounted = false }
  }, [admin])

  useEffect(() => {
    if (!admin && activeSection === 'admin') {
      setActiveSection('home')
    }
  }, [admin, activeSection, setActiveSection])

  if (!hydrated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-xs text-muted-foreground">Loading…</div>
      </div>
    )
  }

  if (!admin) {
    return <LoginScreen />
  }

  const mobilePageTitle = SECTION_TITLES[activeSection] || 'Dashboard'

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Desktop sidebar (lg+ only, always visible) */}
      <DesktopSidebar />

      {/* Mobile top bar (below lg only) */}
      <MobileTopBar
        pageTitle={mobilePageTitle}
        groupName={settings?.groupName}
        groupCode={settings?.groupCode}
        foundingDate={settings?.foundingDate ? formatDate(settings.foundingDate) : null}
      />

      {/* Main content area — offset for desktop sidebar */}
      <div className="lg:pl-64 flex flex-col min-h-screen">
        {/* Desktop top header (lg+ only) */}
        <div className="hidden lg:block">
          <TopHeader data={settings} />
        </div>

        {/* Main content */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-5 pb-28 lg:pb-8 max-w-6xl mx-auto w-full">
          {activeSection === 'home' && <DashboardSection />}
          {activeSection === 'members' && <MembersSection />}
          {activeSection === 'loans' && <LoansSection />}
          {activeSection === 'expenses' && <ExpensesSection />}
          {activeSection === 'weekly' && <WeeklyCollectionSection />}
          {activeSection === 'meetings' && <MeetingsSection />}
          {activeSection === 'reports' && <ReportsSection />}
          {activeSection === 'admin' && <AdminSection />}
        </main>
      </div>

      {/* Mobile bottom navigation (below lg only) */}
      <MobileBottomNav />
    </div>
  )
}
