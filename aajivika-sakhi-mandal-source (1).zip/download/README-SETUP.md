# AAJIVIKA SAKHI MANDAL — SHG Management System

## How to Run (Setup Instructions)

### Prerequisites
- Node.js 18+ or Bun
- SQLite (already included — no separate install needed)

### Steps

1. **Extract the zip file**
   ```bash
   unzip aajivika-sakhi-mandal-source.zip
   cd aajivika-sakhi-mandal
   ```

2. **Install dependencies**
   ```bash
   npm install
   # OR if you have bun:
   bun install
   ```

3. **Set up the database**
   ```bash
   # Create the database and tables
   npx prisma db push
   # OR
   bun run db:push
   ```

4. **Seed sample data** (optional — creates demo members, loans, etc.)
   ```bash
   npx tsx scripts/seed.ts
   # OR
   bun run scripts/seed.ts
   ```

5. **Start the development server**
   ```bash
   npm run dev
   # OR
   bun run dev
   ```

6. **Open in browser**
   ```
   http://localhost:3000
   ```

## Login Credentials
- Username: `admin`
- Password: `sakhi123`

## Features
1. **Dashboard** — 3D glassmorphism stat cards, animated progress rings, IST clock
2. **Members** — Excel-style table + premium 3D card view, photos, KYC, education/occupation
3. **Loans & EMI** — Private + Bank loans, Payment Tracker (date/time, principal/interest auto-calc)
4. **Expenses** — Member/group expenses with categories, self-type option
5. **Weekly Collection** — Mark all members' ₹10 payments in one screen
6. **Meetings (प्रस्ताव)** — Meeting resolutions with WhatsApp share, attendance, group fund
7. **Reports** — Executive summary, weekly collection, member financial, pending, advance, charts
8. **Settings** — Group config, expense categories, admin profile (editable with photo)

## Tech Stack
- Next.js 16 (App Router)
- TypeScript 5
- Tailwind CSS 4
- shadcn/ui components
- Prisma ORM + SQLite
- Zustand (state management)

## Database Models
- Admin, Settings, Member
- PrivateLoan, BankLoan, LoanPayment
- Expense, ExpenseCategory
- WeeklySaving, Meeting

## Group Info
- Group Name: Aajivika Sakhi Mandal
- Group Code: JH340302
- Registration No: JH-ENB-2024-00874
- Meeting Day: Every Wednesday
- Weekly Savings: ₹10/member
